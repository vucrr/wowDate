
Blizzard_Console_SavedVars = {
	["version"] = 3,
	["height"] = 299.999908447266,
	["messageHistory"] = {
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [1]
		{
			"Render scale changed to 0.4", -- [1]
			0, -- [2]
		}, -- [2]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [3]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [4]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [5]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [6]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [7]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [8]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [9]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [10]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [11]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [12]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [13]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [14]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [15]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [16]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [17]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [18]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [19]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [20]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [21]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [22]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [23]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [24]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [25]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [26]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [27]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [28]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [29]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [30]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [31]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [32]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [33]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [34]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [35]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"3\"", -- [1]
			0, -- [2]
		}, -- [36]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [37]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-7-16\"", -- [1]
			0, -- [2]
		}, -- [38]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [39]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [40]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [41]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [42]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [43]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [44]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [45]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [46]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [47]
		{
			"[GlueLogin] Explicitly disconnecting from realm server", -- [1]
			0, -- [2]
		}, -- [48]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [49]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [50]
		{
			"[GlueLogin] Disconnected from WoWpreviouslyConnected=\"false\"", -- [1]
			0, -- [2]
		}, -- [51]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [52]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [53]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [54]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [55]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [56]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [57]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [58]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [59]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [60]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [61]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [62]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [63]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [64]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [65]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [66]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [67]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [68]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [69]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [70]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [71]
		{
			"Shadow texture size changed to 512.", -- [1]
			0, -- [2]
		}, -- [72]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [73]
		{
			"SSAO mode set to 0", -- [1]
			0, -- [2]
		}, -- [74]
		{
			"Depth Based Opacity Disabled", -- [1]
			0, -- [2]
		}, -- [75]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [76]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [77]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [78]
		{
			"Outline mode changed to 0", -- [1]
			0, -- [2]
		}, -- [79]
		{
			"LightBuffer mode changed to 0", -- [1]
			0, -- [2]
		}, -- [80]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [81]
		{
			"Render scale changed to 0.4", -- [1]
			0, -- [2]
		}, -- [82]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [83]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [84]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [85]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [86]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [87]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [88]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [89]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [90]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [91]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [92]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [93]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [94]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [95]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [96]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [97]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [98]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [99]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [100]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [101]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [102]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [103]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [104]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [105]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [106]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [107]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [108]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [109]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [110]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [111]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [112]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [113]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [114]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [115]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"3\"", -- [1]
			0, -- [2]
		}, -- [116]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [117]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-7-16\"", -- [1]
			0, -- [2]
		}, -- [118]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [119]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [120]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [121]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [122]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [123]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [124]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [125]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [126]
		{
			"[IBN_Login] Requesting change realm list", -- [1]
			0, -- [2]
		}, -- [127]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [128]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [129]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [130]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [131]
		{
			"[IBN_Login] Requesting realm listsnumSubRegions=\"3\"", -- [1]
			0, -- [2]
		}, -- [132]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [133]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-11-16\"", -- [1]
			0, -- [2]
		}, -- [134]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [135]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [136]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [137]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [138]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [139]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [140]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [141]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [142]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [143]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [144]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [145]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [146]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [147]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [148]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [149]
		{
			"Proficiency in item class 2 set to 0x0000104081", -- [1]
			0, -- [2]
		}, -- [150]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [151]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [152]
		{
			"Proficiency in item class 2 set to 0x0000106081", -- [1]
			0, -- [2]
		}, -- [153]
		{
			"Proficiency in item class 2 set to 0x0000106281", -- [1]
			0, -- [2]
		}, -- [154]
		{
			"Proficiency in item class 2 set to 0x0000106281", -- [1]
			0, -- [2]
		}, -- [155]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [156]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [157]
		{
			"Time set to 3/24/2019 (Sun) 9:41", -- [1]
			0, -- [2]
		}, -- [158]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [159]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [160]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [161]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [162]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [163]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [164]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [165]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [166]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [167]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [168]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [169]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [170]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [171]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [172]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [173]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [174]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [175]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [176]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [177]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [178]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [179]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [180]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [181]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [182]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [183]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [184]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [185]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [186]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [187]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [188]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [189]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [190]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [191]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [192]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [193]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [194]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [195]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [196]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [197]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [198]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [199]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [200]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [201]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [202]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [203]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [204]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [205]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [206]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [207]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [208]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [209]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [210]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [211]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [212]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [213]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [214]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [215]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [216]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [217]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [218]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [219]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [220]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [221]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [222]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [223]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [224]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [225]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [226]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [227]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [228]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [229]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [230]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [231]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [232]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [233]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [234]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [235]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [236]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [237]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [238]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [239]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [240]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [241]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [242]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [243]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [244]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [245]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [246]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [247]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [248]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [249]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [250]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [251]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [252]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [253]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [254]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [255]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [256]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [257]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [258]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [259]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [260]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [261]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [262]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [263]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [264]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [265]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [266]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [267]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [268]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [269]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [270]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [271]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [272]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [273]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [274]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [275]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [276]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [277]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [278]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [279]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [280]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [281]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [282]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [283]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [284]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [285]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [286]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [287]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [288]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [289]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [290]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [291]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [292]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [293]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [294]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [295]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [296]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [297]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [298]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [299]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [300]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [301]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [302]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [303]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [304]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [305]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [306]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [307]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [308]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [309]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [310]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [311]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [312]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [313]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [314]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [315]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [316]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [317]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [318]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [319]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [320]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [321]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [322]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [323]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [324]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [325]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [326]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [327]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [328]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [329]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [330]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [331]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [332]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [333]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [334]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [335]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [336]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [337]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [338]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [339]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [340]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [341]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [342]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [343]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [344]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [345]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [346]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [347]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [348]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [349]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [350]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [351]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [352]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [353]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [354]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [355]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [356]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [357]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [358]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [359]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [360]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [361]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [362]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [363]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [364]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [365]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [366]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [367]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [368]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [369]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [370]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [371]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [372]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [373]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [374]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [375]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [376]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [377]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [378]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [379]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [380]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [381]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [382]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [383]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [384]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [385]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [386]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [387]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [388]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [389]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [390]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [391]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [392]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [393]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [394]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [395]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [396]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [397]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [398]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [399]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [400]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [401]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [402]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [403]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [404]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [405]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [406]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [407]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [408]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [409]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [410]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [411]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [412]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [413]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [414]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [415]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [416]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [417]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [418]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [419]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [420]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [421]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [422]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [423]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [424]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [425]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [426]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [427]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [428]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [429]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [430]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [431]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [432]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [433]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [434]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [435]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [436]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [437]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [438]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [439]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [440]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [441]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [442]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [443]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [444]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [445]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [446]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [447]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [448]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [449]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [450]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [451]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [452]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [453]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [454]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [455]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [456]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [457]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [458]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [459]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [460]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [461]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [462]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [463]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [464]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [465]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [466]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [467]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [468]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [469]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [470]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [471]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [472]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [473]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [474]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [475]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [476]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [477]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [478]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [479]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [480]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [481]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [482]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [483]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [484]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [485]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [486]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [487]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [488]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [489]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [490]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [491]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [492]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [493]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [494]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [495]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [496]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [497]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [498]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [499]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [500]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [501]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [502]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [503]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [504]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [505]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [506]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [507]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [508]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [509]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [510]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [511]
		{
			"[IBN_Login] Requesting change realm list", -- [1]
			0, -- [2]
		}, -- [512]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [513]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [514]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [515]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [516]
		{
			"[IBN_Login] Requesting realm listsnumSubRegions=\"3\"", -- [1]
			0, -- [2]
		}, -- [517]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [518]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-1-30\"", -- [1]
			0, -- [2]
		}, -- [519]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [520]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [521]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [522]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [523]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [524]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [525]
		{
			"[IBN_Login] Requesting change realm list", -- [1]
			0, -- [2]
		}, -- [526]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [527]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [528]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [529]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [530]
		{
			"[IBN_Login] Requesting realm listsnumSubRegions=\"3\"", -- [1]
			0, -- [2]
		}, -- [531]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [532]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-7-16\"", -- [1]
			0, -- [2]
		}, -- [533]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [534]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [535]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [536]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [537]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [538]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [539]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [540]
		{
			"[GlueLogin] Explicitly disconnecting from realm server", -- [1]
			0, -- [2]
		}, -- [541]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [542]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [543]
		{
			"[GlueLogin] Disconnected from WoWpreviouslyConnected=\"false\"", -- [1]
			0, -- [2]
		}, -- [544]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [545]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [546]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [547]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [548]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [549]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [550]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [551]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [552]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [553]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [554]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [555]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [556]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [557]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [558]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [559]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [560]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [561]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [562]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [563]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [564]
		{
			"Shadow texture size changed to 512.", -- [1]
			0, -- [2]
		}, -- [565]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [566]
		{
			"SSAO mode set to 0", -- [1]
			0, -- [2]
		}, -- [567]
		{
			"Depth Based Opacity Disabled", -- [1]
			0, -- [2]
		}, -- [568]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [569]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [570]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [571]
		{
			"Outline mode changed to 0", -- [1]
			0, -- [2]
		}, -- [572]
		{
			"LightBuffer mode changed to 0", -- [1]
			0, -- [2]
		}, -- [573]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [574]
		{
			"Render scale changed to 0.4", -- [1]
			0, -- [2]
		}, -- [575]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [576]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [577]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [578]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [579]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [580]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [581]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [582]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [583]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [584]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [585]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [586]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [587]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [588]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [589]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [590]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [591]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [592]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [593]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [594]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [595]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [596]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [597]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [598]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [599]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [600]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [601]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [602]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [603]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [604]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [605]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [606]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [607]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [608]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"3\"", -- [1]
			0, -- [2]
		}, -- [609]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [610]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-1-30\"", -- [1]
			0, -- [2]
		}, -- [611]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [612]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [613]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [614]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [615]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [616]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [617]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [618]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [619]
		{
			"[IBN_Login] Requesting change realm list", -- [1]
			0, -- [2]
		}, -- [620]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [621]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [622]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [623]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [624]
		{
			"[IBN_Login] Requesting realm listsnumSubRegions=\"3\"", -- [1]
			0, -- [2]
		}, -- [625]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [626]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-7-16\"", -- [1]
			0, -- [2]
		}, -- [627]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [628]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [629]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [630]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [631]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [632]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [633]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [634]
		{
			"[IBN_Login] Requesting change realm list", -- [1]
			0, -- [2]
		}, -- [635]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [636]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [637]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [638]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [639]
		{
			"[IBN_Login] Requesting realm listsnumSubRegions=\"3\"", -- [1]
			0, -- [2]
		}, -- [640]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [641]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-7-16\"", -- [1]
			0, -- [2]
		}, -- [642]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [643]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [644]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [645]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [646]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [647]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [648]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [649]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [650]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [651]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [652]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [653]
		{
			"Proficiency in item class 2 set to 0x0000000010", -- [1]
			0, -- [2]
		}, -- [654]
		{
			"Proficiency in item class 2 set to 0x0000000410", -- [1]
			0, -- [2]
		}, -- [655]
		{
			"Proficiency in item class 2 set to 0x0000008410", -- [1]
			0, -- [2]
		}, -- [656]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [657]
		{
			"Proficiency in item class 2 set to 0x000000c410", -- [1]
			0, -- [2]
		}, -- [658]
		{
			"Proficiency in item class 2 set to 0x000008c410", -- [1]
			0, -- [2]
		}, -- [659]
		{
			"Proficiency in item class 2 set to 0x000018c410", -- [1]
			0, -- [2]
		}, -- [660]
		{
			"Proficiency in item class 4 set to 0x0000000023", -- [1]
			0, -- [2]
		}, -- [661]
		{
			"Proficiency in item class 2 set to 0x000018c410", -- [1]
			0, -- [2]
		}, -- [662]
		{
			"Proficiency in item class 4 set to 0x0000000023", -- [1]
			0, -- [2]
		}, -- [663]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [664]
		{
			"Time set to 3/24/2019 (Sun) 9:58", -- [1]
			0, -- [2]
		}, -- [665]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [666]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [667]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [668]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [669]
		{
			"[GlueLogin] Disconnected from WoWpreviouslyConnected=\"true\"", -- [1]
			0, -- [2]
		}, -- [670]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [671]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [672]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [673]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [674]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [675]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [676]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [677]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [678]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [679]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [680]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [681]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [682]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [683]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [684]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [685]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [686]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [687]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [688]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [689]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [690]
		{
			"Shadow texture size changed to 512.", -- [1]
			0, -- [2]
		}, -- [691]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [692]
		{
			"SSAO mode set to 0", -- [1]
			0, -- [2]
		}, -- [693]
		{
			"Depth Based Opacity Disabled", -- [1]
			0, -- [2]
		}, -- [694]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [695]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [696]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [697]
		{
			"Outline mode changed to 0", -- [1]
			0, -- [2]
		}, -- [698]
		{
			"LightBuffer mode changed to 0", -- [1]
			0, -- [2]
		}, -- [699]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [700]
		{
			"Render scale changed to 0.4", -- [1]
			0, -- [2]
		}, -- [701]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [702]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [703]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [704]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [705]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [706]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [707]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [708]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [709]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [710]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [711]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [712]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [713]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [714]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [715]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [716]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [717]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [718]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [719]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [720]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [721]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [722]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [723]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [724]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [725]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [726]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [727]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [728]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [729]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [730]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [731]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [732]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [733]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [734]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"3\"", -- [1]
			0, -- [2]
		}, -- [735]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [736]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-7-16\"", -- [1]
			0, -- [2]
		}, -- [737]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [738]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [739]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [740]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [741]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [742]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [743]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [744]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [745]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [746]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [747]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [748]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [749]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [750]
		{
			"Proficiency in item class 2 set to 0x000018c410", -- [1]
			0, -- [2]
		}, -- [751]
		{
			"Proficiency in item class 4 set to 0x0000000023", -- [1]
			0, -- [2]
		}, -- [752]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [753]
		{
			"Time set to 3/24/2019 (Sun) 10:00", -- [1]
			0, -- [2]
		}, -- [754]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [755]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [756]
		{
			"Failed to set SpellClutter callback on graphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [757]
		{
			"Failed to set SpellClutter callback on RAIDgraphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [758]
		{
			"Weather changed to 2, intensity 0.750000\n", -- [1]
			0, -- [2]
		}, -- [759]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [760]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [761]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [762]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [763]
		{
			"[IBN_Login] Requesting change realm list", -- [1]
			0, -- [2]
		}, -- [764]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [765]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [766]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [767]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [768]
		{
			"[IBN_Login] Requesting realm listsnumSubRegions=\"3\"", -- [1]
			0, -- [2]
		}, -- [769]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [770]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-1-30\"", -- [1]
			0, -- [2]
		}, -- [771]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [772]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [773]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [774]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [775]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [776]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [777]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [778]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [779]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [780]
		{
			"Failed to set SpellClutter callback on graphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [781]
		{
			"Failed to set SpellClutter callback on RAIDgraphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [782]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [783]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [784]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [785]
		{
			"Proficiency in item class 2 set to 0x0000000091", -- [1]
			0, -- [2]
		}, -- [786]
		{
			"Proficiency in item class 2 set to 0x0000000191", -- [1]
			0, -- [2]
		}, -- [787]
		{
			"Proficiency in item class 2 set to 0x00000001b1", -- [1]
			0, -- [2]
		}, -- [788]
		{
			"Proficiency in item class 2 set to 0x00000001b3", -- [1]
			0, -- [2]
		}, -- [789]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [790]
		{
			"Proficiency in item class 2 set to 0x00000041b3", -- [1]
			0, -- [2]
		}, -- [791]
		{
			"Proficiency in item class 2 set to 0x00000041f3", -- [1]
			0, -- [2]
		}, -- [792]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [793]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [794]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [795]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [796]
		{
			"Proficiency in item class 2 set to 0x00000041f3", -- [1]
			0, -- [2]
		}, -- [797]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [798]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [799]
		{
			"Time set to 3/24/2019 (Sun) 10:14", -- [1]
			0, -- [2]
		}, -- [800]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [801]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [802]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [803]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [804]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [805]
		{
			"Failed to set SpellClutter callback on graphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [806]
		{
			"Failed to set SpellClutter callback on RAIDgraphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [807]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [808]
		{
			"Proficiency in item class 2 set to 0x0000000010", -- [1]
			0, -- [2]
		}, -- [809]
		{
			"Proficiency in item class 2 set to 0x0000000410", -- [1]
			0, -- [2]
		}, -- [810]
		{
			"Proficiency in item class 2 set to 0x0000000430", -- [1]
			0, -- [2]
		}, -- [811]
		{
			"Proficiency in item class 2 set to 0x0000008430", -- [1]
			0, -- [2]
		}, -- [812]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [813]
		{
			"Proficiency in item class 2 set to 0x000000c430", -- [1]
			0, -- [2]
		}, -- [814]
		{
			"Proficiency in item class 2 set to 0x000000c470", -- [1]
			0, -- [2]
		}, -- [815]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [816]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [817]
		{
			"Proficiency in item class 2 set to 0x000000e470", -- [1]
			0, -- [2]
		}, -- [818]
		{
			"Proficiency in item class 2 set to 0x000000e470", -- [1]
			0, -- [2]
		}, -- [819]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [820]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [821]
		{
			"Time set to 3/24/2019 (Sun) 10:14", -- [1]
			0, -- [2]
		}, -- [822]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [823]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [824]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [825]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [826]
		{
			"Weather changed to 2, intensity 0.088995\n", -- [1]
			0, -- [2]
		}, -- [827]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [828]
		{
			"Weather changed to 2, intensity 0.088995\n", -- [1]
			0, -- [2]
		}, -- [829]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [830]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [831]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [832]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [833]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [834]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [835]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [836]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [837]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [838]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [839]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [840]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [841]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [842]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [843]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [844]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [845]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [846]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [847]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [848]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [849]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [850]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [851]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [852]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [853]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [854]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [855]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [856]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [857]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [858]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [859]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [860]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [861]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [862]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [863]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [864]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [865]
		{
			"Changed difficulty successfully", -- [1]
			0, -- [2]
		}, -- [866]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [867]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [868]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [869]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [870]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [871]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [872]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [873]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [874]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [875]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [876]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [877]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [878]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [879]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [880]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [881]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [882]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [883]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [884]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [885]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [886]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [887]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [888]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [889]
		{
			"Modifier not supported on client (type=174, asset=54404, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [890]
		{
			"Modifier not supported on client (type=174, asset=54310, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.", -- [1]
			3, -- [2]
		}, -- [891]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [892]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [893]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [894]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [895]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [896]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [897]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [898]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [899]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [900]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [901]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [902]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [903]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [904]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [905]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [906]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [907]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [908]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [909]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [910]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [911]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [912]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [913]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [914]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [915]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [916]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [917]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [918]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [919]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [920]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [921]
		{
			"Shadow texture size changed to 512.", -- [1]
			0, -- [2]
		}, -- [922]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [923]
		{
			"SSAO mode set to 0", -- [1]
			0, -- [2]
		}, -- [924]
		{
			"Depth Based Opacity Disabled", -- [1]
			0, -- [2]
		}, -- [925]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [926]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [927]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [928]
		{
			"Outline mode changed to 0", -- [1]
			0, -- [2]
		}, -- [929]
		{
			"LightBuffer mode changed to 0", -- [1]
			0, -- [2]
		}, -- [930]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [931]
		{
			"Render scale changed to 0.4", -- [1]
			0, -- [2]
		}, -- [932]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [933]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [934]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [935]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [936]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [937]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [938]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [939]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [940]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [941]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [942]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [943]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [944]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [945]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [946]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [947]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [948]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [949]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [950]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [951]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [952]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [953]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [954]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [955]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [956]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [957]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [958]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [959]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [960]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [961]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [962]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [963]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [964]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [965]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"3\"", -- [1]
			0, -- [2]
		}, -- [966]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [967]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-1-30\"", -- [1]
			0, -- [2]
		}, -- [968]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [969]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [970]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [971]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [972]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [973]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [974]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [975]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [976]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [977]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [978]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [979]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [980]
		{
			"Proficiency in item class 2 set to 0x0000000010", -- [1]
			0, -- [2]
		}, -- [981]
		{
			"Proficiency in item class 2 set to 0x0000000410", -- [1]
			0, -- [2]
		}, -- [982]
		{
			"Proficiency in item class 2 set to 0x0000000430", -- [1]
			0, -- [2]
		}, -- [983]
		{
			"Proficiency in item class 2 set to 0x0000008430", -- [1]
			0, -- [2]
		}, -- [984]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [985]
		{
			"Proficiency in item class 2 set to 0x000000c430", -- [1]
			0, -- [2]
		}, -- [986]
		{
			"Proficiency in item class 2 set to 0x000000c470", -- [1]
			0, -- [2]
		}, -- [987]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [988]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [989]
		{
			"Proficiency in item class 2 set to 0x000000e470", -- [1]
			0, -- [2]
		}, -- [990]
		{
			"Proficiency in item class 2 set to 0x000000e470", -- [1]
			0, -- [2]
		}, -- [991]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [992]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [993]
		{
			"Time set to 3/24/2019 (Sun) 18:45", -- [1]
			0, -- [2]
		}, -- [994]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [995]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [996]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [997]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [998]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [999]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [1000]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [1001]
	},
	["isShown"] = false,
	["fontHeight"] = 14,
	["commandHistory"] = {
	},
}
