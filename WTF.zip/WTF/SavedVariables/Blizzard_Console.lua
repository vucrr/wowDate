
Blizzard_Console_SavedVars = {
	["version"] = 3,
	["messageHistory"] = {
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [1]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [2]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [3]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [4]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [5]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [6]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [7]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [8]
		{
			"Proficiency in item class 2 set to 0x000004e5ff", -- [1]
			0, -- [2]
		}, -- [9]
		{
			"Proficiency in item class 2 set to 0x000004e5ff", -- [1]
			0, -- [2]
		}, -- [10]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [11]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [12]
		{
			"Time set to 1/13/2019 (Sun) 21:12", -- [1]
			0, -- [2]
		}, -- [13]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [14]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [15]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [16]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [17]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [18]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [19]
		{
			"[IBN_Login] Requesting change realm list", -- [1]
			0, -- [2]
		}, -- [20]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [21]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [22]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [23]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [24]
		{
			"[IBN_Login] Requesting realm listsnumSubRegions=\"2\"", -- [1]
			0, -- [2]
		}, -- [25]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [26]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-11-16\"", -- [1]
			0, -- [2]
		}, -- [27]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [28]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [29]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [30]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [31]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [32]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [33]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [34]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [35]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [36]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [37]
		{
			"Failed to set SpellClutter callback on graphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [38]
		{
			"Failed to set SpellClutter callback on RAIDgraphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [39]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [40]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [41]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [42]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [43]
		{
			"Proficiency in item class 2 set to 0x0000004081", -- [1]
			0, -- [2]
		}, -- [44]
		{
			"Proficiency in item class 2 set to 0x0000104081", -- [1]
			0, -- [2]
		}, -- [45]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [46]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [47]
		{
			"Proficiency in item class 2 set to 0x0000106081", -- [1]
			0, -- [2]
		}, -- [48]
		{
			"Proficiency in item class 2 set to 0x0000106281", -- [1]
			0, -- [2]
		}, -- [49]
		{
			"Proficiency in item class 2 set to 0x0000106281", -- [1]
			0, -- [2]
		}, -- [50]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [51]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [52]
		{
			"Time set to 1/13/2019 (Sun) 21:14", -- [1]
			0, -- [2]
		}, -- [53]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [54]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [55]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [56]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [57]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [58]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [59]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [60]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [61]
		{
			"Failed to set SpellClutter callback on graphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [62]
		{
			"Failed to set SpellClutter callback on RAIDgraphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [63]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [64]
		{
			"Proficiency in item class 2 set to 0x0000000010", -- [1]
			0, -- [2]
		}, -- [65]
		{
			"Proficiency in item class 2 set to 0x0000000410", -- [1]
			0, -- [2]
		}, -- [66]
		{
			"Proficiency in item class 2 set to 0x0000000430", -- [1]
			0, -- [2]
		}, -- [67]
		{
			"Proficiency in item class 2 set to 0x0000008430", -- [1]
			0, -- [2]
		}, -- [68]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [69]
		{
			"Proficiency in item class 2 set to 0x000000c430", -- [1]
			0, -- [2]
		}, -- [70]
		{
			"Proficiency in item class 2 set to 0x000000c470", -- [1]
			0, -- [2]
		}, -- [71]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [72]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [73]
		{
			"Proficiency in item class 2 set to 0x000000e470", -- [1]
			0, -- [2]
		}, -- [74]
		{
			"Proficiency in item class 2 set to 0x000000e470", -- [1]
			0, -- [2]
		}, -- [75]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [76]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [77]
		{
			"Time set to 1/13/2019 (Sun) 21:25", -- [1]
			0, -- [2]
		}, -- [78]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [79]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [80]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [81]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [82]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [83]
		{
			"Failed to set SpellClutter callback on graphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [84]
		{
			"Failed to set SpellClutter callback on RAIDgraphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [85]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [86]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [87]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [88]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [89]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [90]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [91]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [92]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [93]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [94]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [95]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [96]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [97]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [98]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [99]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [100]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [101]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [102]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [103]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [104]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [105]
		{
			"Proficiency in item class 2 set to 0x000004e5ff", -- [1]
			0, -- [2]
		}, -- [106]
		{
			"Proficiency in item class 2 set to 0x000004e5ff", -- [1]
			0, -- [2]
		}, -- [107]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [108]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [109]
		{
			"Time set to 1/13/2019 (Sun) 21:26", -- [1]
			0, -- [2]
		}, -- [110]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [111]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [112]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [113]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [114]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [115]
		{
			"Failed to set SpellClutter callback on graphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [116]
		{
			"Failed to set SpellClutter callback on RAIDgraphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [117]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [118]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [119]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [120]
		{
			"Proficiency in item class 2 set to 0x0000000091", -- [1]
			0, -- [2]
		}, -- [121]
		{
			"Proficiency in item class 2 set to 0x0000000191", -- [1]
			0, -- [2]
		}, -- [122]
		{
			"Proficiency in item class 2 set to 0x00000001b1", -- [1]
			0, -- [2]
		}, -- [123]
		{
			"Proficiency in item class 2 set to 0x00000001b3", -- [1]
			0, -- [2]
		}, -- [124]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [125]
		{
			"Proficiency in item class 2 set to 0x00000041b3", -- [1]
			0, -- [2]
		}, -- [126]
		{
			"Proficiency in item class 2 set to 0x00000041f3", -- [1]
			0, -- [2]
		}, -- [127]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [128]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [129]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [130]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [131]
		{
			"Proficiency in item class 2 set to 0x00000041f3", -- [1]
			0, -- [2]
		}, -- [132]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [133]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [134]
		{
			"Time set to 1/13/2019 (Sun) 21:27", -- [1]
			0, -- [2]
		}, -- [135]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [136]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [137]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [138]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [139]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [140]
		{
			"Failed to set SpellClutter callback on graphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [141]
		{
			"Failed to set SpellClutter callback on RAIDgraphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [142]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [143]
		{
			"Proficiency in item class 2 set to 0x0000000010", -- [1]
			0, -- [2]
		}, -- [144]
		{
			"Proficiency in item class 2 set to 0x0000000410", -- [1]
			0, -- [2]
		}, -- [145]
		{
			"Proficiency in item class 2 set to 0x0000000430", -- [1]
			0, -- [2]
		}, -- [146]
		{
			"Proficiency in item class 2 set to 0x0000008430", -- [1]
			0, -- [2]
		}, -- [147]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [148]
		{
			"Proficiency in item class 2 set to 0x000000c430", -- [1]
			0, -- [2]
		}, -- [149]
		{
			"Proficiency in item class 2 set to 0x000000c470", -- [1]
			0, -- [2]
		}, -- [150]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [151]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [152]
		{
			"Proficiency in item class 2 set to 0x000000e470", -- [1]
			0, -- [2]
		}, -- [153]
		{
			"Proficiency in item class 2 set to 0x000000e470", -- [1]
			0, -- [2]
		}, -- [154]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [155]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [156]
		{
			"Time set to 1/13/2019 (Sun) 21:27", -- [1]
			0, -- [2]
		}, -- [157]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [158]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [159]
		{
			"[IBN_Login] Requesting change realm list", -- [1]
			0, -- [2]
		}, -- [160]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [161]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [162]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [163]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [164]
		{
			"[IBN_Login] Requesting realm listsnumSubRegions=\"2\"", -- [1]
			0, -- [2]
		}, -- [165]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [166]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-1-30\"", -- [1]
			0, -- [2]
		}, -- [167]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [168]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [169]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [170]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [171]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [172]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [173]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [174]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [175]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [176]
		{
			"Failed to set SpellClutter callback on graphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [177]
		{
			"Failed to set SpellClutter callback on RAIDgraphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [178]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [179]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [180]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [181]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [182]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [183]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [184]
		{
			"Proficiency in item class 2 set to 0x000000809d", -- [1]
			0, -- [2]
		}, -- [185]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [186]
		{
			"Proficiency in item class 2 set to 0x000000c09d", -- [1]
			0, -- [2]
		}, -- [187]
		{
			"Proficiency in item class 2 set to 0x000004c09d", -- [1]
			0, -- [2]
		}, -- [188]
		{
			"Proficiency in item class 2 set to 0x000014c09d", -- [1]
			0, -- [2]
		}, -- [189]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [190]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [191]
		{
			"Proficiency in item class 2 set to 0x000014e09d", -- [1]
			0, -- [2]
		}, -- [192]
		{
			"Proficiency in item class 2 set to 0x000014e09d", -- [1]
			0, -- [2]
		}, -- [193]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [194]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [195]
		{
			"Time set to 1/13/2019 (Sun) 21:30", -- [1]
			0, -- [2]
		}, -- [196]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [197]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [198]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [199]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [200]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [201]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [202]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [203]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [204]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [205]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [206]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [207]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [208]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [209]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [210]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [211]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [212]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [213]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [214]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [215]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [216]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [217]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [218]
		{
			"Shadow texture size changed to 512.", -- [1]
			0, -- [2]
		}, -- [219]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [220]
		{
			"SSAO mode set to 0", -- [1]
			0, -- [2]
		}, -- [221]
		{
			"Depth Based Opacity Disabled", -- [1]
			0, -- [2]
		}, -- [222]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [223]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [224]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [225]
		{
			"Outline mode changed to 0", -- [1]
			0, -- [2]
		}, -- [226]
		{
			"LightBuffer mode changed to 0", -- [1]
			0, -- [2]
		}, -- [227]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [228]
		{
			"Render scale changed to 0.4", -- [1]
			0, -- [2]
		}, -- [229]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [230]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [231]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [232]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [233]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [234]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [235]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [236]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [237]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [238]
		{
			"FFX: Anti Aliasing Mode set to FXAA - Quality Level 0", -- [1]
			0, -- [2]
		}, -- [239]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [240]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [241]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [242]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [243]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [244]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [245]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [246]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [247]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [248]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [249]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [250]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [251]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [252]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [253]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [254]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [255]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [256]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [257]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [258]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [259]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [260]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [261]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [262]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [263]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"2\"", -- [1]
			0, -- [2]
		}, -- [264]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [265]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-1-30\"", -- [1]
			0, -- [2]
		}, -- [266]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [267]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [268]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [269]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [270]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [271]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [272]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [273]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [274]
		{
			"[IBN_Login] Requesting change realm list", -- [1]
			0, -- [2]
		}, -- [275]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [276]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [277]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [278]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [279]
		{
			"[IBN_Login] Requesting realm listsnumSubRegions=\"2\"", -- [1]
			0, -- [2]
		}, -- [280]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [281]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-4-43\"", -- [1]
			0, -- [2]
		}, -- [282]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [283]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [284]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [285]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [286]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [287]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [288]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [289]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [290]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [291]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [292]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [293]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [294]
		{
			"Proficiency in item class 2 set to 0x0000000480", -- [1]
			0, -- [2]
		}, -- [295]
		{
			"Proficiency in item class 2 set to 0x0000008480", -- [1]
			0, -- [2]
		}, -- [296]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [297]
		{
			"Proficiency in item class 2 set to 0x000000c480", -- [1]
			0, -- [2]
		}, -- [298]
		{
			"Proficiency in item class 2 set to 0x000008c480", -- [1]
			0, -- [2]
		}, -- [299]
		{
			"Proficiency in item class 2 set to 0x000018c480", -- [1]
			0, -- [2]
		}, -- [300]
		{
			"Proficiency in item class 4 set to 0x0000000023", -- [1]
			0, -- [2]
		}, -- [301]
		{
			"Proficiency in item class 2 set to 0x000018c480", -- [1]
			0, -- [2]
		}, -- [302]
		{
			"Proficiency in item class 4 set to 0x0000000023", -- [1]
			0, -- [2]
		}, -- [303]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [304]
		{
			"Time set to 1/13/2019 (Sun) 21:49", -- [1]
			0, -- [2]
		}, -- [305]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [306]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [307]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [308]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [309]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [310]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [311]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [312]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [313]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [314]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [315]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [316]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [317]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [318]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [319]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [320]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [321]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [322]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [323]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [324]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [325]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [326]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [327]
		{
			"Shadow texture size changed to 512.", -- [1]
			0, -- [2]
		}, -- [328]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [329]
		{
			"SSAO mode set to 0", -- [1]
			0, -- [2]
		}, -- [330]
		{
			"Depth Based Opacity Disabled", -- [1]
			0, -- [2]
		}, -- [331]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [332]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [333]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [334]
		{
			"Outline mode changed to 0", -- [1]
			0, -- [2]
		}, -- [335]
		{
			"LightBuffer mode changed to 0", -- [1]
			0, -- [2]
		}, -- [336]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [337]
		{
			"Render scale changed to 0.4", -- [1]
			0, -- [2]
		}, -- [338]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [339]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [340]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [341]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [342]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [343]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [344]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [345]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [346]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [347]
		{
			"FFX: Anti Aliasing Mode set to FXAA - Quality Level 0", -- [1]
			0, -- [2]
		}, -- [348]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [349]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [350]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [351]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [352]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [353]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [354]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [355]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [356]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [357]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [358]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [359]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [360]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [361]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [362]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [363]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [364]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [365]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [366]
		{
			"[GlueLogin] Fatal error while logging inresult=\"( code=\"ERROR_GAME_ACCOUNT_BANNED (52)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [367]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [368]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [369]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [370]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [371]
		{
			"[IBN_Login] DestroyingisInitialized=\"true\"", -- [1]
			0, -- [2]
		}, -- [372]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [373]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [374]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [375]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [376]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [377]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [378]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [379]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [380]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [381]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [382]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [383]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [384]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [385]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [386]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [387]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [388]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [389]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [390]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [391]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [392]
		{
			"Shadow texture size changed to 512.", -- [1]
			0, -- [2]
		}, -- [393]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [394]
		{
			"SSAO mode set to 0", -- [1]
			0, -- [2]
		}, -- [395]
		{
			"Depth Based Opacity Disabled", -- [1]
			0, -- [2]
		}, -- [396]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [397]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [398]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [399]
		{
			"Outline mode changed to 0", -- [1]
			0, -- [2]
		}, -- [400]
		{
			"LightBuffer mode changed to 0", -- [1]
			0, -- [2]
		}, -- [401]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [402]
		{
			"Render scale changed to 0.4", -- [1]
			0, -- [2]
		}, -- [403]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [404]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [405]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [406]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [407]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [408]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [409]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [410]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [411]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [412]
		{
			"FFX: Anti Aliasing Mode set to FXAA - Quality Level 0", -- [1]
			0, -- [2]
		}, -- [413]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [414]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [415]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [416]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [417]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [418]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [419]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [420]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [421]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [422]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [423]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [424]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [425]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [426]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [427]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [428]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [429]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [430]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [431]
		{
			"[GlueLogin] Fatal error while logging inresult=\"( code=\"ERROR_GAME_ACCOUNT_BANNED (52)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [432]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [433]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [434]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [435]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [436]
		{
			"[IBN_Login] DestroyingisInitialized=\"true\"", -- [1]
			0, -- [2]
		}, -- [437]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [438]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [439]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [440]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [441]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [442]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [443]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [444]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [445]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [446]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [447]
		{
			"[GlueLogin] Fatal error while logging inresult=\"( code=\"ERROR_GAME_ACCOUNT_BANNED (52)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [448]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"2\"", -- [1]
			0, -- [2]
		}, -- [449]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [450]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"2\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [451]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [452]
		{
			"[IBN_Login] DestroyingisInitialized=\"true\"", -- [1]
			0, -- [2]
		}, -- [453]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [454]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [455]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [456]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [457]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [458]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [459]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [460]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [461]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [462]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [463]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [464]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [465]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [466]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [467]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [468]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [469]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [470]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [471]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [472]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [473]
		{
			"Shadow texture size changed to 512.", -- [1]
			0, -- [2]
		}, -- [474]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [475]
		{
			"SSAO mode set to 0", -- [1]
			0, -- [2]
		}, -- [476]
		{
			"Depth Based Opacity Disabled", -- [1]
			0, -- [2]
		}, -- [477]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [478]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [479]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [480]
		{
			"Outline mode changed to 0", -- [1]
			0, -- [2]
		}, -- [481]
		{
			"LightBuffer mode changed to 0", -- [1]
			0, -- [2]
		}, -- [482]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [483]
		{
			"Render scale changed to 0.4", -- [1]
			0, -- [2]
		}, -- [484]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [485]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [486]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [487]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [488]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [489]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [490]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [491]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [492]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [493]
		{
			"FFX: Anti Aliasing Mode set to FXAA - Quality Level 0", -- [1]
			0, -- [2]
		}, -- [494]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [495]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [496]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [497]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [498]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [499]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [500]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [501]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [502]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [503]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [504]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [505]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [506]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [507]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [508]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [509]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [510]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [511]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [512]
		{
			"[GlueLogin] Fatal error while logging inresult=\"( code=\"ERROR_GAME_ACCOUNT_BANNED (52)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [513]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [514]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [515]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [516]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [517]
		{
			"[IBN_Login] DestroyingisInitialized=\"true\"", -- [1]
			0, -- [2]
		}, -- [518]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [519]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [520]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [521]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [522]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [523]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [524]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [525]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [526]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [527]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [528]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [529]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [530]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [531]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [532]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [533]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [534]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [535]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [536]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [537]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [538]
		{
			"Shadow texture size changed to 512.", -- [1]
			0, -- [2]
		}, -- [539]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [540]
		{
			"SSAO mode set to 0", -- [1]
			0, -- [2]
		}, -- [541]
		{
			"Depth Based Opacity Disabled", -- [1]
			0, -- [2]
		}, -- [542]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [543]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [544]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [545]
		{
			"Outline mode changed to 0", -- [1]
			0, -- [2]
		}, -- [546]
		{
			"LightBuffer mode changed to 0", -- [1]
			0, -- [2]
		}, -- [547]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [548]
		{
			"Render scale changed to 0.4", -- [1]
			0, -- [2]
		}, -- [549]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [550]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [551]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [552]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [553]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [554]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [555]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [556]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [557]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [558]
		{
			"FFX: Anti Aliasing Mode set to FXAA - Quality Level 0", -- [1]
			0, -- [2]
		}, -- [559]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [560]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [561]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [562]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [563]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [564]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [565]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [566]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [567]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [568]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [569]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [570]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [571]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [572]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [573]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [574]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [575]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [576]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [577]
		{
			"[GlueLogin] Fatal error while logging inresult=\"( code=\"ERROR_GAME_ACCOUNT_BANNED (52)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [578]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [579]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [580]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [581]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [582]
		{
			"[IBN_Login] DestroyingisInitialized=\"true\"", -- [1]
			0, -- [2]
		}, -- [583]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [584]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [585]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [586]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [587]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [588]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [589]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [590]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [591]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [592]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [593]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [594]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [595]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [596]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [597]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [598]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [599]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [600]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [601]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [602]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [603]
		{
			"Shadow texture size changed to 512.", -- [1]
			0, -- [2]
		}, -- [604]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [605]
		{
			"SSAO mode set to 0", -- [1]
			0, -- [2]
		}, -- [606]
		{
			"Depth Based Opacity Disabled", -- [1]
			0, -- [2]
		}, -- [607]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [608]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [609]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [610]
		{
			"Outline mode changed to 0", -- [1]
			0, -- [2]
		}, -- [611]
		{
			"LightBuffer mode changed to 0", -- [1]
			0, -- [2]
		}, -- [612]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [613]
		{
			"Render scale changed to 0.4", -- [1]
			0, -- [2]
		}, -- [614]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [615]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [616]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [617]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [618]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [619]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [620]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [621]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [622]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [623]
		{
			"FFX: Anti Aliasing Mode set to FXAA - Quality Level 0", -- [1]
			0, -- [2]
		}, -- [624]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [625]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [626]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [627]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [628]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [629]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [630]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [631]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [632]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [633]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [634]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [635]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [636]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [637]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [638]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [639]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [640]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [641]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [642]
		{
			"[GlueLogin] Fatal error while logging inresult=\"( code=\"ERROR_GAME_ACCOUNT_BANNED (52)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [643]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [644]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [645]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [646]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [647]
		{
			"[IBN_Login] DestroyingisInitialized=\"true\"", -- [1]
			0, -- [2]
		}, -- [648]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [649]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [650]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [651]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [652]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [653]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [654]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [655]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [656]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [657]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [658]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [659]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [660]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [661]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [662]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [663]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [664]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [665]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [666]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [667]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [668]
		{
			"Shadow texture size changed to 512.", -- [1]
			0, -- [2]
		}, -- [669]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [670]
		{
			"SSAO mode set to 0", -- [1]
			0, -- [2]
		}, -- [671]
		{
			"Depth Based Opacity Disabled", -- [1]
			0, -- [2]
		}, -- [672]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [673]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [674]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [675]
		{
			"Outline mode changed to 0", -- [1]
			0, -- [2]
		}, -- [676]
		{
			"LightBuffer mode changed to 0", -- [1]
			0, -- [2]
		}, -- [677]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [678]
		{
			"Render scale changed to 0.4", -- [1]
			0, -- [2]
		}, -- [679]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [680]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [681]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [682]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [683]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [684]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [685]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [686]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [687]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [688]
		{
			"FFX: Anti Aliasing Mode set to FXAA - Quality Level 0", -- [1]
			0, -- [2]
		}, -- [689]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [690]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [691]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [692]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [693]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [694]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [695]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [696]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [697]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [698]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [699]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [700]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [701]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [702]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [703]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [704]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [705]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [706]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [707]
		{
			"[GlueLogin] Fatal error while logging inresult=\"( code=\"ERROR_GAME_ACCOUNT_BANNED (52)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [708]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [709]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [710]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [711]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [712]
		{
			"[IBN_Login] DestroyingisInitialized=\"true\"", -- [1]
			0, -- [2]
		}, -- [713]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [714]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [715]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [716]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [717]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [718]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [719]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [720]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [721]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [722]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [723]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [724]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [725]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [726]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [727]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [728]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [729]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [730]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [731]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [732]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [733]
		{
			"Shadow texture size changed to 512.", -- [1]
			0, -- [2]
		}, -- [734]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [735]
		{
			"SSAO mode set to 0", -- [1]
			0, -- [2]
		}, -- [736]
		{
			"Depth Based Opacity Disabled", -- [1]
			0, -- [2]
		}, -- [737]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [738]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [739]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [740]
		{
			"Outline mode changed to 0", -- [1]
			0, -- [2]
		}, -- [741]
		{
			"LightBuffer mode changed to 0", -- [1]
			0, -- [2]
		}, -- [742]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [743]
		{
			"Render scale changed to 0.4", -- [1]
			0, -- [2]
		}, -- [744]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [745]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [746]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [747]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [748]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [749]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [750]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [751]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [752]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [753]
		{
			"FFX: Anti Aliasing Mode set to FXAA - Quality Level 0", -- [1]
			0, -- [2]
		}, -- [754]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [755]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [756]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [757]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [758]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [759]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [760]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [761]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [762]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [763]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [764]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [765]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [766]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [767]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [768]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [769]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [770]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [771]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [772]
		{
			"[GlueLogin] Fatal error while logging inresult=\"( code=\"ERROR_GAME_ACCOUNT_BANNED (52)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [773]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [774]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [775]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [776]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [777]
		{
			"[IBN_Login] DestroyingisInitialized=\"true\"", -- [1]
			0, -- [2]
		}, -- [778]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [779]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [780]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [781]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [782]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [783]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [784]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [785]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [786]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [787]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [788]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [789]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [790]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [791]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [792]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [793]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [794]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [795]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [796]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [797]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [798]
		{
			"Shadow texture size changed to 512.", -- [1]
			0, -- [2]
		}, -- [799]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [800]
		{
			"SSAO mode set to 0", -- [1]
			0, -- [2]
		}, -- [801]
		{
			"Depth Based Opacity Disabled", -- [1]
			0, -- [2]
		}, -- [802]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [803]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [804]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [805]
		{
			"Outline mode changed to 0", -- [1]
			0, -- [2]
		}, -- [806]
		{
			"LightBuffer mode changed to 0", -- [1]
			0, -- [2]
		}, -- [807]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [808]
		{
			"Render scale changed to 0.4", -- [1]
			0, -- [2]
		}, -- [809]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [810]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [811]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [812]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [813]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [814]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [815]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [816]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [817]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [818]
		{
			"FFX: Anti Aliasing Mode set to FXAA - Quality Level 0", -- [1]
			0, -- [2]
		}, -- [819]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [820]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [821]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [822]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [823]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [824]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [825]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [826]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [827]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [828]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [829]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [830]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [831]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [832]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [833]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [834]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [835]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [836]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [837]
		{
			"[GlueLogin] Fatal error while logging inresult=\"( code=\"ERROR_GAME_ACCOUNT_BANNED (52)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [838]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [839]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [840]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [841]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [842]
		{
			"[IBN_Login] DestroyingisInitialized=\"true\"", -- [1]
			0, -- [2]
		}, -- [843]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [844]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [845]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [846]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [847]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [848]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [849]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [850]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [851]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [852]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [853]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [854]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [855]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [856]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [857]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [858]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [859]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [860]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [861]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [862]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [863]
		{
			"Shadow texture size changed to 512.", -- [1]
			0, -- [2]
		}, -- [864]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [865]
		{
			"SSAO mode set to 0", -- [1]
			0, -- [2]
		}, -- [866]
		{
			"Depth Based Opacity Disabled", -- [1]
			0, -- [2]
		}, -- [867]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [868]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [869]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [870]
		{
			"Outline mode changed to 0", -- [1]
			0, -- [2]
		}, -- [871]
		{
			"LightBuffer mode changed to 0", -- [1]
			0, -- [2]
		}, -- [872]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [873]
		{
			"Render scale changed to 0.4", -- [1]
			0, -- [2]
		}, -- [874]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [875]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [876]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [877]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [878]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [879]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [880]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [881]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [882]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [883]
		{
			"FFX: Anti Aliasing Mode set to FXAA - Quality Level 0", -- [1]
			0, -- [2]
		}, -- [884]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [885]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [886]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [887]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [888]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [889]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [890]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [891]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [892]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [893]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [894]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [895]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [896]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [897]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [898]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [899]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [900]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [901]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [902]
		{
			"[GlueLogin] Fatal error while logging inresult=\"( code=\"ERROR_GAME_ACCOUNT_BANNED (52)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [903]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [904]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [905]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [906]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [907]
		{
			"[IBN_Login] DestroyingisInitialized=\"true\"", -- [1]
			0, -- [2]
		}, -- [908]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [909]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [910]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [911]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [912]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [913]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [914]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [915]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [916]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [917]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [918]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [919]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [920]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [921]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [922]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [923]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [924]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [925]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [926]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [927]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [928]
		{
			"Shadow texture size changed to 512.", -- [1]
			0, -- [2]
		}, -- [929]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [930]
		{
			"SSAO mode set to 0", -- [1]
			0, -- [2]
		}, -- [931]
		{
			"Depth Based Opacity Disabled", -- [1]
			0, -- [2]
		}, -- [932]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [933]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [934]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [935]
		{
			"Outline mode changed to 0", -- [1]
			0, -- [2]
		}, -- [936]
		{
			"LightBuffer mode changed to 0", -- [1]
			0, -- [2]
		}, -- [937]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [938]
		{
			"Render scale changed to 0.4", -- [1]
			0, -- [2]
		}, -- [939]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [940]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [941]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [942]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [943]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [944]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [945]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [946]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [947]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [948]
		{
			"FFX: Anti Aliasing Mode set to FXAA - Quality Level 0", -- [1]
			0, -- [2]
		}, -- [949]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [950]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [951]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [952]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [953]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [954]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [955]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [956]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [957]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [958]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [959]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [960]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [961]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [962]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [963]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [964]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [965]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [966]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [967]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [968]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [969]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [970]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [971]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [972]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [973]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"2\"", -- [1]
			0, -- [2]
		}, -- [974]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [975]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-4-43\"", -- [1]
			0, -- [2]
		}, -- [976]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [977]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [978]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [979]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [980]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [981]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [982]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [983]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [984]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [985]
		{
			"[IBN_Login] Requesting change realm list", -- [1]
			0, -- [2]
		}, -- [986]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [987]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [988]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [989]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [990]
		{
			"[IBN_Login] Requesting realm listsnumSubRegions=\"2\"", -- [1]
			0, -- [2]
		}, -- [991]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [992]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-1-30\"", -- [1]
			0, -- [2]
		}, -- [993]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [994]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [995]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [996]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [997]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [998]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [999]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [1000]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [1001]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [1002]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [1003]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [1004]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [1005]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [1006]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [1007]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [1008]
		{
			"Proficiency in item class 2 set to 0x000000018d", -- [1]
			0, -- [2]
		}, -- [1009]
		{
			"Proficiency in item class 2 set to 0x000000058d", -- [1]
			0, -- [2]
		}, -- [1010]
		{
			"Proficiency in item class 2 set to 0x000000058f", -- [1]
			0, -- [2]
		}, -- [1011]
		{
			"Proficiency in item class 2 set to 0x000000858f", -- [1]
			0, -- [2]
		}, -- [1012]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [1013]
		{
			"Proficiency in item class 2 set to 0x000000c58f", -- [1]
			0, -- [2]
		}, -- [1014]
		{
			"Proficiency in item class 2 set to 0x000004c58f", -- [1]
			0, -- [2]
		}, -- [1015]
		{
			"Proficiency in item class 2 set to 0x000004c5cf", -- [1]
			0, -- [2]
		}, -- [1016]
		{
			"Proficiency in item class 2 set to 0x000014c5cf", -- [1]
			0, -- [2]
		}, -- [1017]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [1018]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [1019]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [1020]
		{
			"Proficiency in item class 2 set to 0x000014e5cf", -- [1]
			0, -- [2]
		}, -- [1021]
		{
			"Proficiency in item class 2 set to 0x000014e5cf", -- [1]
			0, -- [2]
		}, -- [1022]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [1023]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [1024]
		{
			"Time set to 1/15/2019 (Tue) 11:23", -- [1]
			0, -- [2]
		}, -- [1025]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [1026]
		{
			"WowBrowser: unselectable", -- [1]
			0, -- [2]
		}, -- [1027]
		{
			"WowBrowser: unselectable", -- [1]
			0, -- [2]
		}, -- [1028]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [1029]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [1030]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [1031]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [1032]
		{
			"Class not defined for spell 90361", -- [1]
			0, -- [2]
		}, -- [1033]
		{
			"Class not defined for spell 90361", -- [1]
			0, -- [2]
		}, -- [1034]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [1035]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [1036]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [1037]
		{
			"Weather changed to 2, intensity 0.056949\n", -- [1]
			0, -- [2]
		}, -- [1038]
		{
			"WowBrowser: Uncaught TypeError: Cannot set property 'value' of null", -- [1]
			0, -- [2]
		}, -- [1039]
		{
			"WowBrowser: Uncaught TypeError: Cannot set property 'value' of null", -- [1]
			0, -- [2]
		}, -- [1040]
	},
	["height"] = 299.999908447266,
	["fontHeight"] = 14,
	["isShown"] = false,
	["commandHistory"] = {
	},
}
