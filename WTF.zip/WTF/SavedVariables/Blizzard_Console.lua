
Blizzard_Console_SavedVars = {
	["version"] = 3,
	["messageHistory"] = {
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [1]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [2]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [3]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [4]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [5]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [6]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [7]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [8]
		{
			"Shadow texture size changed to 512.", -- [1]
			0, -- [2]
		}, -- [9]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [10]
		{
			"SSAO mode set to 0", -- [1]
			0, -- [2]
		}, -- [11]
		{
			"Depth Based Opacity Disabled", -- [1]
			0, -- [2]
		}, -- [12]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [13]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [14]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [15]
		{
			"Outline mode changed to 0", -- [1]
			0, -- [2]
		}, -- [16]
		{
			"LightBuffer mode changed to 0", -- [1]
			0, -- [2]
		}, -- [17]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [18]
		{
			"Render scale changed to 0.4", -- [1]
			0, -- [2]
		}, -- [19]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [20]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [21]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [22]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [23]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [24]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [25]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [26]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [27]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [28]
		{
			"FFX: Anti Aliasing Mode set to FXAA - Quality Level 0", -- [1]
			0, -- [2]
		}, -- [29]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [30]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [31]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [32]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [33]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [34]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [35]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [36]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [37]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [38]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [39]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [40]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [41]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [42]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [43]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [44]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [45]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [46]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [47]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [48]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [49]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [50]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [51]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [52]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [53]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"2\"", -- [1]
			0, -- [2]
		}, -- [54]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [55]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-1-30\"", -- [1]
			0, -- [2]
		}, -- [56]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [57]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [58]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [59]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [60]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [61]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [62]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [63]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [64]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [65]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [66]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [67]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [68]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [69]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [70]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [71]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [72]
		{
			"Proficiency in item class 2 set to 0x000000018d", -- [1]
			0, -- [2]
		}, -- [73]
		{
			"Proficiency in item class 2 set to 0x000000058d", -- [1]
			0, -- [2]
		}, -- [74]
		{
			"Proficiency in item class 2 set to 0x000000058f", -- [1]
			0, -- [2]
		}, -- [75]
		{
			"Proficiency in item class 2 set to 0x000000858f", -- [1]
			0, -- [2]
		}, -- [76]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [77]
		{
			"Proficiency in item class 2 set to 0x000000c58f", -- [1]
			0, -- [2]
		}, -- [78]
		{
			"Proficiency in item class 2 set to 0x000004c58f", -- [1]
			0, -- [2]
		}, -- [79]
		{
			"Proficiency in item class 2 set to 0x000004c5cf", -- [1]
			0, -- [2]
		}, -- [80]
		{
			"Proficiency in item class 2 set to 0x000014c5cf", -- [1]
			0, -- [2]
		}, -- [81]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [82]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [83]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [84]
		{
			"Proficiency in item class 2 set to 0x000014e5cf", -- [1]
			0, -- [2]
		}, -- [85]
		{
			"Proficiency in item class 2 set to 0x000014e5cf", -- [1]
			0, -- [2]
		}, -- [86]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [87]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [88]
		{
			"Time set to 12/22/2018 (Sat) 10:12", -- [1]
			0, -- [2]
		}, -- [89]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [90]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [91]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [92]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [93]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [94]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [95]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [96]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [97]
		{
			"Weather changed to 5, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [98]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [99]
		{
			"Weather changed to 5, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [100]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [101]
		{
			"Weather changed to 5, intensity 0.600000\n", -- [1]
			0, -- [2]
		}, -- [102]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [103]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [104]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [105]
		{
			"Failed to set SpellClutter callback on graphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [106]
		{
			"Failed to set SpellClutter callback on RAIDgraphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [107]
		{
			"Dissolve Effect ID 1075 has invalid fade out time. This will result in the record beign ignore and a regular fade out being applied to the creature.", -- [1]
			0, -- [2]
		}, -- [108]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [109]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [110]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [111]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [112]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [113]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [114]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [115]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [116]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [117]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [118]
		{
			"Failed to set SpellClutter callback on graphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [119]
		{
			"Failed to set SpellClutter callback on RAIDgraphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [120]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [121]
		{
			"Proficiency in item class 2 set to 0x0000000010", -- [1]
			0, -- [2]
		}, -- [122]
		{
			"Proficiency in item class 2 set to 0x0000000410", -- [1]
			0, -- [2]
		}, -- [123]
		{
			"Proficiency in item class 2 set to 0x0000000430", -- [1]
			0, -- [2]
		}, -- [124]
		{
			"Proficiency in item class 2 set to 0x0000008430", -- [1]
			0, -- [2]
		}, -- [125]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [126]
		{
			"Proficiency in item class 2 set to 0x000000c430", -- [1]
			0, -- [2]
		}, -- [127]
		{
			"Proficiency in item class 2 set to 0x000000c470", -- [1]
			0, -- [2]
		}, -- [128]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [129]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [130]
		{
			"Proficiency in item class 2 set to 0x000000e470", -- [1]
			0, -- [2]
		}, -- [131]
		{
			"Proficiency in item class 2 set to 0x000000e470", -- [1]
			0, -- [2]
		}, -- [132]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [133]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [134]
		{
			"Time set to 12/22/2018 (Sat) 10:39", -- [1]
			0, -- [2]
		}, -- [135]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [136]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [137]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [138]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [139]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [140]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [141]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [142]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [143]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [144]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [145]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [146]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [147]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [148]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [149]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [150]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [151]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [152]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [153]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [154]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [155]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [156]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [157]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [158]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [159]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [160]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [161]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [162]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [163]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [164]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [165]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [166]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [167]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [168]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [169]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [170]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [171]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [172]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [173]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [174]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [175]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [176]
		{
			"Shadow texture size changed to 512.", -- [1]
			0, -- [2]
		}, -- [177]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [178]
		{
			"SSAO mode set to 0", -- [1]
			0, -- [2]
		}, -- [179]
		{
			"Depth Based Opacity Disabled", -- [1]
			0, -- [2]
		}, -- [180]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [181]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [182]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [183]
		{
			"Outline mode changed to 0", -- [1]
			0, -- [2]
		}, -- [184]
		{
			"LightBuffer mode changed to 0", -- [1]
			0, -- [2]
		}, -- [185]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [186]
		{
			"Render scale changed to 0.4", -- [1]
			0, -- [2]
		}, -- [187]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [188]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [189]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [190]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [191]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [192]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [193]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [194]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [195]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [196]
		{
			"FFX: Anti Aliasing Mode set to FXAA - Quality Level 0", -- [1]
			0, -- [2]
		}, -- [197]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [198]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [199]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [200]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [201]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [202]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [203]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [204]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [205]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [206]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [207]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [208]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [209]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [210]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [211]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [212]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [213]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [214]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [215]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [216]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [217]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [218]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [219]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [220]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [221]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"2\"", -- [1]
			0, -- [2]
		}, -- [222]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [223]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-1-30\"", -- [1]
			0, -- [2]
		}, -- [224]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [225]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [226]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [227]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [228]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [229]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [230]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [231]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [232]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [233]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [234]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [235]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [236]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [237]
		{
			"Proficiency in item class 2 set to 0x0000000010", -- [1]
			0, -- [2]
		}, -- [238]
		{
			"Proficiency in item class 2 set to 0x0000000410", -- [1]
			0, -- [2]
		}, -- [239]
		{
			"Proficiency in item class 2 set to 0x0000000430", -- [1]
			0, -- [2]
		}, -- [240]
		{
			"Proficiency in item class 2 set to 0x0000008430", -- [1]
			0, -- [2]
		}, -- [241]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [242]
		{
			"Proficiency in item class 2 set to 0x000000c430", -- [1]
			0, -- [2]
		}, -- [243]
		{
			"Proficiency in item class 2 set to 0x000000c470", -- [1]
			0, -- [2]
		}, -- [244]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [245]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [246]
		{
			"Proficiency in item class 2 set to 0x000000e470", -- [1]
			0, -- [2]
		}, -- [247]
		{
			"Proficiency in item class 2 set to 0x000000e470", -- [1]
			0, -- [2]
		}, -- [248]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [249]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [250]
		{
			"Time set to 12/22/2018 (Sat) 11:38", -- [1]
			0, -- [2]
		}, -- [251]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [252]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [253]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [254]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [255]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [256]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [257]
		{
			"Skill 126 increased from 455 to 460", -- [1]
			0, -- [2]
		}, -- [258]
		{
			"Skill 183 increased from 455 to 460", -- [1]
			0, -- [2]
		}, -- [259]
		{
			"Skill 798 increased from 455 to 460", -- [1]
			0, -- [2]
		}, -- [260]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [261]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [262]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [263]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [264]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [265]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [266]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [267]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [268]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [269]
		{
			"Weather changed to 2, intensity 0.800000\n", -- [1]
			0, -- [2]
		}, -- [270]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [271]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [272]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [273]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [274]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [275]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [276]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [277]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [278]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [279]
		{
			"Failed to set SpellClutter callback on graphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [280]
		{
			"Failed to set SpellClutter callback on RAIDgraphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [281]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [282]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [283]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [284]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [285]
		{
			"Failed to set SpellClutter callback on graphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [286]
		{
			"Failed to set SpellClutter callback on RAIDgraphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [287]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [288]
		{
			"Proficiency in item class 2 set to 0x0000000010", -- [1]
			0, -- [2]
		}, -- [289]
		{
			"Proficiency in item class 2 set to 0x0000000410", -- [1]
			0, -- [2]
		}, -- [290]
		{
			"Proficiency in item class 2 set to 0x0000000430", -- [1]
			0, -- [2]
		}, -- [291]
		{
			"Proficiency in item class 2 set to 0x0000008430", -- [1]
			0, -- [2]
		}, -- [292]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [293]
		{
			"Proficiency in item class 2 set to 0x000000c430", -- [1]
			0, -- [2]
		}, -- [294]
		{
			"Proficiency in item class 2 set to 0x000000c470", -- [1]
			0, -- [2]
		}, -- [295]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [296]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [297]
		{
			"Proficiency in item class 2 set to 0x000000e470", -- [1]
			0, -- [2]
		}, -- [298]
		{
			"Proficiency in item class 2 set to 0x000000e470", -- [1]
			0, -- [2]
		}, -- [299]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [300]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [301]
		{
			"Time set to 12/22/2018 (Sat) 12:35", -- [1]
			0, -- [2]
		}, -- [302]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [303]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [304]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [305]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [306]
		{
			"Weather changed to 1, intensity 0.250000\n", -- [1]
			0, -- [2]
		}, -- [307]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [308]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [309]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [310]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [311]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [312]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [313]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [314]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [315]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [316]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [317]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [318]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [319]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [320]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [321]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [322]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [323]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [324]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [325]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [326]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [327]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [328]
		{
			"Shadow texture size changed to 512.", -- [1]
			0, -- [2]
		}, -- [329]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [330]
		{
			"SSAO mode set to 0", -- [1]
			0, -- [2]
		}, -- [331]
		{
			"Depth Based Opacity Disabled", -- [1]
			0, -- [2]
		}, -- [332]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [333]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [334]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [335]
		{
			"Outline mode changed to 0", -- [1]
			0, -- [2]
		}, -- [336]
		{
			"LightBuffer mode changed to 0", -- [1]
			0, -- [2]
		}, -- [337]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [338]
		{
			"Render scale changed to 0.4", -- [1]
			0, -- [2]
		}, -- [339]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [340]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [341]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [342]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [343]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [344]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [345]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [346]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [347]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [348]
		{
			"FFX: Anti Aliasing Mode set to FXAA - Quality Level 0", -- [1]
			0, -- [2]
		}, -- [349]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [350]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [351]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [352]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [353]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [354]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [355]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [356]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [357]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [358]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [359]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [360]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [361]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [362]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [363]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [364]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [365]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [366]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [367]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [368]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [369]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [370]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [371]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [372]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [373]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"2\"", -- [1]
			0, -- [2]
		}, -- [374]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [375]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-1-30\"", -- [1]
			0, -- [2]
		}, -- [376]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [377]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [378]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [379]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [380]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [381]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [382]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [383]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [384]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [385]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [386]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [387]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [388]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [389]
		{
			"Proficiency in item class 2 set to 0x0000000010", -- [1]
			0, -- [2]
		}, -- [390]
		{
			"Proficiency in item class 2 set to 0x0000000410", -- [1]
			0, -- [2]
		}, -- [391]
		{
			"Proficiency in item class 2 set to 0x0000000430", -- [1]
			0, -- [2]
		}, -- [392]
		{
			"Proficiency in item class 2 set to 0x0000008430", -- [1]
			0, -- [2]
		}, -- [393]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [394]
		{
			"Proficiency in item class 2 set to 0x000000c430", -- [1]
			0, -- [2]
		}, -- [395]
		{
			"Proficiency in item class 2 set to 0x000000c470", -- [1]
			0, -- [2]
		}, -- [396]
		{
			"Proficiency in item class 4 set to 0x0000000025", -- [1]
			0, -- [2]
		}, -- [397]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [398]
		{
			"Proficiency in item class 2 set to 0x000000e470", -- [1]
			0, -- [2]
		}, -- [399]
		{
			"Proficiency in item class 2 set to 0x000000e470", -- [1]
			0, -- [2]
		}, -- [400]
		{
			"Proficiency in item class 4 set to 0x0000000027", -- [1]
			0, -- [2]
		}, -- [401]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [402]
		{
			"Time set to 12/22/2018 (Sat) 13:22", -- [1]
			0, -- [2]
		}, -- [403]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [404]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [405]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [406]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [407]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [408]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [409]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [410]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [411]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [412]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [413]
		{
			"Weather changed to 2, intensity 0.800000\n", -- [1]
			0, -- [2]
		}, -- [414]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [415]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [416]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [417]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [418]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [419]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [420]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [421]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [422]
		{
			"Skill 126 increased from 460 to 465", -- [1]
			0, -- [2]
		}, -- [423]
		{
			"Skill 183 increased from 460 to 465", -- [1]
			0, -- [2]
		}, -- [424]
		{
			"Skill 798 increased from 460 to 465", -- [1]
			0, -- [2]
		}, -- [425]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [426]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [427]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [428]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [429]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [430]
		{
			"Weather changed to 2, intensity 1.000000\n", -- [1]
			0, -- [2]
		}, -- [431]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [432]
		{
			"Skill 126 increased from 465 to 470", -- [1]
			0, -- [2]
		}, -- [433]
		{
			"Skill 183 increased from 465 to 470", -- [1]
			0, -- [2]
		}, -- [434]
		{
			"Skill 798 increased from 465 to 470", -- [1]
			0, -- [2]
		}, -- [435]
		{
			"World transfer pending...", -- [1]
			0, -- [2]
		}, -- [436]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [437]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [438]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [439]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [440]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [441]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [442]
		{
			"Failed to set SpellClutter callback on graphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [443]
		{
			"Failed to set SpellClutter callback on RAIDgraphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [444]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [445]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [446]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [447]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [448]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [449]
		{
			"Proficiency in item class 2 set to 0x000000018d", -- [1]
			0, -- [2]
		}, -- [450]
		{
			"Proficiency in item class 2 set to 0x000000058d", -- [1]
			0, -- [2]
		}, -- [451]
		{
			"Proficiency in item class 2 set to 0x000000058f", -- [1]
			0, -- [2]
		}, -- [452]
		{
			"Proficiency in item class 2 set to 0x000000858f", -- [1]
			0, -- [2]
		}, -- [453]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [454]
		{
			"Proficiency in item class 2 set to 0x000000c58f", -- [1]
			0, -- [2]
		}, -- [455]
		{
			"Proficiency in item class 2 set to 0x000004c58f", -- [1]
			0, -- [2]
		}, -- [456]
		{
			"Proficiency in item class 2 set to 0x000004c5cf", -- [1]
			0, -- [2]
		}, -- [457]
		{
			"Proficiency in item class 2 set to 0x000014c5cf", -- [1]
			0, -- [2]
		}, -- [458]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [459]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [460]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [461]
		{
			"Proficiency in item class 2 set to 0x000014e5cf", -- [1]
			0, -- [2]
		}, -- [462]
		{
			"Proficiency in item class 2 set to 0x000014e5cf", -- [1]
			0, -- [2]
		}, -- [463]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [464]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [465]
		{
			"Time set to 12/22/2018 (Sat) 14:20", -- [1]
			0, -- [2]
		}, -- [466]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [467]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [468]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [469]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [470]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [471]
		{
			"Failed to set SpellClutter callback on graphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [472]
		{
			"Failed to set SpellClutter callback on RAIDgraphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [473]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [474]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [475]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [476]
		{
			"Proficiency in item class 2 set to 0x0000000091", -- [1]
			0, -- [2]
		}, -- [477]
		{
			"Proficiency in item class 2 set to 0x0000000191", -- [1]
			0, -- [2]
		}, -- [478]
		{
			"Proficiency in item class 2 set to 0x00000001b1", -- [1]
			0, -- [2]
		}, -- [479]
		{
			"Proficiency in item class 2 set to 0x00000001b3", -- [1]
			0, -- [2]
		}, -- [480]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [481]
		{
			"Proficiency in item class 2 set to 0x00000041b3", -- [1]
			0, -- [2]
		}, -- [482]
		{
			"Proficiency in item class 2 set to 0x00000041f3", -- [1]
			0, -- [2]
		}, -- [483]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [484]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [485]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [486]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [487]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [488]
		{
			"Proficiency in item class 2 set to 0x00000041f3", -- [1]
			0, -- [2]
		}, -- [489]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [490]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [491]
		{
			"Time set to 12/22/2018 (Sat) 14:21", -- [1]
			0, -- [2]
		}, -- [492]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [493]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [494]
		{
			"[IBN_Login] Requesting change realm list", -- [1]
			0, -- [2]
		}, -- [495]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [496]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [497]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [498]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [499]
		{
			"[IBN_Login] Requesting realm listsnumSubRegions=\"2\"", -- [1]
			0, -- [2]
		}, -- [500]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [501]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-4-43\"", -- [1]
			0, -- [2]
		}, -- [502]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [503]
		{
			"NetClient::HandleDisconnect()\n", -- [1]
			0, -- [2]
		}, -- [504]
		{
			"[IBN_BackInterface] Session with Battle.net destroyed.", -- [1]
			0, -- [2]
		}, -- [505]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [506]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [507]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [508]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [509]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [510]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [511]
		{
			"Failed to set SpellClutter callback on graphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [512]
		{
			"Failed to set SpellClutter callback on RAIDgraphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [513]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [514]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [515]
		{
			"Proficiency in item class 2 set to 0x0000000480", -- [1]
			0, -- [2]
		}, -- [516]
		{
			"Proficiency in item class 2 set to 0x0000008480", -- [1]
			0, -- [2]
		}, -- [517]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [518]
		{
			"Proficiency in item class 2 set to 0x000000c480", -- [1]
			0, -- [2]
		}, -- [519]
		{
			"Proficiency in item class 2 set to 0x000008c480", -- [1]
			0, -- [2]
		}, -- [520]
		{
			"Proficiency in item class 2 set to 0x000018c480", -- [1]
			0, -- [2]
		}, -- [521]
		{
			"Proficiency in item class 4 set to 0x0000000023", -- [1]
			0, -- [2]
		}, -- [522]
		{
			"Proficiency in item class 2 set to 0x000018c480", -- [1]
			0, -- [2]
		}, -- [523]
		{
			"Proficiency in item class 4 set to 0x0000000023", -- [1]
			0, -- [2]
		}, -- [524]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [525]
		{
			"Time set to 12/22/2018 (Sat) 14:22", -- [1]
			0, -- [2]
		}, -- [526]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [527]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [528]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [529]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [530]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [531]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [532]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [533]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [534]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [535]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [536]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [537]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [538]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [539]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [540]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [541]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [542]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [543]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [544]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [545]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [546]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [547]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [548]
		{
			"Shadow texture size changed to 512.", -- [1]
			0, -- [2]
		}, -- [549]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [550]
		{
			"SSAO mode set to 0", -- [1]
			0, -- [2]
		}, -- [551]
		{
			"Depth Based Opacity Disabled", -- [1]
			0, -- [2]
		}, -- [552]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [553]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [554]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [555]
		{
			"Outline mode changed to 0", -- [1]
			0, -- [2]
		}, -- [556]
		{
			"LightBuffer mode changed to 0", -- [1]
			0, -- [2]
		}, -- [557]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [558]
		{
			"Render scale changed to 0.4", -- [1]
			0, -- [2]
		}, -- [559]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [560]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [561]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [562]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [563]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [564]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [565]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [566]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [567]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [568]
		{
			"FFX: Anti Aliasing Mode set to FXAA - Quality Level 0", -- [1]
			0, -- [2]
		}, -- [569]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [570]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [571]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [572]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [573]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [574]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [575]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [576]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [577]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [578]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [579]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [580]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [581]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [582]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [583]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [584]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [585]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [586]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [587]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [588]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [589]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [590]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [591]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [592]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [593]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"2\"", -- [1]
			0, -- [2]
		}, -- [594]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [595]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-4-43\"", -- [1]
			0, -- [2]
		}, -- [596]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [597]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [598]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [599]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [600]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [601]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [602]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [603]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [604]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [605]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [606]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [607]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [608]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [609]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [610]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [611]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [612]
		{
			"Proficiency in item class 2 set to 0x000000009d", -- [1]
			0, -- [2]
		}, -- [613]
		{
			"Proficiency in item class 2 set to 0x000000019d", -- [1]
			0, -- [2]
		}, -- [614]
		{
			"Proficiency in item class 2 set to 0x000000059d", -- [1]
			0, -- [2]
		}, -- [615]
		{
			"Proficiency in item class 2 set to 0x00000005bd", -- [1]
			0, -- [2]
		}, -- [616]
		{
			"Proficiency in item class 2 set to 0x00000005bf", -- [1]
			0, -- [2]
		}, -- [617]
		{
			"Proficiency in item class 2 set to 0x00000085bf", -- [1]
			0, -- [2]
		}, -- [618]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [619]
		{
			"Proficiency in item class 2 set to 0x000000c5bf", -- [1]
			0, -- [2]
		}, -- [620]
		{
			"Proficiency in item class 2 set to 0x000004c5bf", -- [1]
			0, -- [2]
		}, -- [621]
		{
			"Proficiency in item class 2 set to 0x000004c5ff", -- [1]
			0, -- [2]
		}, -- [622]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [623]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [624]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [625]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [626]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [627]
		{
			"Proficiency in item class 2 set to 0x000004e5ff", -- [1]
			0, -- [2]
		}, -- [628]
		{
			"Proficiency in item class 2 set to 0x000004e5ff", -- [1]
			0, -- [2]
		}, -- [629]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [630]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [631]
		{
			"Time set to 12/22/2018 (Sat) 14:37", -- [1]
			0, -- [2]
		}, -- [632]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [633]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [634]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [635]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [636]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [637]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [638]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [639]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [640]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [641]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [642]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [643]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [644]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [645]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [646]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [647]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [648]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [649]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [650]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [651]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [652]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [653]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [654]
		{
			"Shadow texture size changed to 512.", -- [1]
			0, -- [2]
		}, -- [655]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [656]
		{
			"SSAO mode set to 0", -- [1]
			0, -- [2]
		}, -- [657]
		{
			"Depth Based Opacity Disabled", -- [1]
			0, -- [2]
		}, -- [658]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [659]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [660]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [661]
		{
			"Outline mode changed to 0", -- [1]
			0, -- [2]
		}, -- [662]
		{
			"LightBuffer mode changed to 0", -- [1]
			0, -- [2]
		}, -- [663]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [664]
		{
			"Render scale changed to 0.4", -- [1]
			0, -- [2]
		}, -- [665]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [666]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [667]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [668]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [669]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [670]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [671]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [672]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [673]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [674]
		{
			"FFX: Anti Aliasing Mode set to FXAA - Quality Level 0", -- [1]
			0, -- [2]
		}, -- [675]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [676]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [677]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [678]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [679]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [680]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [681]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [682]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [683]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [684]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [685]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [686]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [687]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [688]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [689]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [690]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [691]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [692]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [693]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [694]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [695]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [696]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [697]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [698]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [699]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"2\"", -- [1]
			0, -- [2]
		}, -- [700]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [701]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-1-30\"", -- [1]
			0, -- [2]
		}, -- [702]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [703]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [704]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [705]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [706]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [707]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [708]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [709]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [710]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [711]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [712]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [713]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [714]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [715]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [716]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [717]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [718]
		{
			"Proficiency in item class 2 set to 0x000000018d", -- [1]
			0, -- [2]
		}, -- [719]
		{
			"Proficiency in item class 2 set to 0x000000058d", -- [1]
			0, -- [2]
		}, -- [720]
		{
			"Proficiency in item class 2 set to 0x000000058f", -- [1]
			0, -- [2]
		}, -- [721]
		{
			"Proficiency in item class 2 set to 0x000000858f", -- [1]
			0, -- [2]
		}, -- [722]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [723]
		{
			"Proficiency in item class 2 set to 0x000000c58f", -- [1]
			0, -- [2]
		}, -- [724]
		{
			"Proficiency in item class 2 set to 0x000004c58f", -- [1]
			0, -- [2]
		}, -- [725]
		{
			"Proficiency in item class 2 set to 0x000004c5cf", -- [1]
			0, -- [2]
		}, -- [726]
		{
			"Proficiency in item class 2 set to 0x000014c5cf", -- [1]
			0, -- [2]
		}, -- [727]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [728]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [729]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [730]
		{
			"Proficiency in item class 2 set to 0x000014e5cf", -- [1]
			0, -- [2]
		}, -- [731]
		{
			"Proficiency in item class 2 set to 0x000014e5cf", -- [1]
			0, -- [2]
		}, -- [732]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [733]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [734]
		{
			"Time set to 12/23/2018 (Sun) 22:45", -- [1]
			0, -- [2]
		}, -- [735]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [736]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [737]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [738]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [739]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [740]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [741]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [742]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [743]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [744]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [745]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [746]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [747]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [748]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [749]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [750]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [751]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [752]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [753]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [754]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [755]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [756]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [757]
		{
			"Shadow texture size changed to 512.", -- [1]
			0, -- [2]
		}, -- [758]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [759]
		{
			"SSAO mode set to 0", -- [1]
			0, -- [2]
		}, -- [760]
		{
			"Depth Based Opacity Disabled", -- [1]
			0, -- [2]
		}, -- [761]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [762]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [763]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [764]
		{
			"Outline mode changed to 0", -- [1]
			0, -- [2]
		}, -- [765]
		{
			"LightBuffer mode changed to 0", -- [1]
			0, -- [2]
		}, -- [766]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [767]
		{
			"Render scale changed to 0.4", -- [1]
			0, -- [2]
		}, -- [768]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [769]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [770]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [771]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [772]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [773]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [774]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [775]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [776]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [777]
		{
			"FFX: Anti Aliasing Mode set to FXAA - Quality Level 0", -- [1]
			0, -- [2]
		}, -- [778]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [779]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [780]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [781]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [782]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [783]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [784]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [785]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [786]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [787]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [788]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [789]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [790]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [791]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [792]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [793]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [794]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [795]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [796]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [797]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [798]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [799]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [800]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [801]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [802]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"2\"", -- [1]
			0, -- [2]
		}, -- [803]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [804]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-1-30\"", -- [1]
			0, -- [2]
		}, -- [805]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [806]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [807]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [808]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [809]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [810]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [811]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [812]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [813]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [814]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [815]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [816]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [817]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [818]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [819]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [820]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [821]
		{
			"Proficiency in item class 2 set to 0x000000018d", -- [1]
			0, -- [2]
		}, -- [822]
		{
			"Proficiency in item class 2 set to 0x000000058d", -- [1]
			0, -- [2]
		}, -- [823]
		{
			"Proficiency in item class 2 set to 0x000000058f", -- [1]
			0, -- [2]
		}, -- [824]
		{
			"Proficiency in item class 2 set to 0x000000858f", -- [1]
			0, -- [2]
		}, -- [825]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [826]
		{
			"Proficiency in item class 2 set to 0x000000c58f", -- [1]
			0, -- [2]
		}, -- [827]
		{
			"Proficiency in item class 2 set to 0x000004c58f", -- [1]
			0, -- [2]
		}, -- [828]
		{
			"Proficiency in item class 2 set to 0x000004c5cf", -- [1]
			0, -- [2]
		}, -- [829]
		{
			"Proficiency in item class 2 set to 0x000014c5cf", -- [1]
			0, -- [2]
		}, -- [830]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [831]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [832]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [833]
		{
			"Proficiency in item class 2 set to 0x000014e5cf", -- [1]
			0, -- [2]
		}, -- [834]
		{
			"Proficiency in item class 2 set to 0x000014e5cf", -- [1]
			0, -- [2]
		}, -- [835]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [836]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [837]
		{
			"Time set to 12/24/2018 (Mon) 0:49", -- [1]
			0, -- [2]
		}, -- [838]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [839]
		{
			"Weather changed to 2, intensity 0.142180\n", -- [1]
			0, -- [2]
		}, -- [840]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [841]
		{
			"Weather changed to 2, intensity 0.142180\n", -- [1]
			0, -- [2]
		}, -- [842]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [843]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [844]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [845]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [846]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [847]
		{
			"Failed to set SpellClutter callback on graphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [848]
		{
			"Failed to set SpellClutter callback on RAIDgraphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [849]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [850]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [851]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [852]
		{
			"Proficiency in item class 2 set to 0x0000000091", -- [1]
			0, -- [2]
		}, -- [853]
		{
			"Proficiency in item class 2 set to 0x0000000191", -- [1]
			0, -- [2]
		}, -- [854]
		{
			"Proficiency in item class 2 set to 0x00000001b1", -- [1]
			0, -- [2]
		}, -- [855]
		{
			"Proficiency in item class 2 set to 0x00000001b3", -- [1]
			0, -- [2]
		}, -- [856]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [857]
		{
			"Proficiency in item class 2 set to 0x00000041b3", -- [1]
			0, -- [2]
		}, -- [858]
		{
			"Proficiency in item class 2 set to 0x00000041f3", -- [1]
			0, -- [2]
		}, -- [859]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [860]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [861]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [862]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [863]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [864]
		{
			"Proficiency in item class 2 set to 0x00000041f3", -- [1]
			0, -- [2]
		}, -- [865]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [866]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [867]
		{
			"Time set to 12/24/2018 (Mon) 1:01", -- [1]
			0, -- [2]
		}, -- [868]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [869]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [870]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [871]
		{
			"Sorting particles normally.", -- [1]
			0, -- [2]
		}, -- [872]
		{
			"Multithreaded rendering enabled.", -- [1]
			0, -- [2]
		}, -- [873]
		{
			"Multithreaded BeginDraw enabled.", -- [1]
			0, -- [2]
		}, -- [874]
		{
			"Multithread shadows changed to 1.", -- [1]
			0, -- [2]
		}, -- [875]
		{
			"Multithreaded prepass enabled.", -- [1]
			0, -- [2]
		}, -- [876]
		{
			"Multithreaded opaque pass enabled.", -- [1]
			0, -- [2]
		}, -- [877]
		{
			"Multithreaded alpha M2 pass enabled.", -- [1]
			0, -- [2]
		}, -- [878]
		{
			"Multithreaded opaque WMO pass enabled.", -- [1]
			0, -- [2]
		}, -- [879]
		{
			"Water detail changed to 1", -- [1]
			0, -- [2]
		}, -- [880]
		{
			"Ripple detail changed to 0", -- [1]
			0, -- [2]
		}, -- [881]
		{
			"Reflection mode changed to 0", -- [1]
			0, -- [2]
		}, -- [882]
		{
			"Reflection downscale changed to 0", -- [1]
			0, -- [2]
		}, -- [883]
		{
			"Sunshafts quality changed to 0", -- [1]
			0, -- [2]
		}, -- [884]
		{
			"Refraction mode changed to 0", -- [1]
			0, -- [2]
		}, -- [885]
		{
			"Enabling BSP node cache (first time - starting up)", -- [1]
			0, -- [2]
		}, -- [886]
		{
			"Alpha map bit depth set to 8bit on restart.", -- [1]
			0, -- [2]
		}, -- [887]
		{
			"Volume fog enabled.", -- [1]
			0, -- [2]
		}, -- [888]
		{
			"Projected textures disabled.", -- [1]
			0, -- [2]
		}, -- [889]
		{
			"Shadow mode changed to 0 - Precomputed terrain shadows, 1 band unit shadows, 1024", -- [1]
			0, -- [2]
		}, -- [890]
		{
			"Shadow texture size changed to 512.", -- [1]
			0, -- [2]
		}, -- [891]
		{
			"Soft shadows changed to 0.", -- [1]
			0, -- [2]
		}, -- [892]
		{
			"SSAO mode set to 0", -- [1]
			0, -- [2]
		}, -- [893]
		{
			"Depth Based Opacity Disabled", -- [1]
			0, -- [2]
		}, -- [894]
		{
			"SkyCloudLOD set to 0", -- [1]
			0, -- [2]
		}, -- [895]
		{
			"Texture filtering mode updated. Pending GxRestart", -- [1]
			0, -- [2]
		}, -- [896]
		{
			"Terrain mip level changed to 1.", -- [1]
			0, -- [2]
		}, -- [897]
		{
			"Outline mode changed to 0", -- [1]
			0, -- [2]
		}, -- [898]
		{
			"LightBuffer mode changed to 0", -- [1]
			0, -- [2]
		}, -- [899]
		{
			"Physics interaction level changed to 1", -- [1]
			0, -- [2]
		}, -- [900]
		{
			"Render scale changed to 0.4", -- [1]
			0, -- [2]
		}, -- [901]
		{
			"Resample quality changed to 0", -- [1]
			0, -- [2]
		}, -- [902]
		{
			"MSAA disabled", -- [1]
			0, -- [2]
		}, -- [903]
		{
			"MSAA for alpha-test disabled.", -- [1]
			0, -- [2]
		}, -- [904]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [905]
		{
			"Component texture lod changed to 1", -- [1]
			0, -- [2]
		}, -- [906]
		{
			"World preload object sort enabled.", -- [1]
			0, -- [2]
		}, -- [907]
		{
			"World load object sort enabled.", -- [1]
			0, -- [2]
		}, -- [908]
		{
			"World preload non critical enabled.", -- [1]
			0, -- [2]
		}, -- [909]
		{
			"World preload high res textures enabled.", -- [1]
			0, -- [2]
		}, -- [910]
		{
			"FFX: Anti Aliasing Mode set to FXAA - Quality Level 0", -- [1]
			0, -- [2]
		}, -- [911]
		{
			"FFX: Color Blind Test Mode Disabled", -- [1]
			0, -- [2]
		}, -- [912]
		{
			"CVar 'fullDump' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [913]
		{
			"Error display disabled", -- [1]
			0, -- [2]
		}, -- [914]
		{
			"Error display shown", -- [1]
			0, -- [2]
		}, -- [915]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [916]
		{
			"Displaying errors through fatal errors", -- [1]
			0, -- [2]
		}, -- [917]
		{
			"Now filtering: all messages", -- [1]
			0, -- [2]
		}, -- [918]
		{
			"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [919]
		{
			"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [920]
		{
			"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [921]
		{
			"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.", -- [1]
			0, -- [2]
		}, -- [922]
		{
			"[GlueLogin] Starting loginlauncherPortal=\"cn.actual.battle.net\" loginPortal=\"cn.actual.battle.net:1119\"", -- [1]
			0, -- [2]
		}, -- [923]
		{
			"[GlueLogin] Resetting", -- [1]
			0, -- [2]
		}, -- [924]
		{
			"[IBN_Login] Initializing", -- [1]
			0, -- [2]
		}, -- [925]
		{
			"[IBN_Login] Attempting logonhost=\"cn.actual.battle.net\" port=\"1119\"", -- [1]
			0, -- [2]
		}, -- [926]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [927]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [928]
		{
			"[GlueLogin] Waiting for server response.", -- [1]
			0, -- [2]
		}, -- [929]
		{
			"[GlueLogin] Logon complete.", -- [1]
			0, -- [2]
		}, -- [930]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [931]
		{
			"[IBN_Login] Requesting realm list ticket", -- [1]
			0, -- [2]
		}, -- [932]
		{
			"[IBN_Login] Received realm list ticketcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [933]
		{
			"[GlueLogin] Waiting for realm list.", -- [1]
			0, -- [2]
		}, -- [934]
		{
			"[IBN_Login] Received sub region listcode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [935]
		{
			"[IBN_Login] Requesting last played charsnumSubRegions=\"2\"", -- [1]
			0, -- [2]
		}, -- [936]
		{
			"[GlueLogin] Realm list ready.", -- [1]
			0, -- [2]
		}, -- [937]
		{
			"[IBN_Login] Joining realmsubRegion=\"5-101-89\" realmAddress=\"5-1-30\"", -- [1]
			0, -- [2]
		}, -- [938]
		{
			"[IBN_Login] OnRealmJoincode=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [939]
		{
			"NetClient::HandleConnect()\n", -- [1]
			0, -- [2]
		}, -- [940]
		{
			"[GlueLogin] Received AuthedToWoWresult=\"ERROR_OK (0)\"", -- [1]
			0, -- [2]
		}, -- [941]
		{
			"Got new connection 2", -- [1]
			0, -- [2]
		}, -- [942]
		{
			"[IBN_Login] Front disconnectingconnectionId=\"1\"", -- [1]
			0, -- [2]
		}, -- [943]
		{
			"[GlueLogin] Disconnecting from authentication server.", -- [1]
			0, -- [2]
		}, -- [944]
		{
			"[IBN_BackInterface] Session with Battle.net established.", -- [1]
			0, -- [2]
		}, -- [945]
		{
			"[IBN_Login] Front disconnectedconnectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"", -- [1]
			0, -- [2]
		}, -- [946]
		{
			"[GlueLogin] Disconnected from authentication server.", -- [1]
			0, -- [2]
		}, -- [947]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [948]
		{
			"Game table failed consistency check: ChallengeModeHealth. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [949]
		{
			"Game table failed consistency check: ChallengeModeDamage. rows: 50, expectedRows: 51, columns: 1, expectedColumns: 1\n", -- [1]
			3, -- [2]
		}, -- [950]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [951]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [952]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [953]
		{
			"Proficiency in item class 2 set to 0x0000000085", -- [1]
			0, -- [2]
		}, -- [954]
		{
			"Proficiency in item class 2 set to 0x000000008d", -- [1]
			0, -- [2]
		}, -- [955]
		{
			"Proficiency in item class 2 set to 0x000000018d", -- [1]
			0, -- [2]
		}, -- [956]
		{
			"Proficiency in item class 2 set to 0x000000058d", -- [1]
			0, -- [2]
		}, -- [957]
		{
			"Proficiency in item class 2 set to 0x000000058f", -- [1]
			0, -- [2]
		}, -- [958]
		{
			"Proficiency in item class 2 set to 0x000000858f", -- [1]
			0, -- [2]
		}, -- [959]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [960]
		{
			"Proficiency in item class 2 set to 0x000000c58f", -- [1]
			0, -- [2]
		}, -- [961]
		{
			"Proficiency in item class 2 set to 0x000004c58f", -- [1]
			0, -- [2]
		}, -- [962]
		{
			"Proficiency in item class 2 set to 0x000004c5cf", -- [1]
			0, -- [2]
		}, -- [963]
		{
			"Proficiency in item class 2 set to 0x000014c5cf", -- [1]
			0, -- [2]
		}, -- [964]
		{
			"Proficiency in item class 4 set to 0x0000000029", -- [1]
			0, -- [2]
		}, -- [965]
		{
			"Proficiency in item class 4 set to 0x000000002d", -- [1]
			0, -- [2]
		}, -- [966]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [967]
		{
			"Proficiency in item class 2 set to 0x000014e5cf", -- [1]
			0, -- [2]
		}, -- [968]
		{
			"Proficiency in item class 2 set to 0x000014e5cf", -- [1]
			0, -- [2]
		}, -- [969]
		{
			"Proficiency in item class 4 set to 0x000000002f", -- [1]
			0, -- [2]
		}, -- [970]
		{
			"Weather changed to 2, intensity 0.117553\n", -- [1]
			0, -- [2]
		}, -- [971]
		{
			"Time set to 12/24/2018 (Mon) 1:08", -- [1]
			0, -- [2]
		}, -- [972]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [973]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [974]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [975]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [976]
		{
			"Attempted to register existing command: ShowObjUsage\n", -- [1]
			0, -- [2]
		}, -- [977]
		{
			"Attempted to register existing command: SetDifficulty\n", -- [1]
			0, -- [2]
		}, -- [978]
		{
			"Failed to set SpellClutter callback on graphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [979]
		{
			"Failed to set SpellClutter callback on RAIDgraphicsQuality CVar - using default of 30.0", -- [1]
			0, -- [2]
		}, -- [980]
		{
			"Got new connection 3", -- [1]
			0, -- [2]
		}, -- [981]
		{
			"Proficiency in item class 2 set to 0x0000000080", -- [1]
			0, -- [2]
		}, -- [982]
		{
			"Proficiency in item class 2 set to 0x0000000081", -- [1]
			0, -- [2]
		}, -- [983]
		{
			"Proficiency in item class 2 set to 0x0000000091", -- [1]
			0, -- [2]
		}, -- [984]
		{
			"Proficiency in item class 2 set to 0x0000000191", -- [1]
			0, -- [2]
		}, -- [985]
		{
			"Proficiency in item class 2 set to 0x00000001b1", -- [1]
			0, -- [2]
		}, -- [986]
		{
			"Proficiency in item class 2 set to 0x00000001b3", -- [1]
			0, -- [2]
		}, -- [987]
		{
			"Proficiency in item class 4 set to 0x0000000021", -- [1]
			0, -- [2]
		}, -- [988]
		{
			"Proficiency in item class 2 set to 0x00000041b3", -- [1]
			0, -- [2]
		}, -- [989]
		{
			"Proficiency in item class 2 set to 0x00000041f3", -- [1]
			0, -- [2]
		}, -- [990]
		{
			"Proficiency in item class 4 set to 0x0000000031", -- [1]
			0, -- [2]
		}, -- [991]
		{
			"Proficiency in item class 4 set to 0x0000000039", -- [1]
			0, -- [2]
		}, -- [992]
		{
			"Proficiency in item class 4 set to 0x000000003d", -- [1]
			0, -- [2]
		}, -- [993]
		{
			"Proficiency in item class 4 set to 0x000000003f", -- [1]
			0, -- [2]
		}, -- [994]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [995]
		{
			"Proficiency in item class 2 set to 0x00000041f3", -- [1]
			0, -- [2]
		}, -- [996]
		{
			"Proficiency in item class 4 set to 0x000000007f", -- [1]
			0, -- [2]
		}, -- [997]
		{
			"Weather changed to 1, intensity 0.000000\n", -- [1]
			0, -- [2]
		}, -- [998]
		{
			"Time set to 12/24/2018 (Mon) 1:14", -- [1]
			0, -- [2]
		}, -- [999]
		{
			"Gamespeed set from 0.017 to 0.017", -- [1]
			0, -- [2]
		}, -- [1000]
		{
			"-------------------------------------------------- Previous Session --------------------------------------------------", -- [1]
			0, -- [2]
		}, -- [1001]
	},
	["height"] = 299.999908447266,
	["fontHeight"] = 14,
	["isShown"] = false,
	["commandHistory"] = {
	},
}
