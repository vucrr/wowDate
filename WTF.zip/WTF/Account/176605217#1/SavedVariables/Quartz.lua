
Quartz3DB = {
	["namespaces"] = {
		["Swing"] = {
		},
		["Buff"] = {
		},
		["Interrupt"] = {
		},
		["Flight"] = {
		},
		["Pet"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 767.5,
				},
			},
		},
		["Player"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 742.5,
				},
			},
		},
		["EnemyCasts"] = {
		},
		["GCD"] = {
		},
		["Focus"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 767.5,
				},
			},
		},
		["Target"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 767.5,
				},
			},
		},
		["Mirror"] = {
		},
		["Range"] = {
		},
		["Latency"] = {
		},
	},
	["profileKeys"] = {
		["Romanyieky - 菲拉斯"] = "Default",
		["我死你要陪 - 菲拉斯"] = "Default",
		["诡沭妖姬 - 菲拉斯"] = "Default",
		["Viser - 山丘之王"] = "Default",
		["Romantidead - 菲拉斯"] = "Default",
		["澜本嫁依 - 菲拉斯"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
