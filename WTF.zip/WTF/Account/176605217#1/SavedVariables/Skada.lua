
SkadaDB = {
	["profileKeys"] = {
		["Romantidead - 菲拉斯"] = "Default",
		["我死你要陪 - 菲拉斯"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["windows"] = {
				{
					["hidden"] = true,
					["y"] = -0.0001220703125,
					["point"] = "CENTER",
					["x"] = 0,
				}, -- [1]
			},
			["versions"] = {
				["1.6.7"] = true,
				["1.6.4"] = true,
				["1.6.3"] = true,
			},
		},
	},
}
