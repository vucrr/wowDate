
SkadaDB = {
	["profileKeys"] = {
		["Romanyieky - 菲拉斯"] = "Default",
		["我死你要陪 - 菲拉斯"] = "Default",
		["诡沭妖姬 - 菲拉斯"] = "Default",
		["Viser - 山丘之王"] = "Default",
		["Romantidead - 菲拉斯"] = "Default",
		["澜本嫁依 - 菲拉斯"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["windows"] = {
				{
					["hidden"] = true,
					["y"] = -0.0001373291015625,
					["point"] = "CENTER",
					["x"] = -3.05175781250e-05,
				}, -- [1]
			},
			["versions"] = {
				["1.6.7"] = true,
				["1.6.4"] = true,
				["1.6.3"] = true,
			},
		},
	},
}
