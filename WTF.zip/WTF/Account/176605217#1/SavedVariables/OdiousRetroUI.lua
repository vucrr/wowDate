
leftEndOffset = nil
rightEndOffset = nil
mbOffset = nil
actBarOffset = nil
xpBarOffset = nil
mbgScale = nil
mbScale = nil
mbgOffset = nil
barScale = nil
babScale = nil
