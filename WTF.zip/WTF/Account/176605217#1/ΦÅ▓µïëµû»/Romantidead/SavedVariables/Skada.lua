
SkadaPerCharDB = {
	["sets"] = {
	},
}
