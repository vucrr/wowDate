
BattlefieldMapOptions = {
	["locked"] = true,
	["opacity"] = 0.7,
	["showPlayers"] = true,
}
