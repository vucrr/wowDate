
MapsterDB = {
	["namespaces"] = {
		["FogClear"] = {
		},
		["Coords"] = {
		},
	},
	["profileKeys"] = {
		["Remo - 影之哀伤"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
