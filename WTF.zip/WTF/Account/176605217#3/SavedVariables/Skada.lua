
SkadaDB = {
	["profileKeys"] = {
		["Remo - 影之哀伤"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["modeclicks"] = {
				["伤害"] = 1,
			},
			["windows"] = {
				{
					["y"] = -201.333160400391,
					["mode"] = "伤害",
					["point"] = "LEFT",
					["x"] = 41.3332672119141,
					["background"] = {
						["height"] = 153.333404541016,
					},
					["barwidth"] = 402.666839599609,
				}, -- [1]
			},
			["versions"] = {
				["1.6.3"] = true,
				["1.6.4"] = true,
				["1.6.7"] = true,
			},
		},
	},
}
