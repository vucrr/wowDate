
AngryKeystones_Config = {
	["__version"] = 1,
}
AngryKeystones_Data = {
	["state"] = {
	},
	["rumors"] = {
	},
	["progress"] = {
	},
	["splits"] = {
	},
}
