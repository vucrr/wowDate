
MapsterDB = {
	["namespaces"] = {
		["FogClear"] = {
		},
		["Coords"] = {
		},
	},
	["profileKeys"] = {
		["阿莱克斯祂萨 - 罗宁"] = "Default",
		["无心恋吹吹 - 罗宁"] = "Default",
		["Vucrr - 罗宁"] = "Default",
		["我不准我不准 - 影之哀伤"] = "Default",
		["红丝巾 - 血色十字军"] = "Default",
		["Romane - 影之哀伤"] = "Default",
		["我死你要陪 - 罗宁"] = "Default",
		["Ttyj - 影之哀伤"] = "Default",
		["Romante - 影之哀伤"] = "Default",
		["Romandead - 菲拉斯"] = "Default",
		["Viser - 菲拉斯"] = "Default",
		["Nodejs - 罗宁"] = "Default",
		["馨德拉 - 罗宁"] = "Default",
		["Romanv - 影之哀伤"] = "Default",
		["放逐灬之刃 - 罗宁"] = "Default",
		["任凭空虚斐疼 - 菲拉斯"] = "Default",
		["嘴角一抹血 - 菲拉斯"] = "Default",
		["Cwx - 影之哀伤"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
