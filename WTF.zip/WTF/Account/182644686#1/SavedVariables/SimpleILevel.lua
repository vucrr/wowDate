
SIL_Settings = {
	["profileKeys"] = {
		["Romante - 影之哀伤"] = "Default",
	},
	["global"] = {
		["cinfo"] = true,
		["version"] = 3,
	},
}
SIL_CacheGUID = {
	["Player-2133-084528F6"] = {
		["items"] = 16,
		["name"] = "Romante",
		["time"] = 1535081289,
		["level"] = 120,
		["target"] = "player",
		["class"] = "DEMONHUNTER",
		["score"] = 329.0625,
		["realm"] = "影之哀伤",
	},
}
