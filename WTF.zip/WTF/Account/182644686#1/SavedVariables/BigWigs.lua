
BigWigs3DB = {
	["profileKeys"] = {
		["Nodejs - 罗宁"] = "Default",
		["嘴角一抹血 - 菲拉斯"] = "Default",
		["红丝巾 - 血色十字军"] = "Default",
	},
	["namespaces"] = {
		["BigWigs_Plugins_Victory"] = {
		},
		["BigWigs_Plugins_BossBlock"] = {
		},
		["BigWigs_Plugins_Colors"] = {
		},
		["BigWigs_Plugins_Raid Icons"] = {
		},
		["BigWigs_Plugins_InfoBox"] = {
		},
		["BigWigs_Plugins_Bars"] = {
			["profiles"] = {
				["Default"] = {
					["tempSpacingReset"] = true,
					["BigWigsEmphasizeAnchor_height"] = 21.9999904632568,
					["tempMonoUIReset"] = true,
					["BigWigsAnchor_width"] = 219.999908447266,
					["BigWigsEmphasizeAnchor_width"] = 319.999938964844,
					["font"] = "默认",
					["BigWigsAnchor_height"] = 16.0000095367432,
				},
			},
		},
		["LibDualSpec-1.0"] = {
		},
		["BigWigs_Plugins_Super Emphasize"] = {
			["profiles"] = {
				["Default"] = {
					["font"] = "默认",
				},
			},
		},
		["BigWigs_Plugins_Sounds"] = {
		},
		["BigWigs_Plugins_AutoReply"] = {
		},
		["BigWigs_Plugins_Messages"] = {
			["profiles"] = {
				["Default"] = {
					["fontSize"] = 20,
					["font"] = "默认",
					["chat"] = true,
				},
			},
		},
		["BigWigs_Plugins_Statistics"] = {
		},
		["BigWigs_Plugins_Proximity"] = {
			["profiles"] = {
				["Default"] = {
					["font"] = "默认",
					["fontSize"] = 20,
				},
			},
		},
		["BigWigs_Plugins_Wipe"] = {
		},
		["BigWigs_Plugins_Pull"] = {
		},
		["BigWigs_Plugins_Alt Power"] = {
			["profiles"] = {
				["Default"] = {
					["font"] = "默认",
					["fontSize"] = 15,
					["fontOutline"] = "",
				},
			},
		},
	},
	["discord"] = 15,
	["profiles"] = {
		["Default"] = {
		},
	},
}
BigWigsIconDB = {
}
BigWigsStatsDB = {
}
