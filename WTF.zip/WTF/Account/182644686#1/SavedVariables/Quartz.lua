
Quartz3DB = {
	["namespaces"] = {
		["Swing"] = {
		},
		["Buff"] = {
		},
		["Interrupt"] = {
			["profiles"] = {
				["Default"] = {
					["interruptcolor"] = {
						nil, -- [1]
						nil, -- [2]
						nil, -- [3]
						1, -- [4]
					},
				},
			},
		},
		["Flight"] = {
		},
		["Pet"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 860,
				},
			},
		},
		["EnemyCasts"] = {
		},
		["Player"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 835,
				},
			},
		},
		["GCD"] = {
		},
		["Focus"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 860,
				},
			},
		},
		["Target"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 860,
				},
			},
		},
		["Range"] = {
		},
		["Mirror"] = {
		},
		["Latency"] = {
		},
	},
	["profileKeys"] = {
		["Wrwad - 菲拉斯"] = "Default",
		["阿莱克斯祂萨 - 罗宁"] = "Default",
		["Tesyt - 菲拉斯"] = "Default",
		["Testes - 血色十字军"] = "Default",
		["Cwx - 影之哀伤"] = "Default",
		["Romante - 影之哀伤"] = "Default",
		["我死你要陪 - 罗宁"] = "Default",
		["Ttyj - 影之哀伤"] = "Default",
		["诡沭妖姬 - 血色十字军"] = "Default",
		["馨德拉 - 罗宁"] = "Default",
		["绝版灬女飞贼 - 洛丹伦"] = "Default",
		["Romandead - 菲拉斯"] = "Default",
		["Viser - 菲拉斯"] = "Default",
		["任凭空虚斐疼 - 菲拉斯"] = "Default",
		["红丝巾 - 血色十字军"] = "Default",
		["放逐灬之刃 - 罗宁"] = "Default",
		["Romane - 血色十字军"] = "Default",
		["Nodejs - 罗宁"] = "Default",
		["嘴角一抹血 - 菲拉斯"] = "Default",
		["Romane - 影之哀伤"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
