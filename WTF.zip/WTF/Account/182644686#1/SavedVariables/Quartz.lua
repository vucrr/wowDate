
Quartz3DB = {
	["namespaces"] = {
		["Swing"] = {
		},
		["Buff"] = {
		},
		["Interrupt"] = {
			["profiles"] = {
				["Default"] = {
					["interruptcolor"] = {
						nil, -- [1]
						nil, -- [2]
						nil, -- [3]
						1, -- [4]
					},
				},
			},
		},
		["Flight"] = {
		},
		["Pet"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 860,
				},
			},
		},
		["Player"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 835,
				},
			},
		},
		["EnemyCasts"] = {
		},
		["GCD"] = {
		},
		["Focus"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 860,
				},
			},
		},
		["Target"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 860,
				},
			},
		},
		["Mirror"] = {
		},
		["Range"] = {
		},
		["Latency"] = {
		},
	},
	["profileKeys"] = {
		["Wrwad - 菲拉斯"] = "Default",
		["阿莱克斯祂萨 - 罗宁"] = "Default",
		["无心恋吹吹 - 罗宁"] = "Default",
		["Nodejs - 罗宁"] = "Default",
		["嘴角一抹血 - 菲拉斯"] = "Default",
		["任凭空虚斐疼 - 菲拉斯"] = "Default",
		["Vucrr - 罗宁"] = "Default",
		["我不准我不准 - 影之哀伤"] = "Default",
		["Viser - 菲拉斯"] = "Default",
		["Romanv - 影之哀伤"] = "Default",
		["Romane - 影之哀伤"] = "Default",
		["Tesyt - 菲拉斯"] = "Default",
		["Testes - 血色十字军"] = "Default",
		["Ttyj - 影之哀伤"] = "Default",
		["Romane - 血色十字军"] = "Default",
		["Romante - 影之哀伤"] = "Default",
		["我死你要陪 - 罗宁"] = "Default",
		["术伯特 - 罗宁"] = "Default",
		["Romandead - 菲拉斯"] = "Default",
		["红丝巾 - 血色十字军"] = "Default",
		["绝版灬女飞贼 - 洛丹伦"] = "Default",
		["Viser - 罗宁"] = "Default",
		["Cwx - 影之哀伤"] = "Default",
		["Ewt - 罗宁"] = "Default",
		["生涯最大诅咒 - 罗宁"] = "Default",
		["放逐灬之刃 - 罗宁"] = "Default",
		["馨德拉 - 罗宁"] = "Default",
		["术生 - 罗宁"] = "Default",
		["诡沭妖姬 - 血色十字军"] = "Default",
		["書生 - 罗宁"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
