
PlateColorDB = {
	["zb"] = true,
	["arrow"] = false,
	["scale"] = false,
	["mb"] = false,
	["ch"] = true,
	["name"] = true,
	["zsx"] = 0.35,
	["zs"] = false,
	["jian"] = false,
}
