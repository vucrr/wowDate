
SkadaPerCharDB = {
	["total"] = {
		["healingabsorbed"] = 0,
		["auras"] = {
		},
		["ccbreaks"] = 0,
		["time"] = 300,
		["interrupts"] = 0,
		["damage"] = 1476,
		["players"] = {
			{
				["healingabsorbed"] = 0,
				["class"] = "WARLOCK",
				["damaged"] = {
				},
				["dispells"] = 0,
				["role"] = "NONE",
				["time"] = 268,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedonespells"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 1476,
				["damagespells"] = {
					["吉尔尼斯猎犬: 攻击"] = {
						["hitmin"] = 1,
						["criticalamount"] = 2,
						["id"] = 6603,
						["criticalmin"] = 1,
						["hitamount"] = 4,
						["critical"] = 2,
						["min"] = 1,
						["criticalmax"] = 1,
						["hitmax"] = 1,
						["hit"] = 4,
						["school"] = 1,
						["max"] = 1,
						["totalhits"] = 6,
						["damage"] = 6,
					},
					["腐蚀术"] = {
						["hitmin"] = 1,
						["criticalamount"] = 150,
						["id"] = 146739,
						["criticalmin"] = 2,
						["hitamount"] = 837,
						["critical"] = 21,
						["min"] = 1,
						["criticalmax"] = 8,
						["hitmax"] = 4,
						["hit"] = 224,
						["school"] = 32,
						["max"] = 8,
						["totalhits"] = 245,
						["damage"] = 987,
					},
					["暗影箭"] = {
						["hitmin"] = 13,
						["id"] = 232670,
						["EVADE"] = 2,
						["min"] = 13,
						["hitamount"] = 483,
						["hitmax"] = 20,
						["hit"] = 30,
						["school"] = 32,
						["max"] = 20,
						["totalhits"] = 32,
						["damage"] = 483,
					},
				},
				["maxhp"] = 279,
				["healed"] = {
					["Player-729-04D9AAF2"] = {
						["role"] = "NONE",
						["name"] = "术伯特",
						["amount"] = 169,
						["class"] = "WARLOCK",
						["shielding"] = 0,
					},
				},
				["power"] = {
				},
				["id"] = "Player-729-04D9AAF2",
				["damagetaken"] = 1004,
				["damagetakenspells"] = {
					["攻击"] = {
						["crushing"] = 0,
						["id"] = 6603,
						["min"] = 1,
						["school"] = 1,
						["critical"] = 0,
						["glancing"] = 0,
						["absorbed"] = 0,
						["name"] = "攻击",
						["blocked"] = 0,
						["totalhits"] = 273,
						["resisted"] = 0,
						["max"] = 7,
						["damage"] = 1004,
					},
				},
				["deathlog"] = {
					{
						["ts"] = 1551455905.236,
						["amount"] = -5,
						["hp"] = 264,
						["srcname"] = "血牙潜伏者",
						["spellid"] = 88163,
					}, -- [1]
					{
						["ts"] = 1551455905.922,
						["amount"] = -5,
						["hp"] = 255,
						["spellid"] = 88163,
						["srcname"] = "血牙潜伏者",
					}, -- [2]
					{
						["ts"] = 1551455906.971,
						["amount"] = -6,
						["hp"] = 250,
						["spellid"] = 88163,
						["srcname"] = "血牙潜伏者",
					}, -- [3]
					{
						["hp"] = 250,
						["amount"] = -5,
						["ts"] = 1551455907.055,
						["spellid"] = 88163,
						["srcname"] = "血牙潜伏者",
					}, -- [4]
					{
						["ts"] = 1551455907.52,
						["amount"] = -5,
						["hp"] = 239,
						["srcname"] = "血牙潜伏者",
						["spellid"] = 88163,
					}, -- [5]
					{
						["ts"] = 1551455908.437,
						["absorb"] = 0,
						["amount"] = 7,
						["hp"] = 241,
						["spellid"] = 59913,
						["srcname"] = "术伯特",
					}, -- [6]
					{
						["ts"] = 1551455909.203,
						["amount"] = -6,
						["hp"] = 241,
						["spellid"] = 88163,
						["srcname"] = "血牙潜伏者",
					}, -- [7]
					{
						["ts"] = 1551455909.203,
						["amount"] = -6,
						["hp"] = 241,
						["spellid"] = 88163,
						["srcname"] = "血牙潜伏者",
					}, -- [8]
					{
						["hp"] = 229,
						["amount"] = -6,
						["ts"] = 1551455910.752,
						["spellid"] = 88163,
						["srcname"] = "血牙潜伏者",
					}, -- [9]
					{
						["ts"] = 1551455910.752,
						["absorb"] = 0,
						["amount"] = 8,
						["hp"] = 237,
						["spellid"] = 59913,
						["srcname"] = "术伯特",
					}, -- [10]
					{
						["ts"] = 1551455911.139,
						["amount"] = -5,
						["hp"] = 231,
						["spellid"] = 88163,
						["srcname"] = "血牙潜伏者",
					}, -- [11]
					{
						["ts"] = 1551455912.771,
						["amount"] = -6,
						["hp"] = 226,
						["spellid"] = 88163,
						["srcname"] = "血牙潜伏者",
					}, -- [12]
					{
						["ts"] = 1551455913.053,
						["absorb"] = 0,
						["amount"] = 7,
						["hp"] = 227,
						["spellid"] = 59913,
						["srcname"] = "术伯特",
					}, -- [13]
					{
						["hp"] = 271,
						["amount"] = -7,
						["ts"] = 1551455904.021,
						["spellid"] = 88163,
						["srcname"] = "血牙潜伏者",
					}, -- [14]
					{
						["ts"] = 1551455905.236,
						["amount"] = -4,
						["hp"] = 264,
						["spellid"] = 88163,
						["srcname"] = "血牙潜伏者",
					}, -- [15]
					["pos"] = 14,
				},
				["overhealing"] = 74,
				["name"] = "术伯特",
				["healingspells"] = {
					["迅捷的正义之手"] = {
						["shielding"] = 0,
						["id"] = 59913,
						["healing"] = 169,
						["min"] = 0,
						["name"] = "迅捷的正义之手",
						["max"] = 8,
						["critical"] = 0,
						["absorbed"] = 0,
						["overhealing"] = 74,
						["hits"] = 33,
					},
				},
				["shielding"] = 0,
				["healing"] = 169,
				["auras"] = {
					["腐蚀术"] = {
						["uptime"] = 185,
						["active"] = 0,
						["auratype"] = "DEBUFF",
						["school"] = 32,
						["name"] = "腐蚀术",
						["id"] = 146739,
					},
				},
				["ccbreaks"] = 0,
			}, -- [1]
		},
		["deaths"] = 0,
		["mobs"] = {
			["暴怒的狼人"] = {
				["players"] = {
					["术伯特"] = {
						["taken"] = 367,
						["done"] = 212,
						["role"] = "NONE",
						["class"] = "WARLOCK",
					},
				},
				["hdone"] = 0,
				["htakenspell"] = {
				},
				["taken"] = 367,
				["done"] = 212,
				["htaken"] = 0,
				["hdonespell"] = {
				},
			},
			["血牙潜伏者"] = {
				["players"] = {
					["术伯特"] = {
						["taken"] = 336,
						["done"] = 206,
						["role"] = "NONE",
						["class"] = "WARLOCK",
					},
				},
				["hdone"] = 0,
				["htakenspell"] = {
				},
				["taken"] = 336,
				["done"] = 206,
				["htaken"] = 0,
				["hdonespell"] = {
				},
			},
			["达利乌斯·克罗雷领主"] = {
				["players"] = {
				},
				["hdone"] = 259,
				["htakenspell"] = {
					["叛军勇气"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 3,
						["healing"] = 14,
						["overhealing"] = 4738,
						["hits"] = 72,
					},
				},
				["taken"] = 0,
				["done"] = 0,
				["htaken"] = 14,
				["hdonespell"] = {
					["叛军勇气"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 9,
						["healing"] = 259,
						["overhealing"] = 474456,
						["hits"] = 247,
					},
				},
			},
			["吉尔尼斯皇家卫兵"] = {
				["players"] = {
				},
				["hdone"] = 0,
				["htakenspell"] = {
					["叛军勇气"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 5,
						["healing"] = 188,
						["overhealing"] = 463412,
						["hits"] = 61,
					},
				},
				["taken"] = 0,
				["done"] = 0,
				["htaken"] = 188,
				["hdonespell"] = {
				},
			},
			["血牙狼人"] = {
				["players"] = {
					["术伯特"] = {
						["taken"] = 301,
						["done"] = 374,
						["role"] = "NONE",
						["class"] = "WARLOCK",
					},
				},
				["hdone"] = 0,
				["htakenspell"] = {
				},
				["taken"] = 301,
				["done"] = 374,
				["htaken"] = 0,
				["hdonespell"] = {
				},
			},
			["托比亚斯·密斯特曼托"] = {
				["players"] = {
				},
				["hdone"] = 0,
				["htakenspell"] = {
					["叛军勇气"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 2,
						["healing"] = 5,
						["overhealing"] = 339,
						["hits"] = 65,
					},
				},
				["taken"] = 0,
				["done"] = 0,
				["htaken"] = 5,
				["hdonespell"] = {
				},
			},
			["天黑黑丶-死亡之翼"] = {
				["players"] = {
				},
				["hdone"] = 0,
				["htakenspell"] = {
					["迅捷的正义之手"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 0,
						["healing"] = 0,
						["overhealing"] = 32,
						["hits"] = 4,
					},
				},
				["taken"] = 0,
				["done"] = 0,
				["htaken"] = 0,
				["hdonespell"] = {
					["迅捷的正义之手"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 0,
						["healing"] = 0,
						["overhealing"] = 32,
						["hits"] = 4,
					},
				},
			},
			["冲啊丶皮卡丘-回音山"] = {
				["players"] = {
				},
				["hdone"] = 69,
				["htakenspell"] = {
					["迅捷的正义之手"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 7,
						["healing"] = 69,
						["overhealing"] = 348,
						["hits"] = 60,
					},
					["叛军勇气"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 9,
						["healing"] = 52,
						["overhealing"] = 1631,
						["hits"] = 48,
					},
				},
				["taken"] = 0,
				["done"] = 0,
				["htaken"] = 121,
				["hdonespell"] = {
					["迅捷的正义之手"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 7,
						["healing"] = 69,
						["overhealing"] = 348,
						["hits"] = 60,
					},
				},
			},
			["狼人幼崽"] = {
				["players"] = {
					["术伯特"] = {
						["taken"] = 469,
						["done"] = 212,
						["role"] = "NONE",
						["class"] = "WARLOCK",
					},
				},
				["hdone"] = 0,
				["htakenspell"] = {
				},
				["taken"] = 469,
				["done"] = 212,
				["htaken"] = 0,
				["hdonespell"] = {
				},
			},
			["富兰克林·马丁"] = {
				["players"] = {
				},
				["hdone"] = 0,
				["htakenspell"] = {
					["叛军勇气"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 0,
						["healing"] = 0,
						["overhealing"] = 4336,
						["hits"] = 1,
					},
				},
				["taken"] = 0,
				["done"] = 0,
				["htaken"] = 0,
				["hdonespell"] = {
				},
			},
			["狼人前锋"] = {
				["players"] = {
					["术伯特"] = {
						["taken"] = 3,
						["done"] = 0,
						["role"] = "NONE",
						["class"] = "WARLOCK",
					},
				},
				["hdone"] = 0,
				["htakenspell"] = {
				},
				["taken"] = 3,
				["done"] = 0,
				["htaken"] = 0,
				["hdonespell"] = {
				},
			},
		},
		["mobtaken"] = 1476,
		["ffdamagedone"] = 0,
		["healing"] = 169,
		["damagetaken"] = 1004,
		["overhealing"] = 74,
		["shielding"] = 0,
		["starttime"] = 1551455246,
		["name"] = "总计",
		["dispells"] = 0,
		["power"] = {
		},
		["mobhdone"] = 328,
		["last_action"] = 1551455246,
		["mobdone"] = 1004,
	},
	["sets"] = {
		{
			["healingabsorbed"] = 0,
			["auras"] = {
			},
			["ccbreaks"] = 0,
			["time"] = 30,
			["interrupts"] = 0,
			["endtime"] = 1551455914,
			["dispells"] = 0,
			["damage"] = 181,
			["players"] = {
				{
					["last"] = 1551455913,
					["healingabsorbed"] = 0,
					["class"] = "WARLOCK",
					["damaged"] = {
						["血牙潜伏者"] = 181,
					},
					["dispells"] = 0,
					["role"] = "NONE",
					["time"] = 29,
					["interrupts"] = 0,
					["ffdamagedonetargets"] = {
					},
					["ffdamagedonespells"] = {
					},
					["damage"] = 181,
					["damagespells"] = {
						["吉尔尼斯猎犬: 攻击"] = {
							["hitmin"] = 1,
							["criticalamount"] = 2,
							["id"] = 6603,
							["hitmax"] = 1,
							["hitamount"] = 3,
							["criticalmin"] = 1,
							["min"] = 1,
							["criticalmax"] = 1,
							["critical"] = 2,
							["hit"] = 3,
							["school"] = 1,
							["max"] = 1,
							["totalhits"] = 5,
							["damage"] = 5,
						},
						["腐蚀术"] = {
							["hitmin"] = 1,
							["criticalamount"] = 7,
							["id"] = 146739,
							["criticalmin"] = 7,
							["hitamount"] = 73,
							["critical"] = 1,
							["min"] = 1,
							["criticalmax"] = 7,
							["hitmax"] = 4,
							["hit"] = 19,
							["school"] = 32,
							["max"] = 7,
							["totalhits"] = 20,
							["damage"] = 80,
						},
						["暗影箭"] = {
							["hitmin"] = 19,
							["id"] = 232670,
							["min"] = 19,
							["hitamount"] = 96,
							["hitmax"] = 20,
							["hit"] = 5,
							["school"] = 32,
							["max"] = 20,
							["totalhits"] = 5,
							["damage"] = 96,
						},
					},
					["ffdamagedone"] = 0,
					["healed"] = {
						["Player-729-04D9AAF2"] = {
							["role"] = "NONE",
							["name"] = "术伯特",
							["amount"] = 22,
							["class"] = "WARLOCK",
							["shielding"] = 0,
						},
					},
					["power"] = {
					},
					["id"] = "Player-729-04D9AAF2",
					["first"] = 1551455884,
					["damagetaken"] = 140,
					["damagetakenspells"] = {
						["攻击"] = {
							["crushing"] = 0,
							["id"] = 6603,
							["min"] = 4,
							["school"] = 1,
							["critical"] = 0,
							["glancing"] = 0,
							["absorbed"] = 0,
							["name"] = "攻击",
							["blocked"] = 0,
							["totalhits"] = 25,
							["resisted"] = 0,
							["max"] = 7,
							["damage"] = 140,
						},
					},
					["maxhp"] = 387,
					["overhealing"] = 0,
					["name"] = "术伯特",
					["healingspells"] = {
						["迅捷的正义之手"] = {
							["shielding"] = 0,
							["id"] = 59913,
							["healing"] = 22,
							["min"] = 7,
							["name"] = "迅捷的正义之手",
							["max"] = 8,
							["critical"] = 0,
							["absorbed"] = 0,
							["overhealing"] = 0,
							["hits"] = 3,
						},
					},
					["shielding"] = 0,
					["healing"] = 22,
					["auras"] = {
						["腐蚀术"] = {
							["school"] = 32,
							["name"] = "腐蚀术",
							["active"] = 0,
							["id"] = 146739,
							["auratype"] = "DEBUFF",
							["uptime"] = 26,
						},
					},
					["ccbreaks"] = 0,
				}, -- [1]
			},
			["deaths"] = 0,
			["mobs"] = {
				["冲啊丶皮卡丘-回音山"] = {
					["players"] = {
					},
					["hdone"] = 5,
					["htakenspell"] = {
						["迅捷的正义之手"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 5,
							["healing"] = 5,
							["overhealing"] = 9,
							["hits"] = 2,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 5,
					["hdonespell"] = {
						["迅捷的正义之手"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 5,
							["healing"] = 5,
							["overhealing"] = 9,
							["hits"] = 2,
						},
					},
				},
				["血牙潜伏者"] = {
					["players"] = {
						["术伯特"] = {
							["taken"] = 181,
							["done"] = 140,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 181,
					["done"] = 140,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
			},
			["mobtaken"] = 181,
			["ffdamagedone"] = 0,
			["healing"] = 22,
			["damagetaken"] = 140,
			["overhealing"] = 0,
			["shielding"] = 0,
			["starttime"] = 1551455884,
			["name"] = "血牙潜伏者 (3)",
			["mobname"] = "血牙潜伏者",
			["power"] = {
			},
			["mobhdone"] = 5,
			["last_action"] = 1551455884,
			["mobdone"] = 140,
		}, -- [1]
		{
			["healingabsorbed"] = 0,
			["auras"] = {
			},
			["ccbreaks"] = 0,
			["time"] = 10,
			["interrupts"] = 0,
			["endtime"] = 1551455879,
			["dispells"] = 0,
			["damage"] = 55,
			["players"] = {
				{
					["last"] = 1551455877,
					["healingabsorbed"] = 0,
					["class"] = "WARLOCK",
					["damaged"] = {
						["血牙潜伏者"] = 55,
					},
					["dispells"] = 0,
					["role"] = "NONE",
					["time"] = 8,
					["interrupts"] = 0,
					["ffdamagedonetargets"] = {
					},
					["ffdamagedonespells"] = {
					},
					["damage"] = 55,
					["damagespells"] = {
						["吉尔尼斯猎犬: 攻击"] = {
							["hitmin"] = 1,
							["id"] = 6603,
							["min"] = 1,
							["hitamount"] = 1,
							["hitmax"] = 1,
							["hit"] = 1,
							["school"] = 1,
							["max"] = 1,
							["totalhits"] = 1,
							["damage"] = 1,
						},
						["腐蚀术"] = {
							["hitmin"] = 4,
							["id"] = 146739,
							["min"] = 4,
							["hitamount"] = 16,
							["hitmax"] = 4,
							["hit"] = 4,
							["school"] = 32,
							["max"] = 4,
							["totalhits"] = 4,
							["damage"] = 16,
						},
						["暗影箭"] = {
							["hitmin"] = 19,
							["id"] = 232670,
							["min"] = 19,
							["hitamount"] = 38,
							["hitmax"] = 19,
							["hit"] = 2,
							["school"] = 32,
							["max"] = 19,
							["totalhits"] = 2,
							["damage"] = 38,
						},
					},
					["ffdamagedone"] = 0,
					["healed"] = {
						["Player-729-04D9AAF2"] = {
							["role"] = "NONE",
							["name"] = "术伯特",
							["amount"] = 7,
							["class"] = "WARLOCK",
							["shielding"] = 0,
						},
					},
					["power"] = {
					},
					["id"] = "Player-729-04D9AAF2",
					["first"] = 1551455869,
					["damagetaken"] = 17,
					["damagetakenspells"] = {
						["攻击"] = {
							["crushing"] = 0,
							["id"] = 6603,
							["min"] = 4,
							["school"] = 1,
							["critical"] = 0,
							["glancing"] = 0,
							["absorbed"] = 0,
							["name"] = "攻击",
							["blocked"] = 0,
							["totalhits"] = 3,
							["resisted"] = 0,
							["max"] = 7,
							["damage"] = 17,
						},
					},
					["maxhp"] = 387,
					["overhealing"] = 0,
					["name"] = "术伯特",
					["healingspells"] = {
						["迅捷的正义之手"] = {
							["shielding"] = 0,
							["id"] = 59913,
							["healing"] = 7,
							["min"] = 7,
							["name"] = "迅捷的正义之手",
							["max"] = 7,
							["critical"] = 0,
							["absorbed"] = 0,
							["overhealing"] = 0,
							["hits"] = 1,
						},
					},
					["shielding"] = 0,
					["healing"] = 7,
					["auras"] = {
						["腐蚀术"] = {
							["school"] = 32,
							["name"] = "腐蚀术",
							["active"] = 0,
							["id"] = 146739,
							["auratype"] = "DEBUFF",
							["uptime"] = 8,
						},
					},
					["ccbreaks"] = 0,
				}, -- [1]
			},
			["deaths"] = 0,
			["mobs"] = {
				["冲啊丶皮卡丘-回音山"] = {
					["players"] = {
					},
					["hdone"] = 27,
					["htakenspell"] = {
						["迅捷的正义之手"] = {
							["min"] = 6,
							["crits"] = 0,
							["max"] = 7,
							["healing"] = 27,
							["overhealing"] = 1,
							["hits"] = 4,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 27,
					["hdonespell"] = {
						["迅捷的正义之手"] = {
							["min"] = 6,
							["crits"] = 0,
							["max"] = 7,
							["healing"] = 27,
							["overhealing"] = 1,
							["hits"] = 4,
						},
					},
				},
				["血牙潜伏者"] = {
					["players"] = {
						["术伯特"] = {
							["taken"] = 55,
							["done"] = 17,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 55,
					["done"] = 17,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
			},
			["mobtaken"] = 55,
			["ffdamagedone"] = 0,
			["healing"] = 7,
			["damagetaken"] = 17,
			["overhealing"] = 0,
			["shielding"] = 0,
			["starttime"] = 1551455869,
			["name"] = "血牙潜伏者 (2)",
			["mobname"] = "血牙潜伏者",
			["power"] = {
			},
			["mobhdone"] = 27,
			["last_action"] = 1551455869,
			["mobdone"] = 17,
		}, -- [2]
		{
			["healingabsorbed"] = 0,
			["auras"] = {
			},
			["ccbreaks"] = 0,
			["time"] = 15,
			["interrupts"] = 0,
			["endtime"] = 1551455827,
			["dispells"] = 0,
			["damage"] = 100,
			["players"] = {
				{
					["last"] = 1551455826,
					["healingabsorbed"] = 0,
					["class"] = "WARLOCK",
					["damaged"] = {
						["血牙潜伏者"] = 100,
					},
					["dispells"] = 0,
					["role"] = "NONE",
					["time"] = 13,
					["interrupts"] = 0,
					["ffdamagedonetargets"] = {
					},
					["ffdamagedonespells"] = {
					},
					["damage"] = 100,
					["damagespells"] = {
						["腐蚀术"] = {
							["hitmin"] = 4,
							["criticalamount"] = 15,
							["id"] = 146739,
							["criticalmin"] = 7,
							["hitamount"] = 28,
							["critical"] = 2,
							["min"] = 4,
							["criticalmax"] = 8,
							["hitmax"] = 4,
							["hit"] = 7,
							["school"] = 32,
							["max"] = 8,
							["totalhits"] = 9,
							["damage"] = 43,
						},
						["暗影箭"] = {
							["hitmin"] = 19,
							["id"] = 232670,
							["min"] = 19,
							["hitamount"] = 57,
							["hitmax"] = 19,
							["hit"] = 3,
							["school"] = 32,
							["max"] = 19,
							["totalhits"] = 3,
							["damage"] = 57,
						},
					},
					["ffdamagedone"] = 0,
					["healed"] = {
						["Player-729-04D9AAF2"] = {
							["role"] = "NONE",
							["name"] = "术伯特",
							["amount"] = 16,
							["class"] = "WARLOCK",
							["shielding"] = 0,
						},
					},
					["power"] = {
					},
					["id"] = "Player-729-04D9AAF2",
					["first"] = 1551455813,
					["damagetaken"] = 49,
					["damagetakenspells"] = {
						["攻击"] = {
							["crushing"] = 0,
							["id"] = 6603,
							["min"] = 4,
							["school"] = 1,
							["critical"] = 0,
							["glancing"] = 0,
							["absorbed"] = 0,
							["name"] = "攻击",
							["blocked"] = 0,
							["totalhits"] = 9,
							["resisted"] = 0,
							["max"] = 6,
							["damage"] = 49,
						},
					},
					["maxhp"] = 387,
					["overhealing"] = 0,
					["name"] = "术伯特",
					["healingspells"] = {
						["迅捷的正义之手"] = {
							["shielding"] = 0,
							["id"] = 59913,
							["healing"] = 16,
							["min"] = 8,
							["name"] = "迅捷的正义之手",
							["max"] = 8,
							["critical"] = 0,
							["absorbed"] = 0,
							["overhealing"] = 0,
							["hits"] = 2,
						},
					},
					["shielding"] = 0,
					["healing"] = 16,
					["auras"] = {
						["腐蚀术"] = {
							["school"] = 32,
							["name"] = "腐蚀术",
							["active"] = 0,
							["id"] = 146739,
							["auratype"] = "DEBUFF",
							["uptime"] = 13,
						},
					},
					["ccbreaks"] = 0,
				}, -- [1]
			},
			["deaths"] = 0,
			["mobs"] = {
				["血牙潜伏者"] = {
					["players"] = {
						["术伯特"] = {
							["taken"] = 100,
							["done"] = 49,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 100,
					["done"] = 49,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
			},
			["mobtaken"] = 100,
			["ffdamagedone"] = 0,
			["healing"] = 16,
			["damagetaken"] = 49,
			["overhealing"] = 0,
			["shielding"] = 0,
			["starttime"] = 1551455812,
			["name"] = "血牙潜伏者",
			["mobname"] = "血牙潜伏者",
			["power"] = {
			},
			["mobhdone"] = 0,
			["last_action"] = 1551455812,
			["mobdone"] = 49,
		}, -- [3]
		{
			["healingabsorbed"] = 0,
			["auras"] = {
			},
			["ccbreaks"] = 0,
			["time"] = 33,
			["interrupts"] = 0,
			["endtime"] = 1551455781,
			["dispells"] = 0,
			["damage"] = 48,
			["players"] = {
				{
					["last"] = 1551455780,
					["healingabsorbed"] = 0,
					["class"] = "WARLOCK",
					["damaged"] = {
						["血牙狼人"] = 48,
					},
					["dispells"] = 0,
					["role"] = "NONE",
					["time"] = 28,
					["interrupts"] = 0,
					["ffdamagedonetargets"] = {
					},
					["ffdamagedonespells"] = {
					},
					["damage"] = 48,
					["damagespells"] = {
						["腐蚀术"] = {
							["hitmin"] = 3,
							["criticalamount"] = 9,
							["id"] = 146739,
							["criticalmin"] = 2,
							["hitamount"] = 39,
							["critical"] = 2,
							["min"] = 2,
							["criticalmax"] = 7,
							["hitmax"] = 4,
							["hit"] = 10,
							["school"] = 32,
							["max"] = 7,
							["totalhits"] = 12,
							["damage"] = 48,
						},
					},
					["ffdamagedone"] = 0,
					["healed"] = {
						["Player-729-04D9AAF2"] = {
							["role"] = "NONE",
							["name"] = "术伯特",
							["amount"] = 8,
							["class"] = "WARLOCK",
							["shielding"] = 0,
						},
					},
					["power"] = {
					},
					["id"] = "Player-729-04D9AAF2",
					["first"] = 1551455752,
					["damagetaken"] = 77,
					["damagetakenspells"] = {
						["攻击"] = {
							["crushing"] = 0,
							["id"] = 6603,
							["min"] = 5,
							["school"] = 1,
							["critical"] = 0,
							["glancing"] = 0,
							["absorbed"] = 0,
							["name"] = "攻击",
							["blocked"] = 0,
							["totalhits"] = 14,
							["resisted"] = 0,
							["max"] = 6,
							["damage"] = 77,
						},
					},
					["maxhp"] = 387,
					["overhealing"] = 0,
					["name"] = "术伯特",
					["healingspells"] = {
						["迅捷的正义之手"] = {
							["shielding"] = 0,
							["id"] = 59913,
							["healing"] = 8,
							["min"] = 8,
							["name"] = "迅捷的正义之手",
							["max"] = 8,
							["critical"] = 0,
							["absorbed"] = 0,
							["overhealing"] = 0,
							["hits"] = 1,
						},
					},
					["shielding"] = 0,
					["healing"] = 8,
					["auras"] = {
						["腐蚀术"] = {
							["school"] = 32,
							["name"] = "腐蚀术",
							["active"] = 0,
							["id"] = 146739,
							["auratype"] = "DEBUFF",
							["uptime"] = 22,
						},
					},
					["ccbreaks"] = 0,
				}, -- [1]
			},
			["deaths"] = 0,
			["mobs"] = {
				["天黑黑丶-死亡之翼"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["迅捷的正义之手"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 32,
							["hits"] = 4,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 0,
					["hdonespell"] = {
						["迅捷的正义之手"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 32,
							["hits"] = 4,
						},
					},
				},
				["托比亚斯·密斯特曼托"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 21,
							["hits"] = 4,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
				["富兰克林·马丁"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 4336,
							["hits"] = 1,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
				["冲啊丶皮卡丘-回音山"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 105,
							["hits"] = 3,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
				["吉尔尼斯皇家卫兵"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 45600,
							["hits"] = 6,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
				["达利乌斯·克罗雷领主"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 264,
							["hits"] = 4,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 0,
					["hdonespell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 50326,
							["hits"] = 18,
						},
					},
				},
				["血牙狼人"] = {
					["players"] = {
						["术伯特"] = {
							["taken"] = 48,
							["done"] = 77,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 48,
					["done"] = 77,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
			},
			["mobtaken"] = 48,
			["ffdamagedone"] = 0,
			["healing"] = 8,
			["damagetaken"] = 77,
			["overhealing"] = 0,
			["shielding"] = 0,
			["starttime"] = 1551455748,
			["name"] = "血牙狼人 (3)",
			["mobname"] = "血牙狼人",
			["power"] = {
			},
			["mobhdone"] = 0,
			["last_action"] = 1551455748,
			["mobdone"] = 77,
		}, -- [4]
		{
			["healingabsorbed"] = 0,
			["auras"] = {
			},
			["ccbreaks"] = 0,
			["time"] = 53,
			["interrupts"] = 0,
			["endtime"] = 1551455741,
			["dispells"] = 0,
			["damage"] = 213,
			["players"] = {
				{
					["last"] = 1551455740,
					["healingabsorbed"] = 0,
					["class"] = "WARLOCK",
					["damaged"] = {
						["血牙狼人"] = 213,
					},
					["dispells"] = 0,
					["role"] = "NONE",
					["time"] = 51,
					["interrupts"] = 0,
					["ffdamagedonetargets"] = {
					},
					["ffdamagedonespells"] = {
					},
					["damage"] = 213,
					["damagespells"] = {
						["腐蚀术"] = {
							["hitmin"] = 1,
							["criticalamount"] = 49,
							["id"] = 146739,
							["hitmax"] = 4,
							["hitamount"] = 145,
							["criticalmin"] = 2,
							["min"] = 1,
							["criticalmax"] = 8,
							["critical"] = 7,
							["hit"] = 38,
							["school"] = 32,
							["max"] = 8,
							["totalhits"] = 45,
							["damage"] = 194,
						},
						["暗影箭"] = {
							["hitmin"] = 19,
							["id"] = 232670,
							["min"] = 19,
							["hitamount"] = 19,
							["hitmax"] = 19,
							["hit"] = 1,
							["school"] = 32,
							["max"] = 19,
							["totalhits"] = 1,
							["damage"] = 19,
						},
					},
					["ffdamagedone"] = 0,
					["healed"] = {
						["Player-729-04D9AAF2"] = {
							["role"] = "NONE",
							["name"] = "术伯特",
							["amount"] = 40,
							["class"] = "WARLOCK",
							["shielding"] = 0,
						},
					},
					["power"] = {
					},
					["id"] = "Player-729-04D9AAF2",
					["first"] = 1551455689,
					["damagetaken"] = 266,
					["damagetakenspells"] = {
						["攻击"] = {
							["crushing"] = 0,
							["id"] = 6603,
							["min"] = 4,
							["school"] = 1,
							["critical"] = 0,
							["glancing"] = 0,
							["absorbed"] = 0,
							["name"] = "攻击",
							["blocked"] = 0,
							["totalhits"] = 52,
							["resisted"] = 0,
							["max"] = 7,
							["damage"] = 266,
						},
					},
					["maxhp"] = 387,
					["overhealing"] = 0,
					["name"] = "术伯特",
					["healingspells"] = {
						["迅捷的正义之手"] = {
							["shielding"] = 0,
							["id"] = 59913,
							["healing"] = 40,
							["min"] = 8,
							["name"] = "迅捷的正义之手",
							["max"] = 8,
							["critical"] = 0,
							["absorbed"] = 0,
							["overhealing"] = 0,
							["hits"] = 5,
						},
					},
					["shielding"] = 0,
					["healing"] = 40,
					["auras"] = {
						["腐蚀术"] = {
							["school"] = 32,
							["name"] = "腐蚀术",
							["active"] = 0,
							["id"] = 146739,
							["auratype"] = "DEBUFF",
							["uptime"] = 33,
						},
					},
					["ccbreaks"] = 0,
				}, -- [1]
			},
			["deaths"] = 0,
			["mobs"] = {
				["达利乌斯·克罗雷领主"] = {
					["players"] = {
					},
					["hdone"] = 84,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 1,
							["healing"] = 2,
							["overhealing"] = 1714,
							["hits"] = 26,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 2,
					["hdonespell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 9,
							["healing"] = 84,
							["overhealing"] = 101511,
							["hits"] = 91,
						},
					},
				},
				["冲啊丶皮卡丘-回音山"] = {
					["players"] = {
					},
					["hdone"] = 18,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 9,
							["healing"] = 39,
							["overhealing"] = 909,
							["hits"] = 27,
						},
						["迅捷的正义之手"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 7,
							["healing"] = 18,
							["overhealing"] = 110,
							["hits"] = 18,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 57,
					["hdonespell"] = {
						["迅捷的正义之手"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 7,
							["healing"] = 18,
							["overhealing"] = 110,
							["hits"] = 18,
						},
					},
				},
				["吉尔尼斯皇家卫兵"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 5,
							["healing"] = 40,
							["overhealing"] = 98760,
							["hits"] = 13,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 40,
					["hdonespell"] = {
					},
				},
				["托比亚斯·密斯特曼托"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 2,
							["healing"] = 3,
							["overhealing"] = 128,
							["hits"] = 25,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 3,
					["hdonespell"] = {
					},
				},
				["血牙狼人"] = {
					["players"] = {
						["术伯特"] = {
							["taken"] = 213,
							["done"] = 266,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 213,
					["done"] = 266,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
			},
			["mobtaken"] = 213,
			["ffdamagedone"] = 0,
			["healing"] = 40,
			["damagetaken"] = 266,
			["overhealing"] = 0,
			["shielding"] = 0,
			["starttime"] = 1551455688,
			["name"] = "血牙狼人 (2)",
			["mobname"] = "血牙狼人",
			["power"] = {
			},
			["mobhdone"] = 102,
			["last_action"] = 1551455688,
			["mobdone"] = 266,
		}, -- [5]
		{
			["healingabsorbed"] = 0,
			["auras"] = {
			},
			["ccbreaks"] = 0,
			["time"] = 23,
			["interrupts"] = 0,
			["endtime"] = 1551455672,
			["dispells"] = 0,
			["damage"] = 215,
			["players"] = {
				{
					["last"] = 1551455670,
					["healingabsorbed"] = 0,
					["class"] = "WARLOCK",
					["damaged"] = {
						["狼人幼崽"] = 212,
						["狼人前锋"] = 3,
					},
					["dispells"] = 0,
					["role"] = "NONE",
					["time"] = 21,
					["interrupts"] = 0,
					["ffdamagedonetargets"] = {
					},
					["ffdamagedonespells"] = {
					},
					["damage"] = 215,
					["damagespells"] = {
						["腐蚀术"] = {
							["hitmin"] = 3,
							["criticalamount"] = 8,
							["id"] = 146739,
							["criticalmin"] = 8,
							["hitamount"] = 207,
							["critical"] = 1,
							["min"] = 3,
							["criticalmax"] = 8,
							["hitmax"] = 4,
							["hit"] = 53,
							["school"] = 32,
							["max"] = 8,
							["totalhits"] = 54,
							["damage"] = 215,
						},
					},
					["ffdamagedone"] = 0,
					["healed"] = {
						["Player-729-04D9AAF2"] = {
							["role"] = "NONE",
							["name"] = "术伯特",
							["amount"] = 20,
							["class"] = "WARLOCK",
							["shielding"] = 0,
						},
					},
					["power"] = {
					},
					["id"] = "Player-729-04D9AAF2",
					["first"] = 1551455649,
					["damagetaken"] = 112,
					["damagetakenspells"] = {
						["攻击"] = {
							["crushing"] = 0,
							["id"] = 6603,
							["min"] = 1,
							["school"] = 1,
							["critical"] = 0,
							["glancing"] = 0,
							["absorbed"] = 0,
							["name"] = "攻击",
							["blocked"] = 0,
							["totalhits"] = 65,
							["resisted"] = 0,
							["max"] = 3,
							["damage"] = 112,
						},
					},
					["maxhp"] = 387,
					["overhealing"] = 27,
					["name"] = "术伯特",
					["healingspells"] = {
						["迅捷的正义之手"] = {
							["shielding"] = 0,
							["id"] = 59913,
							["healing"] = 20,
							["min"] = 0,
							["name"] = "迅捷的正义之手",
							["max"] = 8,
							["critical"] = 0,
							["absorbed"] = 0,
							["overhealing"] = 27,
							["hits"] = 6,
						},
					},
					["shielding"] = 0,
					["healing"] = 20,
					["auras"] = {
						["腐蚀术"] = {
							["school"] = 32,
							["name"] = "腐蚀术",
							["active"] = 0,
							["id"] = 146739,
							["auratype"] = "DEBUFF",
							["uptime"] = 20,
						},
					},
					["ccbreaks"] = 0,
				}, -- [1]
			},
			["deaths"] = 0,
			["mobs"] = {
				["达利乌斯·克罗雷领主"] = {
					["players"] = {
					},
					["hdone"] = 59,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 726,
							["hits"] = 11,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 0,
					["hdonespell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 5,
							["healing"] = 59,
							["overhealing"] = 92305,
							["hits"] = 44,
						},
					},
				},
				["狼人幼崽"] = {
					["players"] = {
						["术伯特"] = {
							["taken"] = 212,
							["done"] = 112,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 212,
					["done"] = 112,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
				["冲啊丶皮卡丘-回音山"] = {
					["players"] = {
					},
					["hdone"] = 10,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 5,
							["healing"] = 13,
							["overhealing"] = 372,
							["hits"] = 11,
						},
						["迅捷的正义之手"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 4,
							["healing"] = 10,
							["overhealing"] = 130,
							["hits"] = 20,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 23,
					["hdonespell"] = {
						["迅捷的正义之手"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 4,
							["healing"] = 10,
							["overhealing"] = 130,
							["hits"] = 20,
						},
					},
				},
				["吉尔尼斯皇家卫兵"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 3,
							["crits"] = 0,
							["max"] = 4,
							["healing"] = 44,
							["overhealing"] = 91156,
							["hits"] = 12,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 44,
					["hdonespell"] = {
					},
				},
				["托比亚斯·密斯特曼托"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 1,
							["healing"] = 2,
							["overhealing"] = 51,
							["hits"] = 10,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 2,
					["hdonespell"] = {
					},
				},
				["狼人前锋"] = {
					["players"] = {
						["术伯特"] = {
							["taken"] = 3,
							["done"] = 0,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 3,
					["done"] = 0,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
			},
			["mobtaken"] = 215,
			["ffdamagedone"] = 0,
			["healing"] = 20,
			["damagetaken"] = 112,
			["overhealing"] = 27,
			["shielding"] = 0,
			["starttime"] = 1551455649,
			["name"] = "狼人前锋",
			["mobname"] = "狼人前锋",
			["power"] = {
			},
			["mobhdone"] = 69,
			["last_action"] = 1551455649,
			["mobdone"] = 112,
		}, -- [6]
		{
			["healingabsorbed"] = 0,
			["auras"] = {
			},
			["ccbreaks"] = 0,
			["time"] = 19,
			["interrupts"] = 0,
			["endtime"] = 1551455608,
			["dispells"] = 0,
			["damage"] = 133,
			["players"] = {
				{
					["last"] = 1551455606,
					["healingabsorbed"] = 0,
					["class"] = "WARLOCK",
					["damaged"] = {
						["狼人幼崽"] = 133,
					},
					["dispells"] = 0,
					["role"] = "NONE",
					["time"] = 15,
					["interrupts"] = 0,
					["ffdamagedonetargets"] = {
					},
					["ffdamagedonespells"] = {
					},
					["damage"] = 133,
					["damagespells"] = {
						["腐蚀术"] = {
							["hitmin"] = 3,
							["criticalamount"] = 16,
							["id"] = 146739,
							["criticalmin"] = 8,
							["hitamount"] = 117,
							["critical"] = 2,
							["min"] = 3,
							["criticalmax"] = 8,
							["hitmax"] = 4,
							["hit"] = 31,
							["school"] = 32,
							["max"] = 8,
							["totalhits"] = 33,
							["damage"] = 133,
						},
					},
					["ffdamagedone"] = 0,
					["healed"] = {
						["Player-729-04D9AAF2"] = {
							["role"] = "NONE",
							["name"] = "术伯特",
							["amount"] = 2,
							["class"] = "WARLOCK",
							["shielding"] = 0,
						},
					},
					["power"] = {
					},
					["id"] = "Player-729-04D9AAF2",
					["first"] = 1551455591,
					["damagetaken"] = 75,
					["damagetakenspells"] = {
						["攻击"] = {
							["crushing"] = 0,
							["id"] = 6603,
							["min"] = 1,
							["school"] = 1,
							["critical"] = 0,
							["glancing"] = 0,
							["absorbed"] = 0,
							["name"] = "攻击",
							["blocked"] = 0,
							["totalhits"] = 42,
							["resisted"] = 0,
							["max"] = 3,
							["damage"] = 75,
						},
					},
					["maxhp"] = 387,
					["overhealing"] = 13,
					["name"] = "术伯特",
					["healingspells"] = {
						["迅捷的正义之手"] = {
							["shielding"] = 0,
							["id"] = 59913,
							["healing"] = 2,
							["min"] = 0,
							["name"] = "迅捷的正义之手",
							["max"] = 2,
							["critical"] = 0,
							["absorbed"] = 0,
							["overhealing"] = 13,
							["hits"] = 2,
						},
					},
					["shielding"] = 0,
					["healing"] = 2,
					["auras"] = {
						["腐蚀术"] = {
							["school"] = 32,
							["name"] = "腐蚀术",
							["active"] = 0,
							["id"] = 146739,
							["auratype"] = "DEBUFF",
							["uptime"] = 14,
						},
					},
					["ccbreaks"] = 0,
				}, -- [1]
			},
			["deaths"] = 0,
			["mobs"] = {
				["达利乌斯·克罗雷领主"] = {
					["players"] = {
					},
					["hdone"] = 44,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 3,
							["healing"] = 8,
							["overhealing"] = 586,
							["hits"] = 9,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 8,
					["hdonespell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 4,
							["healing"] = 44,
							["overhealing"] = 76738,
							["hits"] = 32,
						},
					},
				},
				["冲啊丶皮卡丘-回音山"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["迅捷的正义之手"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 28,
							["hits"] = 4,
						},
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 140,
							["hits"] = 4,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 0,
					["hdonespell"] = {
						["迅捷的正义之手"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 28,
							["hits"] = 4,
						},
					},
				},
				["吉尔尼斯皇家卫兵"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 3,
							["crits"] = 0,
							["max"] = 4,
							["healing"] = 36,
							["overhealing"] = 75964,
							["hits"] = 10,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 36,
					["hdonespell"] = {
					},
				},
				["狼人幼崽"] = {
					["players"] = {
						["术伯特"] = {
							["taken"] = 133,
							["done"] = 75,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 133,
					["done"] = 75,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
				["托比亚斯·密斯特曼托"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 48,
							["hits"] = 9,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
			},
			["mobtaken"] = 133,
			["ffdamagedone"] = 0,
			["healing"] = 2,
			["damagetaken"] = 75,
			["overhealing"] = 13,
			["shielding"] = 0,
			["starttime"] = 1551455589,
			["name"] = "狼人幼崽 (2)",
			["mobname"] = "狼人幼崽",
			["power"] = {
			},
			["mobhdone"] = 44,
			["last_action"] = 1551455589,
			["mobdone"] = 75,
		}, -- [7]
		{
			["healingabsorbed"] = 0,
			["auras"] = {
			},
			["ccbreaks"] = 0,
			["time"] = 19,
			["interrupts"] = 0,
			["endtime"] = 1551455579,
			["dispells"] = 0,
			["damage"] = 124,
			["players"] = {
				{
					["last"] = 1551455574,
					["healingabsorbed"] = 0,
					["class"] = "WARLOCK",
					["damaged"] = {
						["狼人幼崽"] = 124,
					},
					["dispells"] = 0,
					["role"] = "NONE",
					["time"] = 12,
					["interrupts"] = 0,
					["ffdamagedonetargets"] = {
					},
					["ffdamagedonespells"] = {
					},
					["damage"] = 124,
					["damagespells"] = {
						["腐蚀术"] = {
							["hitmin"] = 3,
							["criticalamount"] = 39,
							["id"] = 146739,
							["criticalmin"] = 7,
							["hitamount"] = 85,
							["critical"] = 5,
							["min"] = 3,
							["criticalmax"] = 8,
							["hitmax"] = 4,
							["hit"] = 23,
							["school"] = 32,
							["max"] = 8,
							["totalhits"] = 28,
							["damage"] = 124,
						},
					},
					["ffdamagedone"] = 0,
					["healed"] = {
						["Player-729-04D9AAF2"] = {
							["role"] = "NONE",
							["name"] = "术伯特",
							["amount"] = 4,
							["class"] = "WARLOCK",
							["shielding"] = 0,
						},
					},
					["power"] = {
					},
					["id"] = "Player-729-04D9AAF2",
					["first"] = 1551455562,
					["damagetaken"] = 25,
					["damagetakenspells"] = {
						["攻击"] = {
							["crushing"] = 0,
							["id"] = 6603,
							["min"] = 1,
							["school"] = 1,
							["critical"] = 0,
							["glancing"] = 0,
							["absorbed"] = 0,
							["name"] = "攻击",
							["blocked"] = 0,
							["totalhits"] = 14,
							["resisted"] = 0,
							["max"] = 2,
							["damage"] = 25,
						},
					},
					["maxhp"] = 387,
					["overhealing"] = 20,
					["name"] = "术伯特",
					["healingspells"] = {
						["迅捷的正义之手"] = {
							["shielding"] = 0,
							["id"] = 59913,
							["healing"] = 4,
							["min"] = 0,
							["name"] = "迅捷的正义之手",
							["max"] = 3,
							["critical"] = 0,
							["absorbed"] = 0,
							["overhealing"] = 20,
							["hits"] = 3,
						},
					},
					["shielding"] = 0,
					["healing"] = 4,
					["auras"] = {
						["腐蚀术"] = {
							["school"] = 32,
							["name"] = "腐蚀术",
							["active"] = 0,
							["id"] = 146739,
							["auratype"] = "DEBUFF",
							["uptime"] = 12,
						},
					},
					["ccbreaks"] = 0,
				}, -- [1]
			},
			["deaths"] = 0,
			["mobs"] = {
				["达利乌斯·克罗雷领主"] = {
					["players"] = {
					},
					["hdone"] = 34,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 2,
							["healing"] = 4,
							["overhealing"] = 590,
							["hits"] = 9,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 4,
					["hdonespell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 5,
							["healing"] = 34,
							["overhealing"] = 69004,
							["hits"] = 26,
						},
					},
				},
				["冲啊丶皮卡丘-回音山"] = {
					["players"] = {
					},
					["hdone"] = 9,
					["htakenspell"] = {
						["迅捷的正义之手"] = {
							["min"] = 2,
							["crits"] = 0,
							["max"] = 7,
							["healing"] = 9,
							["overhealing"] = 5,
							["hits"] = 2,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 9,
					["hdonespell"] = {
						["迅捷的正义之手"] = {
							["min"] = 2,
							["crits"] = 0,
							["max"] = 7,
							["healing"] = 9,
							["overhealing"] = 5,
							["hits"] = 2,
						},
					},
				},
				["吉尔尼斯皇家卫兵"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 5,
							["healing"] = 30,
							["overhealing"] = 68370,
							["hits"] = 9,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 30,
					["hdonespell"] = {
					},
				},
				["狼人幼崽"] = {
					["players"] = {
						["术伯特"] = {
							["taken"] = 124,
							["done"] = 25,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 124,
					["done"] = 25,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
				["托比亚斯·密斯特曼托"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 44,
							["hits"] = 8,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
			},
			["mobtaken"] = 124,
			["ffdamagedone"] = 0,
			["healing"] = 4,
			["damagetaken"] = 25,
			["overhealing"] = 20,
			["shielding"] = 0,
			["starttime"] = 1551455560,
			["name"] = "狼人幼崽",
			["mobname"] = "狼人幼崽",
			["power"] = {
			},
			["mobhdone"] = 43,
			["last_action"] = 1551455560,
			["mobdone"] = 25,
		}, -- [8]
		{
			["healingabsorbed"] = 0,
			["auras"] = {
			},
			["ccbreaks"] = 0,
			["time"] = 19,
			["interrupts"] = 0,
			["endtime"] = 1551455552,
			["dispells"] = 0,
			["damage"] = 40,
			["players"] = {
				{
					["last"] = 1551455551,
					["healingabsorbed"] = 0,
					["class"] = "WARLOCK",
					["damaged"] = {
						["血牙狼人"] = 40,
					},
					["dispells"] = 0,
					["role"] = "NONE",
					["time"] = 16,
					["interrupts"] = 0,
					["ffdamagedonetargets"] = {
					},
					["ffdamagedonespells"] = {
					},
					["damage"] = 40,
					["damagespells"] = {
						["腐蚀术"] = {
							["hitmin"] = 3,
							["id"] = 146739,
							["min"] = 3,
							["hitamount"] = 24,
							["hitmax"] = 4,
							["hit"] = 7,
							["school"] = 32,
							["max"] = 4,
							["totalhits"] = 7,
							["damage"] = 24,
						},
						["暗影箭"] = {
							["hitmin"] = 16,
							["id"] = 232670,
							["min"] = 16,
							["hitamount"] = 16,
							["hitmax"] = 16,
							["hit"] = 1,
							["school"] = 32,
							["max"] = 16,
							["totalhits"] = 1,
							["damage"] = 16,
						},
					},
					["ffdamagedone"] = 0,
					["healed"] = {
						["Player-729-04D9AAF2"] = {
							["role"] = "NONE",
							["name"] = "术伯特",
							["amount"] = 5,
							["class"] = "WARLOCK",
							["shielding"] = 0,
						},
					},
					["power"] = {
					},
					["id"] = "Player-729-04D9AAF2",
					["first"] = 1551455535,
					["damagetaken"] = 31,
					["damagetakenspells"] = {
						["攻击"] = {
							["crushing"] = 0,
							["id"] = 6603,
							["min"] = 4,
							["school"] = 1,
							["critical"] = 0,
							["glancing"] = 0,
							["absorbed"] = 0,
							["name"] = "攻击",
							["blocked"] = 0,
							["totalhits"] = 6,
							["resisted"] = 0,
							["max"] = 6,
							["damage"] = 31,
						},
					},
					["maxhp"] = 342,
					["overhealing"] = 2,
					["name"] = "术伯特",
					["healingspells"] = {
						["迅捷的正义之手"] = {
							["shielding"] = 0,
							["id"] = 59913,
							["healing"] = 5,
							["min"] = 5,
							["name"] = "迅捷的正义之手",
							["max"] = 5,
							["critical"] = 0,
							["absorbed"] = 0,
							["overhealing"] = 2,
							["hits"] = 1,
						},
					},
					["shielding"] = 0,
					["healing"] = 5,
					["auras"] = {
						["腐蚀术"] = {
							["school"] = 32,
							["name"] = "腐蚀术",
							["active"] = 0,
							["id"] = 146739,
							["auratype"] = "DEBUFF",
							["uptime"] = 10,
						},
					},
					["ccbreaks"] = 0,
				}, -- [1]
			},
			["deaths"] = 0,
			["mobs"] = {
				["托比亚斯·密斯特曼托"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 47,
							["hits"] = 9,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
				["冲啊丶皮卡丘-回音山"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["迅捷的正义之手"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 37,
							["hits"] = 6,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 0,
					["hdonespell"] = {
						["迅捷的正义之手"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 37,
							["hits"] = 6,
						},
					},
				},
				["吉尔尼斯皇家卫兵"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 3,
							["crits"] = 0,
							["max"] = 4,
							["healing"] = 31,
							["overhealing"] = 68369,
							["hits"] = 9,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 31,
					["hdonespell"] = {
					},
				},
				["达利乌斯·克罗雷领主"] = {
					["players"] = {
					},
					["hdone"] = 31,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 660,
							["hits"] = 10,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 0,
					["hdonespell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 4,
							["healing"] = 31,
							["overhealing"] = 69076,
							["hits"] = 28,
						},
					},
				},
				["血牙狼人"] = {
					["players"] = {
						["术伯特"] = {
							["taken"] = 40,
							["done"] = 31,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 40,
					["done"] = 31,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
			},
			["mobtaken"] = 40,
			["ffdamagedone"] = 0,
			["healing"] = 5,
			["damagetaken"] = 31,
			["overhealing"] = 2,
			["shielding"] = 0,
			["starttime"] = 1551455533,
			["name"] = "血牙狼人",
			["mobname"] = "血牙狼人",
			["power"] = {
			},
			["mobhdone"] = 31,
			["last_action"] = 1551455533,
			["mobdone"] = 31,
		}, -- [9]
		{
			["healingabsorbed"] = 0,
			["auras"] = {
			},
			["ccbreaks"] = 0,
			["time"] = 32,
			["interrupts"] = 0,
			["endtime"] = 1551455407,
			["dispells"] = 0,
			["damage"] = 110,
			["players"] = {
				{
					["last"] = 1551455405,
					["healingabsorbed"] = 0,
					["class"] = "WARLOCK",
					["damaged"] = {
						["暴怒的狼人"] = 110,
					},
					["dispells"] = 0,
					["role"] = "NONE",
					["time"] = 30,
					["interrupts"] = 0,
					["ffdamagedonetargets"] = {
					},
					["ffdamagedonespells"] = {
					},
					["damage"] = 110,
					["damagespells"] = {
						["腐蚀术"] = {
							["hitmin"] = 1,
							["criticalamount"] = 7,
							["id"] = 146739,
							["criticalmin"] = 7,
							["hitamount"] = 103,
							["critical"] = 1,
							["min"] = 1,
							["criticalmax"] = 7,
							["hitmax"] = 4,
							["hit"] = 32,
							["school"] = 32,
							["max"] = 7,
							["totalhits"] = 33,
							["damage"] = 110,
						},
					},
					["ffdamagedone"] = 0,
					["healed"] = {
						["Player-729-04D9AAF2"] = {
							["role"] = "NONE",
							["name"] = "术伯特",
							["amount"] = 21,
							["class"] = "WARLOCK",
							["shielding"] = 0,
						},
					},
					["power"] = {
					},
					["id"] = "Player-729-04D9AAF2",
					["first"] = 1551455375,
					["damagetaken"] = 140,
					["damagetakenspells"] = {
						["攻击"] = {
							["crushing"] = 0,
							["id"] = 6603,
							["min"] = 4,
							["school"] = 1,
							["critical"] = 0,
							["glancing"] = 0,
							["absorbed"] = 0,
							["name"] = "攻击",
							["blocked"] = 0,
							["totalhits"] = 28,
							["resisted"] = 0,
							["max"] = 6,
							["damage"] = 140,
						},
					},
					["maxhp"] = 342,
					["overhealing"] = 0,
					["name"] = "术伯特",
					["healingspells"] = {
						["迅捷的正义之手"] = {
							["shielding"] = 0,
							["id"] = 59913,
							["healing"] = 21,
							["min"] = 7,
							["name"] = "迅捷的正义之手",
							["max"] = 7,
							["critical"] = 0,
							["absorbed"] = 0,
							["overhealing"] = 0,
							["hits"] = 3,
						},
					},
					["shielding"] = 0,
					["healing"] = 21,
					["auras"] = {
						["腐蚀术"] = {
							["school"] = 32,
							["name"] = "腐蚀术",
							["active"] = 0,
							["id"] = 146739,
							["auratype"] = "DEBUFF",
							["uptime"] = 27,
						},
					},
					["ccbreaks"] = 0,
				}, -- [1]
			},
			["deaths"] = 0,
			["mobs"] = {
				["暴怒的狼人"] = {
					["players"] = {
						["术伯特"] = {
							["taken"] = 110,
							["done"] = 140,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 110,
					["done"] = 140,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
			},
			["mobtaken"] = 110,
			["ffdamagedone"] = 0,
			["healing"] = 21,
			["damagetaken"] = 140,
			["overhealing"] = 0,
			["shielding"] = 0,
			["starttime"] = 1551455375,
			["name"] = "暴怒的狼人 (6)",
			["mobname"] = "暴怒的狼人",
			["power"] = {
			},
			["mobhdone"] = 0,
			["last_action"] = 1551455375,
			["mobdone"] = 140,
		}, -- [10]
	},
}
