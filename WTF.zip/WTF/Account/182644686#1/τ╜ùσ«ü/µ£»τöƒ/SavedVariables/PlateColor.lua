
PlateColorDB = {
	["zb"] = true,
	["arrow"] = false,
	["scale"] = false,
	["mb"] = true,
	["ch"] = true,
	["name"] = true,
	["zsx"] = 0.35,
	["zs"] = false,
	["jian"] = true,
}
