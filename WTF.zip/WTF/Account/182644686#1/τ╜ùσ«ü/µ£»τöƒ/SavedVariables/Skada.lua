
SkadaPerCharDB = {
	["total"] = {
		["healingabsorbed"] = 0,
		["auras"] = {
		},
		["ccbreaks"] = 0,
		["time"] = 15,
		["interrupts"] = 0,
		["damage"] = 72,
		["players"] = {
			{
				["healingabsorbed"] = 0,
				["class"] = "WARLOCK",
				["damaged"] = {
				},
				["dispells"] = 0,
				["role"] = "NONE",
				["time"] = 13,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedonespells"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 72,
				["damagespells"] = {
					["暗影箭"] = {
						["hitmin"] = 14,
						["id"] = 232670,
						["min"] = 14,
						["hitamount"] = 72,
						["hitmax"] = 15,
						["hit"] = 5,
						["school"] = 32,
						["max"] = 15,
						["totalhits"] = 5,
						["damage"] = 72,
					},
				},
				["maxhp"] = 297,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Player-729-04D9AA8E",
				["damagetaken"] = 26,
				["damagetakenspells"] = {
					["攻击"] = {
						["crushing"] = 0,
						["id"] = 6603,
						["min"] = 4,
						["school"] = 1,
						["critical"] = 0,
						["glancing"] = 0,
						["absorbed"] = 0,
						["name"] = "攻击",
						["blocked"] = 0,
						["totalhits"] = 5,
						["resisted"] = 0,
						["max"] = 6,
						["damage"] = 26,
					},
				},
				["deathlog"] = {
					{
						["ts"] = 1551454722.718,
						["amount"] = -5,
						["hp"] = 297,
						["spellid"] = 88163,
						["srcname"] = "暴怒的狼人",
					}, -- [1]
					{
						["ts"] = 1551454724.751,
						["amount"] = -6,
						["hp"] = 292,
						["spellid"] = 88163,
						["srcname"] = "暴怒的狼人",
					}, -- [2]
					{
						["ts"] = 1551454726.77,
						["amount"] = -4,
						["hp"] = 286,
						["spellid"] = 88163,
						["srcname"] = "暴怒的狼人",
					}, -- [3]
					{
						["ts"] = 1551454728.768,
						["amount"] = -6,
						["hp"] = 282,
						["spellid"] = 88163,
						["srcname"] = "暴怒的狼人",
					}, -- [4]
					{
						["ts"] = 1551454825.249,
						["amount"] = -5,
						["hp"] = 315,
						["spellid"] = 88163,
						["srcname"] = "暴怒的狼人",
					}, -- [5]
					["pos"] = 6,
				},
				["overhealing"] = 0,
				["name"] = "术生",
				["healingspells"] = {
				},
				["shielding"] = 0,
				["healing"] = 0,
				["auras"] = {
				},
				["ccbreaks"] = 0,
			}, -- [1]
		},
		["deaths"] = 0,
		["mobs"] = {
			["暴怒的狼人"] = {
				["players"] = {
					["术生"] = {
						["taken"] = 72,
						["done"] = 26,
						["role"] = "NONE",
						["class"] = "WARLOCK",
					},
				},
				["hdone"] = 0,
				["htakenspell"] = {
				},
				["taken"] = 72,
				["done"] = 26,
				["htaken"] = 0,
				["hdonespell"] = {
				},
			},
		},
		["mobtaken"] = 72,
		["ffdamagedone"] = 0,
		["healing"] = 0,
		["damagetaken"] = 26,
		["overhealing"] = 0,
		["shielding"] = 0,
		["starttime"] = 1551454721,
		["name"] = "总计",
		["dispells"] = 0,
		["power"] = {
		},
		["mobhdone"] = 0,
		["last_action"] = 1551454721,
		["mobdone"] = 26,
	},
	["sets"] = {
		{
			["healingabsorbed"] = 0,
			["auras"] = {
			},
			["ccbreaks"] = 0,
			["time"] = 7,
			["interrupts"] = 0,
			["endtime"] = 1551454827,
			["dispells"] = 0,
			["damage"] = 44,
			["players"] = {
				{
					["last"] = 1551454826,
					["healingabsorbed"] = 0,
					["class"] = "WARLOCK",
					["damaged"] = {
						["暴怒的狼人"] = 44,
					},
					["dispells"] = 0,
					["role"] = "NONE",
					["time"] = 5,
					["interrupts"] = 0,
					["ffdamagedonetargets"] = {
					},
					["ffdamagedonespells"] = {
					},
					["damage"] = 44,
					["damagespells"] = {
						["暗影箭"] = {
							["hitmin"] = 14,
							["id"] = 232670,
							["min"] = 14,
							["hitamount"] = 44,
							["hitmax"] = 15,
							["hit"] = 3,
							["school"] = 32,
							["max"] = 15,
							["totalhits"] = 3,
							["damage"] = 44,
						},
					},
					["ffdamagedone"] = 0,
					["healed"] = {
					},
					["power"] = {
					},
					["id"] = "Player-729-04D9AA8E",
					["first"] = 1551454821,
					["damagetaken"] = 5,
					["damagetakenspells"] = {
						["攻击"] = {
							["crushing"] = 0,
							["id"] = 6603,
							["min"] = 5,
							["school"] = 1,
							["critical"] = 0,
							["glancing"] = 0,
							["absorbed"] = 0,
							["name"] = "攻击",
							["blocked"] = 0,
							["totalhits"] = 1,
							["resisted"] = 0,
							["max"] = 5,
							["damage"] = 5,
						},
					},
					["maxhp"] = 315,
					["overhealing"] = 0,
					["name"] = "术生",
					["healingspells"] = {
					},
					["shielding"] = 0,
					["healing"] = 0,
					["auras"] = {
					},
					["ccbreaks"] = 0,
				}, -- [1]
			},
			["deaths"] = 0,
			["mobs"] = {
				["暴怒的狼人"] = {
					["players"] = {
						["术生"] = {
							["taken"] = 44,
							["done"] = 5,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 44,
					["done"] = 5,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
			},
			["mobtaken"] = 44,
			["ffdamagedone"] = 0,
			["healing"] = 0,
			["damagetaken"] = 5,
			["overhealing"] = 0,
			["shielding"] = 0,
			["starttime"] = 1551454820,
			["name"] = "暴怒的狼人 (2)",
			["mobname"] = "暴怒的狼人",
			["power"] = {
			},
			["mobhdone"] = 0,
			["last_action"] = 1551454820,
			["mobdone"] = 5,
		}, -- [1]
		{
			["healingabsorbed"] = 0,
			["auras"] = {
			},
			["ccbreaks"] = 0,
			["time"] = 8,
			["interrupts"] = 0,
			["endtime"] = 1551454729,
			["dispells"] = 0,
			["damage"] = 28,
			["players"] = {
				{
					["last"] = 1551454729,
					["healingabsorbed"] = 0,
					["class"] = "WARLOCK",
					["damaged"] = {
						["暴怒的狼人"] = 28,
					},
					["dispells"] = 0,
					["role"] = "NONE",
					["time"] = 8,
					["interrupts"] = 0,
					["ffdamagedonetargets"] = {
					},
					["ffdamagedonespells"] = {
					},
					["damage"] = 28,
					["damagespells"] = {
						["暗影箭"] = {
							["hitmin"] = 14,
							["id"] = 232670,
							["min"] = 14,
							["hitamount"] = 28,
							["hitmax"] = 14,
							["hit"] = 2,
							["school"] = 32,
							["max"] = 14,
							["totalhits"] = 2,
							["damage"] = 28,
						},
					},
					["ffdamagedone"] = 0,
					["healed"] = {
					},
					["power"] = {
					},
					["id"] = "Player-729-04D9AA8E",
					["first"] = 1551454721,
					["damagetaken"] = 21,
					["damagetakenspells"] = {
						["攻击"] = {
							["crushing"] = 0,
							["id"] = 6603,
							["min"] = 4,
							["school"] = 1,
							["critical"] = 0,
							["glancing"] = 0,
							["absorbed"] = 0,
							["name"] = "攻击",
							["blocked"] = 0,
							["totalhits"] = 4,
							["resisted"] = 0,
							["max"] = 6,
							["damage"] = 21,
						},
					},
					["maxhp"] = 297,
					["overhealing"] = 0,
					["name"] = "术生",
					["healingspells"] = {
					},
					["shielding"] = 0,
					["healing"] = 0,
					["auras"] = {
					},
					["ccbreaks"] = 0,
				}, -- [1]
			},
			["deaths"] = 0,
			["mobs"] = {
				["暴怒的狼人"] = {
					["players"] = {
						["术生"] = {
							["taken"] = 28,
							["done"] = 21,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 28,
					["done"] = 21,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
			},
			["mobtaken"] = 28,
			["ffdamagedone"] = 0,
			["healing"] = 0,
			["damagetaken"] = 21,
			["overhealing"] = 0,
			["shielding"] = 0,
			["starttime"] = 1551454721,
			["name"] = "暴怒的狼人",
			["mobname"] = "暴怒的狼人",
			["power"] = {
			},
			["mobhdone"] = 0,
			["last_action"] = 1551454721,
			["mobdone"] = 21,
		}, -- [2]
	},
}
