
SkadaPerCharDB = {
	["sets"] = {
		{
			["healingabsorbed"] = 0,
			["auras"] = {
			},
			["ccbreaks"] = 0,
			["time"] = 9,
			["interrupts"] = 0,
			["endtime"] = 1551454246,
			["dispells"] = 0,
			["damage"] = 54,
			["players"] = {
				{
					["last"] = 1551454245,
					["healingabsorbed"] = 0,
					["class"] = "WARLOCK",
					["damaged"] = {
						["血牙潜伏者"] = 54,
					},
					["dispells"] = 0,
					["role"] = "NONE",
					["time"] = 8,
					["interrupts"] = 0,
					["ffdamagedonetargets"] = {
					},
					["ffdamagedonespells"] = {
					},
					["damage"] = 54,
					["damagespells"] = {
						["腐蚀术"] = {
							["hitmin"] = 4,
							["id"] = 146739,
							["min"] = 4,
							["hitamount"] = 16,
							["hitmax"] = 4,
							["hit"] = 4,
							["school"] = 32,
							["max"] = 4,
							["totalhits"] = 4,
							["damage"] = 16,
						},
						["暗影箭"] = {
							["hitmin"] = 19,
							["id"] = 232670,
							["min"] = 19,
							["hitamount"] = 38,
							["hitmax"] = 19,
							["hit"] = 2,
							["school"] = 32,
							["max"] = 19,
							["totalhits"] = 2,
							["damage"] = 38,
						},
					},
					["ffdamagedone"] = 0,
					["healed"] = {
					},
					["power"] = {
					},
					["id"] = "Player-729-04D8F3EB",
					["first"] = 1551454237,
					["damagetaken"] = 24,
					["damagetakenspells"] = {
						["攻击"] = {
							["crushing"] = 0,
							["id"] = 6603,
							["min"] = 4,
							["school"] = 1,
							["critical"] = 0,
							["glancing"] = 0,
							["absorbed"] = 0,
							["name"] = "攻击",
							["blocked"] = 0,
							["totalhits"] = 4,
							["resisted"] = 0,
							["max"] = 7,
							["damage"] = 24,
						},
					},
					["maxhp"] = 405,
					["overhealing"] = 0,
					["name"] = "書生",
					["healingspells"] = {
					},
					["shielding"] = 0,
					["healing"] = 0,
					["auras"] = {
					},
					["ccbreaks"] = 0,
				}, -- [1]
			},
			["deaths"] = 0,
			["mobs"] = {
				["血牙潜伏者"] = {
					["players"] = {
						["書生"] = {
							["taken"] = 54,
							["done"] = 24,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 54,
					["done"] = 24,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
			},
			["mobtaken"] = 54,
			["ffdamagedone"] = 0,
			["healing"] = 0,
			["damagetaken"] = 24,
			["overhealing"] = 0,
			["shielding"] = 0,
			["starttime"] = 1551454237,
			["name"] = "血牙潜伏者 (4)",
			["mobname"] = "血牙潜伏者",
			["power"] = {
			},
			["mobhdone"] = 0,
			["last_action"] = 1551454237,
			["mobdone"] = 24,
		}, -- [1]
		{
			["healingabsorbed"] = 0,
			["auras"] = {
			},
			["ccbreaks"] = 0,
			["time"] = 6,
			["interrupts"] = 0,
			["endtime"] = 1551454230,
			["dispells"] = 0,
			["damage"] = 50,
			["players"] = {
				{
					["last"] = 1551454230,
					["healingabsorbed"] = 0,
					["class"] = "WARLOCK",
					["damaged"] = {
						["血牙潜伏者"] = 50,
					},
					["dispells"] = 0,
					["role"] = "NONE",
					["time"] = 5,
					["interrupts"] = 0,
					["ffdamagedonetargets"] = {
					},
					["ffdamagedonespells"] = {
					},
					["damage"] = 50,
					["damagespells"] = {
						["腐蚀术"] = {
							["hitmin"] = 4,
							["id"] = 146739,
							["min"] = 4,
							["hitamount"] = 12,
							["hitmax"] = 4,
							["hit"] = 3,
							["school"] = 32,
							["max"] = 4,
							["totalhits"] = 3,
							["damage"] = 12,
						},
						["暗影箭"] = {
							["hitmin"] = 19,
							["id"] = 232670,
							["min"] = 19,
							["hitamount"] = 38,
							["hitmax"] = 19,
							["hit"] = 2,
							["school"] = 32,
							["max"] = 19,
							["totalhits"] = 2,
							["damage"] = 38,
						},
					},
					["ffdamagedone"] = 0,
					["healed"] = {
					},
					["power"] = {
					},
					["id"] = "Player-729-04D8F3EB",
					["first"] = 1551454225,
					["damagetaken"] = 17,
					["damagetakenspells"] = {
						["攻击"] = {
							["crushing"] = 0,
							["id"] = 6603,
							["min"] = 5,
							["school"] = 1,
							["critical"] = 0,
							["glancing"] = 0,
							["absorbed"] = 0,
							["name"] = "攻击",
							["blocked"] = 0,
							["totalhits"] = 3,
							["resisted"] = 0,
							["max"] = 7,
							["damage"] = 17,
						},
					},
					["maxhp"] = 405,
					["overhealing"] = 0,
					["name"] = "書生",
					["healingspells"] = {
					},
					["shielding"] = 0,
					["healing"] = 0,
					["auras"] = {
					},
					["ccbreaks"] = 0,
				}, -- [1]
			},
			["deaths"] = 0,
			["mobs"] = {
				["血牙潜伏者"] = {
					["players"] = {
						["書生"] = {
							["taken"] = 50,
							["done"] = 17,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 50,
					["done"] = 17,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
			},
			["mobtaken"] = 50,
			["ffdamagedone"] = 0,
			["healing"] = 0,
			["damagetaken"] = 17,
			["overhealing"] = 0,
			["shielding"] = 0,
			["starttime"] = 1551454224,
			["name"] = "血牙潜伏者 (3)",
			["mobname"] = "血牙潜伏者",
			["power"] = {
			},
			["mobhdone"] = 0,
			["last_action"] = 1551454224,
			["mobdone"] = 17,
		}, -- [2]
		{
			["healingabsorbed"] = 0,
			["auras"] = {
			},
			["ccbreaks"] = 0,
			["time"] = 10,
			["interrupts"] = 0,
			["endtime"] = 1551454181,
			["dispells"] = 0,
			["damage"] = 57,
			["players"] = {
				{
					["last"] = 1551454180,
					["healingabsorbed"] = 0,
					["class"] = "WARLOCK",
					["damaged"] = {
						["血牙潜伏者"] = 57,
					},
					["dispells"] = 0,
					["role"] = "NONE",
					["time"] = 9,
					["interrupts"] = 0,
					["ffdamagedonetargets"] = {
					},
					["ffdamagedonespells"] = {
					},
					["damage"] = 57,
					["damagespells"] = {
						["吉尔尼斯猎犬: 攻击"] = {
							["hitmin"] = 1,
							["id"] = 6603,
							["min"] = 1,
							["hitamount"] = 2,
							["hitmax"] = 1,
							["hit"] = 2,
							["school"] = 1,
							["max"] = 1,
							["totalhits"] = 2,
							["damage"] = 2,
						},
						["腐蚀术"] = {
							["hitmin"] = 4,
							["id"] = 146739,
							["min"] = 4,
							["hitamount"] = 16,
							["hitmax"] = 4,
							["hit"] = 4,
							["school"] = 32,
							["max"] = 4,
							["totalhits"] = 4,
							["damage"] = 16,
						},
						["暗影箭"] = {
							["hitmin"] = 19,
							["id"] = 232670,
							["min"] = 19,
							["hitamount"] = 39,
							["hitmax"] = 20,
							["hit"] = 2,
							["school"] = 32,
							["max"] = 20,
							["totalhits"] = 2,
							["damage"] = 39,
						},
					},
					["ffdamagedone"] = 0,
					["healed"] = {
					},
					["power"] = {
					},
					["id"] = "Player-729-04D8F3EB",
					["first"] = 1551454171,
					["damagetaken"] = 22,
					["damagetakenspells"] = {
						["攻击"] = {
							["crushing"] = 0,
							["id"] = 6603,
							["min"] = 5,
							["school"] = 1,
							["critical"] = 0,
							["glancing"] = 0,
							["absorbed"] = 0,
							["name"] = "攻击",
							["blocked"] = 0,
							["totalhits"] = 4,
							["resisted"] = 0,
							["max"] = 7,
							["damage"] = 22,
						},
					},
					["maxhp"] = 405,
					["overhealing"] = 0,
					["name"] = "書生",
					["healingspells"] = {
					},
					["shielding"] = 0,
					["healing"] = 0,
					["auras"] = {
						["腐蚀术"] = {
							["school"] = 32,
							["name"] = "腐蚀术",
							["active"] = 0,
							["id"] = 146739,
							["auratype"] = "DEBUFF",
							["uptime"] = 9,
						},
					},
					["ccbreaks"] = 0,
				}, -- [1]
			},
			["deaths"] = 0,
			["mobs"] = {
				["血牙潜伏者"] = {
					["players"] = {
						["書生"] = {
							["taken"] = 57,
							["done"] = 22,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 57,
					["done"] = 22,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
			},
			["mobtaken"] = 57,
			["ffdamagedone"] = 0,
			["healing"] = 0,
			["damagetaken"] = 22,
			["overhealing"] = 0,
			["shielding"] = 0,
			["starttime"] = 1551454171,
			["name"] = "血牙潜伏者 (2)",
			["mobname"] = "血牙潜伏者",
			["power"] = {
			},
			["mobhdone"] = 0,
			["last_action"] = 1551454171,
			["mobdone"] = 22,
		}, -- [3]
		{
			["healingabsorbed"] = 0,
			["auras"] = {
			},
			["ccbreaks"] = 0,
			["time"] = 12,
			["interrupts"] = 0,
			["endtime"] = 1551454145,
			["dispells"] = 0,
			["damage"] = 57,
			["players"] = {
				{
					["last"] = 1551454143,
					["healingabsorbed"] = 0,
					["class"] = "WARLOCK",
					["damaged"] = {
						["血牙潜伏者"] = 57,
					},
					["dispells"] = 0,
					["role"] = "NONE",
					["time"] = 9,
					["interrupts"] = 0,
					["ffdamagedonetargets"] = {
					},
					["ffdamagedonespells"] = {
					},
					["damage"] = 57,
					["damagespells"] = {
						["吉尔尼斯猎犬: 攻击"] = {
							["hitmin"] = 1,
							["id"] = 6603,
							["min"] = 1,
							["hitamount"] = 3,
							["hitmax"] = 1,
							["hit"] = 3,
							["school"] = 1,
							["max"] = 1,
							["totalhits"] = 3,
							["damage"] = 3,
						},
						["腐蚀术"] = {
							["hitmin"] = 4,
							["id"] = 146739,
							["min"] = 4,
							["hitamount"] = 16,
							["hitmax"] = 4,
							["hit"] = 4,
							["school"] = 32,
							["max"] = 4,
							["totalhits"] = 4,
							["damage"] = 16,
						},
						["暗影箭"] = {
							["hitmin"] = 19,
							["id"] = 232670,
							["min"] = 19,
							["hitamount"] = 38,
							["hitmax"] = 19,
							["hit"] = 2,
							["school"] = 32,
							["max"] = 19,
							["totalhits"] = 2,
							["damage"] = 38,
						},
					},
					["ffdamagedone"] = 0,
					["healed"] = {
					},
					["power"] = {
					},
					["id"] = "Player-729-04D8F3EB",
					["first"] = 1551454134,
					["damagetaken"] = 23,
					["damagetakenspells"] = {
						["攻击"] = {
							["crushing"] = 0,
							["id"] = 6603,
							["min"] = 5,
							["school"] = 1,
							["critical"] = 0,
							["glancing"] = 0,
							["absorbed"] = 0,
							["name"] = "攻击",
							["blocked"] = 0,
							["totalhits"] = 4,
							["resisted"] = 0,
							["max"] = 7,
							["damage"] = 23,
						},
					},
					["maxhp"] = 405,
					["overhealing"] = 0,
					["name"] = "書生",
					["healingspells"] = {
					},
					["shielding"] = 0,
					["healing"] = 0,
					["auras"] = {
						["腐蚀术"] = {
							["school"] = 32,
							["name"] = "腐蚀术",
							["active"] = 0,
							["id"] = 146739,
							["auratype"] = "DEBUFF",
							["uptime"] = 9,
						},
					},
					["ccbreaks"] = 0,
				}, -- [1]
			},
			["deaths"] = 0,
			["mobs"] = {
				["血牙潜伏者"] = {
					["players"] = {
						["書生"] = {
							["taken"] = 57,
							["done"] = 23,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 57,
					["done"] = 23,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
			},
			["mobtaken"] = 57,
			["ffdamagedone"] = 0,
			["healing"] = 0,
			["damagetaken"] = 23,
			["overhealing"] = 0,
			["shielding"] = 0,
			["starttime"] = 1551454133,
			["name"] = "血牙潜伏者",
			["mobname"] = "血牙潜伏者",
			["power"] = {
			},
			["mobhdone"] = 0,
			["last_action"] = 1551454133,
			["mobdone"] = 23,
		}, -- [4]
		{
			["healingabsorbed"] = 0,
			["auras"] = {
			},
			["ccbreaks"] = 0,
			["time"] = 37,
			["interrupts"] = 0,
			["endtime"] = 1551453972,
			["dispells"] = 0,
			["damage"] = 259,
			["players"] = {
				{
					["last"] = 1551453971,
					["healingabsorbed"] = 0,
					["class"] = "WARLOCK",
					["damaged"] = {
						["狼人幼崽"] = 186,
						["血牙放血者"] = 45,
						["狼人前锋"] = 28,
					},
					["dispells"] = 0,
					["role"] = "NONE",
					["time"] = 35,
					["interrupts"] = 0,
					["ffdamagedonetargets"] = {
					},
					["ffdamagedonespells"] = {
					},
					["damage"] = 259,
					["damagespells"] = {
						["腐蚀术"] = {
							["hitmin"] = 3,
							["criticalamount"] = 39,
							["id"] = 146739,
							["criticalmin"] = 7,
							["hitamount"] = 201,
							["critical"] = 5,
							["min"] = 3,
							["criticalmax"] = 8,
							["hitmax"] = 4,
							["hit"] = 52,
							["school"] = 32,
							["max"] = 8,
							["totalhits"] = 57,
							["damage"] = 240,
						},
						["暗影箭"] = {
							["hitmin"] = 19,
							["id"] = 232670,
							["min"] = 19,
							["hitamount"] = 19,
							["hitmax"] = 19,
							["hit"] = 1,
							["school"] = 32,
							["max"] = 19,
							["totalhits"] = 1,
							["damage"] = 19,
						},
					},
					["ffdamagedone"] = 0,
					["healed"] = {
					},
					["power"] = {
					},
					["id"] = "Player-729-04D8F3EB",
					["first"] = 1551453936,
					["damagetaken"] = 191,
					["damagetakenspells"] = {
						["攻击"] = {
							["crushing"] = 0,
							["id"] = 6603,
							["min"] = 1,
							["school"] = 1,
							["critical"] = 0,
							["glancing"] = 0,
							["absorbed"] = 0,
							["name"] = "攻击",
							["blocked"] = 0,
							["totalhits"] = 86,
							["resisted"] = 0,
							["max"] = 7,
							["damage"] = 191,
						},
					},
					["maxhp"] = 405,
					["overhealing"] = 0,
					["name"] = "書生",
					["healingspells"] = {
					},
					["shielding"] = 0,
					["healing"] = 0,
					["auras"] = {
						["腐蚀术"] = {
							["school"] = 32,
							["name"] = "腐蚀术",
							["active"] = 0,
							["id"] = 146739,
							["auratype"] = "DEBUFF",
							["uptime"] = 31,
						},
					},
					["ccbreaks"] = 0,
				}, -- [1]
			},
			["deaths"] = 0,
			["mobs"] = {
				["托比亚斯·密斯特曼托"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 3,
							["healing"] = 9,
							["overhealing"] = 85,
							["hits"] = 18,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 9,
					["hdonespell"] = {
					},
				},
				["血牙放血者"] = {
					["players"] = {
						["書生"] = {
							["taken"] = 45,
							["done"] = 38,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 45,
					["done"] = 38,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
				["达利乌斯·克罗雷领主"] = {
					["players"] = {
					},
					["hdone"] = 95,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 5,
							["healing"] = 18,
							["overhealing"] = 1170,
							["hits"] = 18,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 18,
					["hdonespell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 5,
							["healing"] = 95,
							["overhealing"] = 137987,
							["hits"] = 54,
						},
					},
				},
				["狼人幼崽"] = {
					["players"] = {
						["書生"] = {
							["taken"] = 186,
							["done"] = 129,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 186,
					["done"] = 129,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
				["吉尔尼斯皇家卫兵"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 5,
							["healing"] = 68,
							["overhealing"] = 136732,
							["hits"] = 18,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 68,
					["hdonespell"] = {
					},
				},
				["狼人前锋"] = {
					["players"] = {
						["書生"] = {
							["taken"] = 28,
							["done"] = 24,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 28,
					["done"] = 24,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
			},
			["mobtaken"] = 259,
			["ffdamagedone"] = 0,
			["healing"] = 0,
			["damagetaken"] = 191,
			["overhealing"] = 0,
			["shielding"] = 0,
			["starttime"] = 1551453935,
			["name"] = "狼人幼崽 (2)",
			["mobname"] = "狼人幼崽",
			["power"] = {
			},
			["mobhdone"] = 95,
			["last_action"] = 1551453935,
			["mobdone"] = 191,
		}, -- [5]
		{
			["healingabsorbed"] = 0,
			["auras"] = {
			},
			["ccbreaks"] = 0,
			["time"] = 10,
			["interrupts"] = 0,
			["endtime"] = 1551453918,
			["dispells"] = 0,
			["damage"] = 30,
			["players"] = {
				{
					["last"] = 1551453916,
					["healingabsorbed"] = 0,
					["class"] = "WARLOCK",
					["damaged"] = {
						["狼人前锋"] = 30,
					},
					["dispells"] = 0,
					["role"] = "NONE",
					["time"] = 5,
					["interrupts"] = 0,
					["ffdamagedonetargets"] = {
					},
					["ffdamagedonespells"] = {
					},
					["damage"] = 30,
					["damagespells"] = {
						["腐蚀术"] = {
							["hitmin"] = 3,
							["id"] = 146739,
							["min"] = 3,
							["hitamount"] = 11,
							["hitmax"] = 4,
							["hit"] = 3,
							["school"] = 32,
							["max"] = 4,
							["totalhits"] = 3,
							["damage"] = 11,
						},
						["暗影箭"] = {
							["hitmin"] = 19,
							["id"] = 232670,
							["min"] = 19,
							["hitamount"] = 19,
							["hitmax"] = 19,
							["hit"] = 1,
							["school"] = 32,
							["max"] = 19,
							["totalhits"] = 1,
							["damage"] = 19,
						},
					},
					["ffdamagedone"] = 0,
					["healed"] = {
					},
					["power"] = {
					},
					["id"] = "Player-729-04D8F3EB",
					["first"] = 1551453911,
					["damagetaken"] = 5,
					["damagetakenspells"] = {
						["攻击"] = {
							["crushing"] = 0,
							["id"] = 6603,
							["min"] = 5,
							["school"] = 1,
							["critical"] = 0,
							["glancing"] = 0,
							["absorbed"] = 0,
							["name"] = "攻击",
							["blocked"] = 0,
							["totalhits"] = 1,
							["resisted"] = 0,
							["max"] = 5,
							["damage"] = 5,
						},
					},
					["maxhp"] = 405,
					["overhealing"] = 0,
					["name"] = "書生",
					["healingspells"] = {
					},
					["shielding"] = 0,
					["healing"] = 0,
					["auras"] = {
						["腐蚀术"] = {
							["school"] = 32,
							["name"] = "腐蚀术",
							["active"] = 0,
							["id"] = 146739,
							["auratype"] = "DEBUFF",
							["uptime"] = 4,
						},
					},
					["ccbreaks"] = 0,
				}, -- [1]
			},
			["deaths"] = 0,
			["mobs"] = {
				["托比亚斯·密斯特曼托"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 21,
							["hits"] = 4,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
				["吉尔尼斯皇家卫兵"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 3,
							["crits"] = 0,
							["max"] = 5,
							["healing"] = 21,
							["overhealing"] = 37979,
							["hits"] = 5,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 21,
					["hdonespell"] = {
					},
				},
				["达利乌斯·克罗雷领主"] = {
					["players"] = {
					},
					["hdone"] = 27,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 6,
							["healing"] = 6,
							["overhealing"] = 324,
							["hits"] = 5,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 6,
					["hdonespell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 6,
							["healing"] = 27,
							["overhealing"] = 38324,
							["hits"] = 14,
						},
					},
				},
				["狼人前锋"] = {
					["players"] = {
						["書生"] = {
							["taken"] = 30,
							["done"] = 5,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 30,
					["done"] = 5,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
			},
			["mobtaken"] = 30,
			["ffdamagedone"] = 0,
			["healing"] = 0,
			["damagetaken"] = 5,
			["overhealing"] = 0,
			["shielding"] = 0,
			["starttime"] = 1551453908,
			["name"] = "狼人前锋",
			["mobname"] = "狼人前锋",
			["power"] = {
			},
			["mobhdone"] = 27,
			["last_action"] = 1551453908,
			["mobdone"] = 5,
		}, -- [6]
		{
			["healingabsorbed"] = 0,
			["auras"] = {
			},
			["ccbreaks"] = 0,
			["time"] = 52,
			["interrupts"] = 0,
			["endtime"] = 1551453899,
			["dispells"] = 0,
			["damage"] = 187,
			["players"] = {
				{
					["last"] = 1551453879,
					["healingabsorbed"] = 0,
					["class"] = "WARLOCK",
					["damaged"] = {
						["血牙放血者"] = 23,
						["狼人幼崽"] = 164,
					},
					["dispells"] = 0,
					["role"] = "NONE",
					["time"] = 27,
					["interrupts"] = 0,
					["ffdamagedonetargets"] = {
					},
					["ffdamagedonespells"] = {
					},
					["damage"] = 187,
					["damagespells"] = {
						["腐蚀术"] = {
							["hitmin"] = 3,
							["criticalamount"] = 16,
							["id"] = 146739,
							["criticalmin"] = 8,
							["hitamount"] = 171,
							["critical"] = 2,
							["min"] = 3,
							["criticalmax"] = 8,
							["hitmax"] = 4,
							["hit"] = 45,
							["school"] = 32,
							["max"] = 8,
							["totalhits"] = 47,
							["damage"] = 187,
						},
					},
					["ffdamagedone"] = 0,
					["healed"] = {
					},
					["power"] = {
					},
					["id"] = "Player-729-04D8F3EB",
					["first"] = 1551453852,
					["damagetaken"] = 74,
					["damagetakenspells"] = {
						["攻击"] = {
							["crushing"] = 0,
							["id"] = 6603,
							["min"] = 1,
							["school"] = 1,
							["critical"] = 0,
							["glancing"] = 0,
							["absorbed"] = 0,
							["name"] = "攻击",
							["blocked"] = 0,
							["totalhits"] = 42,
							["resisted"] = 0,
							["max"] = 6,
							["damage"] = 74,
						},
					},
					["maxhp"] = 405,
					["overhealing"] = 0,
					["name"] = "書生",
					["healingspells"] = {
					},
					["shielding"] = 0,
					["healing"] = 0,
					["auras"] = {
						["腐蚀术"] = {
							["school"] = 32,
							["name"] = "腐蚀术",
							["active"] = 0,
							["id"] = 146739,
							["auratype"] = "DEBUFF",
							["uptime"] = 23,
						},
					},
					["ccbreaks"] = 0,
				}, -- [1]
			},
			["deaths"] = 0,
			["mobs"] = {
				["扫描电镜-国王之谷"] = {
					["players"] = {
					},
					["hdone"] = 12,
					["htakenspell"] = {
						["迅捷的正义之手"] = {
							["min"] = 4,
							["crits"] = 0,
							["max"] = 8,
							["healing"] = 12,
							["overhealing"] = 4,
							["hits"] = 2,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 12,
					["hdonespell"] = {
						["迅捷的正义之手"] = {
							["min"] = 4,
							["crits"] = 0,
							["max"] = 8,
							["healing"] = 12,
							["overhealing"] = 4,
							["hits"] = 2,
						},
					},
				},
				["达利乌斯·克罗雷领主"] = {
					["players"] = {
					},
					["hdone"] = 110,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 1716,
							["hits"] = 26,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 0,
					["hdonespell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 5,
							["healing"] = 110,
							["overhealing"] = 191725,
							["hits"] = 74,
						},
					},
				},
				["托比亚斯·密斯特曼托"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 3,
							["healing"] = 8,
							["overhealing"] = 111,
							["hits"] = 23,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 8,
					["hdonespell"] = {
					},
				},
				["吉尔尼斯皇家卫兵"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 5,
							["healing"] = 102,
							["overhealing"] = 189898,
							["hits"] = 25,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 102,
					["hdonespell"] = {
					},
				},
				["狼人幼崽"] = {
					["players"] = {
						["書生"] = {
							["taken"] = 164,
							["done"] = 59,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 164,
					["done"] = 59,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
				["血牙放血者"] = {
					["players"] = {
						["書生"] = {
							["taken"] = 23,
							["done"] = 15,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 23,
					["done"] = 15,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
			},
			["mobtaken"] = 187,
			["ffdamagedone"] = 0,
			["healing"] = 0,
			["damagetaken"] = 74,
			["overhealing"] = 0,
			["shielding"] = 0,
			["starttime"] = 1551453847,
			["name"] = "狼人幼崽",
			["mobname"] = "狼人幼崽",
			["power"] = {
			},
			["mobhdone"] = 122,
			["last_action"] = 1551453847,
			["mobdone"] = 74,
		}, -- [7]
		{
			["healingabsorbed"] = 0,
			["auras"] = {
			},
			["ccbreaks"] = 0,
			["time"] = 21,
			["interrupts"] = 0,
			["endtime"] = 1551453833,
			["dispells"] = 0,
			["damage"] = 55,
			["players"] = {
				{
					["last"] = 1551453833,
					["healingabsorbed"] = 0,
					["class"] = "WARLOCK",
					["damaged"] = {
						["血牙狼人"] = 55,
					},
					["dispells"] = 0,
					["role"] = "NONE",
					["time"] = 21,
					["interrupts"] = 0,
					["ffdamagedonetargets"] = {
					},
					["ffdamagedonespells"] = {
					},
					["damage"] = 55,
					["damagespells"] = {
						["腐蚀术"] = {
							["hitmin"] = 4,
							["criticalamount"] = 7,
							["id"] = 146739,
							["criticalmin"] = 7,
							["hitamount"] = 48,
							["critical"] = 1,
							["min"] = 4,
							["criticalmax"] = 7,
							["hitmax"] = 4,
							["hit"] = 12,
							["school"] = 32,
							["max"] = 7,
							["totalhits"] = 13,
							["damage"] = 55,
						},
					},
					["ffdamagedone"] = 0,
					["healed"] = {
					},
					["power"] = {
					},
					["id"] = "Player-729-04D8F3EB",
					["first"] = 1551453812,
					["damagetaken"] = 67,
					["damagetakenspells"] = {
						["攻击"] = {
							["crushing"] = 0,
							["id"] = 6603,
							["min"] = 4,
							["school"] = 1,
							["critical"] = 0,
							["glancing"] = 0,
							["absorbed"] = 0,
							["name"] = "攻击",
							["blocked"] = 0,
							["totalhits"] = 13,
							["resisted"] = 0,
							["max"] = 7,
							["damage"] = 67,
						},
					},
					["maxhp"] = 405,
					["overhealing"] = 0,
					["name"] = "書生",
					["healingspells"] = {
					},
					["shielding"] = 0,
					["healing"] = 0,
					["auras"] = {
						["腐蚀术"] = {
							["school"] = 32,
							["name"] = "腐蚀术",
							["active"] = 0,
							["id"] = 146739,
							["auratype"] = "DEBUFF",
							["uptime"] = 14,
						},
					},
					["ccbreaks"] = 0,
				}, -- [1]
			},
			["deaths"] = 0,
			["mobs"] = {
				["托比亚斯·密斯特曼托"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 50,
							["hits"] = 10,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
				["吉尔尼斯皇家卫兵"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 3,
							["crits"] = 0,
							["max"] = 5,
							["healing"] = 43,
							["overhealing"] = 75957,
							["hits"] = 10,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 43,
					["hdonespell"] = {
					},
				},
				["达利乌斯·克罗雷领主"] = {
					["players"] = {
					},
					["hdone"] = 43,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 660,
							["hits"] = 10,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 0,
					["hdonespell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 5,
							["healing"] = 43,
							["overhealing"] = 76667,
							["hits"] = 30,
						},
					},
				},
				["血牙狼人"] = {
					["players"] = {
						["書生"] = {
							["taken"] = 55,
							["done"] = 67,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 55,
					["done"] = 67,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
			},
			["mobtaken"] = 55,
			["ffdamagedone"] = 0,
			["healing"] = 0,
			["damagetaken"] = 67,
			["overhealing"] = 0,
			["shielding"] = 0,
			["starttime"] = 1551453812,
			["name"] = "血牙狼人 (2)",
			["mobname"] = "血牙狼人",
			["power"] = {
			},
			["mobhdone"] = 43,
			["last_action"] = 1551453812,
			["mobdone"] = 67,
		}, -- [8]
		{
			["healingabsorbed"] = 0,
			["auras"] = {
			},
			["ccbreaks"] = 0,
			["time"] = 32,
			["interrupts"] = 0,
			["endtime"] = 1551453776,
			["dispells"] = 0,
			["damage"] = 187,
			["players"] = {
				{
					["last"] = 1551453773,
					["healingabsorbed"] = 0,
					["class"] = "WARLOCK",
					["damaged"] = {
						["血牙狼人"] = 187,
					},
					["dispells"] = 0,
					["role"] = "NONE",
					["time"] = 28,
					["interrupts"] = 0,
					["ffdamagedonetargets"] = {
					},
					["ffdamagedonespells"] = {
					},
					["damage"] = 187,
					["damagespells"] = {
						["腐蚀术"] = {
							["hitmin"] = 1,
							["criticalamount"] = 24,
							["id"] = 146739,
							["criticalmin"] = 8,
							["hitamount"] = 144,
							["critical"] = 3,
							["min"] = 1,
							["criticalmax"] = 8,
							["hitmax"] = 4,
							["hit"] = 39,
							["school"] = 32,
							["max"] = 8,
							["totalhits"] = 42,
							["damage"] = 168,
						},
						["暗影箭"] = {
							["hitmin"] = 19,
							["id"] = 232670,
							["min"] = 19,
							["hitamount"] = 19,
							["hitmax"] = 19,
							["hit"] = 1,
							["school"] = 32,
							["max"] = 19,
							["totalhits"] = 1,
							["damage"] = 19,
						},
					},
					["ffdamagedone"] = 0,
					["healed"] = {
					},
					["power"] = {
					},
					["id"] = "Player-729-04D8F3EB",
					["first"] = 1551453745,
					["damagetaken"] = 176,
					["damagetakenspells"] = {
						["攻击"] = {
							["crushing"] = 0,
							["id"] = 6603,
							["min"] = 4,
							["school"] = 1,
							["critical"] = 0,
							["glancing"] = 0,
							["absorbed"] = 0,
							["name"] = "攻击",
							["blocked"] = 0,
							["totalhits"] = 35,
							["resisted"] = 0,
							["max"] = 6,
							["damage"] = 176,
						},
					},
					["maxhp"] = 405,
					["overhealing"] = 0,
					["name"] = "書生",
					["healingspells"] = {
					},
					["shielding"] = 0,
					["healing"] = 0,
					["auras"] = {
						["腐蚀术"] = {
							["school"] = 32,
							["name"] = "腐蚀术",
							["active"] = 0,
							["id"] = 146739,
							["auratype"] = "DEBUFF",
							["uptime"] = 24,
						},
					},
					["ccbreaks"] = 0,
				}, -- [1]
			},
			["deaths"] = 0,
			["mobs"] = {
				["扫描电镜-国王之谷"] = {
					["players"] = {
					},
					["hdone"] = 41,
					["htakenspell"] = {
						["迅捷的正义之手"] = {
							["min"] = 8,
							["crits"] = 0,
							["max"] = 9,
							["healing"] = 41,
							["overhealing"] = 0,
							["hits"] = 5,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 41,
					["hdonespell"] = {
						["迅捷的正义之手"] = {
							["min"] = 8,
							["crits"] = 0,
							["max"] = 9,
							["healing"] = 41,
							["overhealing"] = 0,
							["hits"] = 5,
						},
					},
				},
				["达利乌斯·克罗雷领主"] = {
					["players"] = {
					},
					["hdone"] = 54,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 924,
							["hits"] = 14,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 0,
					["hdonespell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 5,
							["healing"] = 54,
							["overhealing"] = 107342,
							["hits"] = 42,
						},
					},
				},
				["吉尔尼斯皇家卫兵"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 5,
							["healing"] = 54,
							["overhealing"] = 106346,
							["hits"] = 14,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 54,
					["hdonespell"] = {
					},
				},
				["托比亚斯·密斯特曼托"] = {
					["players"] = {
					},
					["hdone"] = 0,
					["htakenspell"] = {
						["叛军勇气"] = {
							["min"] = 0,
							["crits"] = 0,
							["max"] = 0,
							["healing"] = 0,
							["overhealing"] = 72,
							["hits"] = 14,
						},
					},
					["taken"] = 0,
					["done"] = 0,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
				["血牙狼人"] = {
					["players"] = {
						["書生"] = {
							["taken"] = 187,
							["done"] = 176,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 187,
					["done"] = 176,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
			},
			["mobtaken"] = 187,
			["ffdamagedone"] = 0,
			["healing"] = 0,
			["damagetaken"] = 176,
			["overhealing"] = 0,
			["shielding"] = 0,
			["starttime"] = 1551453744,
			["name"] = "血牙狼人",
			["mobname"] = "血牙狼人",
			["power"] = {
			},
			["mobhdone"] = 95,
			["last_action"] = 1551453744,
			["mobdone"] = 176,
		}, -- [9]
		{
			["healingabsorbed"] = 0,
			["auras"] = {
			},
			["ccbreaks"] = 0,
			["time"] = 19,
			["interrupts"] = 0,
			["endtime"] = 1551453639,
			["dispells"] = 0,
			["damage"] = 31,
			["players"] = {
				{
					["last"] = 1551453637,
					["healingabsorbed"] = 0,
					["class"] = "WARLOCK",
					["damaged"] = {
						["暴怒的狼人"] = 31,
					},
					["dispells"] = 0,
					["role"] = "NONE",
					["time"] = 17,
					["interrupts"] = 0,
					["ffdamagedonetargets"] = {
					},
					["ffdamagedonespells"] = {
					},
					["damage"] = 31,
					["damagespells"] = {
						["腐蚀术"] = {
							["hitmin"] = 3,
							["criticalamount"] = 6,
							["id"] = 146739,
							["criticalmin"] = 6,
							["hitamount"] = 25,
							["critical"] = 1,
							["min"] = 3,
							["criticalmax"] = 6,
							["hitmax"] = 4,
							["hit"] = 8,
							["school"] = 32,
							["max"] = 6,
							["totalhits"] = 9,
							["damage"] = 31,
						},
					},
					["ffdamagedone"] = 0,
					["healed"] = {
					},
					["power"] = {
					},
					["id"] = "Player-729-04D8F3EB",
					["first"] = 1551453620,
					["damagetaken"] = 29,
					["damagetakenspells"] = {
						["攻击"] = {
							["crushing"] = 0,
							["id"] = 6603,
							["min"] = 4,
							["school"] = 1,
							["critical"] = 0,
							["glancing"] = 0,
							["absorbed"] = 0,
							["name"] = "攻击",
							["blocked"] = 0,
							["totalhits"] = 7,
							["resisted"] = 0,
							["max"] = 5,
							["damage"] = 29,
						},
					},
					["maxhp"] = 360,
					["overhealing"] = 0,
					["name"] = "書生",
					["healingspells"] = {
					},
					["shielding"] = 0,
					["healing"] = 0,
					["auras"] = {
						["腐蚀术"] = {
							["school"] = 32,
							["name"] = "腐蚀术",
							["active"] = 0,
							["id"] = 146739,
							["auratype"] = "DEBUFF",
							["uptime"] = 17,
						},
					},
					["ccbreaks"] = 0,
				}, -- [1]
			},
			["deaths"] = 0,
			["mobs"] = {
				["暴怒的狼人"] = {
					["players"] = {
						["書生"] = {
							["taken"] = 31,
							["done"] = 29,
							["role"] = "NONE",
							["class"] = "WARLOCK",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 31,
					["done"] = 29,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
			},
			["mobtaken"] = 31,
			["ffdamagedone"] = 0,
			["healing"] = 0,
			["damagetaken"] = 29,
			["overhealing"] = 0,
			["shielding"] = 0,
			["starttime"] = 1551453620,
			["name"] = "暴怒的狼人 (2)",
			["mobname"] = "暴怒的狼人",
			["power"] = {
			},
			["mobhdone"] = 0,
			["last_action"] = 1551453620,
			["mobdone"] = 29,
		}, -- [10]
	},
	["total"] = {
		["healingabsorbed"] = 0,
		["auras"] = {
		},
		["ccbreaks"] = 0,
		["time"] = 223,
		["interrupts"] = 0,
		["damage"] = 1034,
		["players"] = {
			{
				["healingabsorbed"] = 0,
				["class"] = "WARLOCK",
				["damaged"] = {
				},
				["dispells"] = 0,
				["role"] = "NONE",
				["time"] = 227,
				["interrupts"] = 0,
				["ccbreaks"] = 0,
				["auras"] = {
					["腐蚀术"] = {
						["uptime"] = 145,
						["active"] = 0,
						["id"] = 146739,
						["name"] = "腐蚀术",
						["school"] = 32,
						["auratype"] = "DEBUFF",
					},
				},
				["damage"] = 1034,
				["damagespells"] = {
					["吉尔尼斯猎犬: 攻击"] = {
						["hitmin"] = 1,
						["id"] = 6603,
						["min"] = 1,
						["hitamount"] = 5,
						["hitmax"] = 1,
						["hit"] = 5,
						["school"] = 1,
						["max"] = 1,
						["totalhits"] = 5,
						["damage"] = 5,
					},
					["腐蚀术"] = {
						["hitmin"] = 1,
						["criticalamount"] = 92,
						["id"] = 146739,
						["criticalmin"] = 6,
						["damage"] = 771,
						["critical"] = 12,
						["min"] = 1,
						["criticalmax"] = 8,
						["hitmax"] = 4,
						["hit"] = 180,
						["school"] = 32,
						["totalhits"] = 192,
						["max"] = 8,
						["hitamount"] = 679,
					},
					["暗影箭"] = {
						["hitmin"] = 15,
						["id"] = 232670,
						["min"] = 15,
						["damage"] = 258,
						["hitmax"] = 20,
						["hit"] = 14,
						["school"] = 32,
						["totalhits"] = 14,
						["max"] = 20,
						["hitamount"] = 258,
					},
				},
				["healing"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Player-729-04D8F3EB",
				["maxhp"] = 360,
				["shielding"] = 0,
				["damagetakenspells"] = {
					["攻击"] = {
						["crushing"] = 0,
						["id"] = 6603,
						["damage"] = 748,
						["max"] = 7,
						["name"] = "攻击",
						["min"] = 1,
						["totalhits"] = 224,
						["critical"] = 0,
						["blocked"] = 0,
						["school"] = 1,
						["resisted"] = 0,
						["glancing"] = 0,
						["absorbed"] = 0,
					},
				},
				["healingspells"] = {
				},
				["name"] = "書生",
				["ffdamagedonetargets"] = {
				},
				["overhealing"] = 0,
				["deathlog"] = {
					{
						["ts"] = 1551454239.942,
						["amount"] = -7,
						["srcname"] = "血牙潜伏者",
						["spellid"] = 88163,
						["hp"] = 398,
					}, -- [1]
					{
						["ts"] = 1551454242.096,
						["amount"] = -6,
						["srcname"] = "血牙潜伏者",
						["spellid"] = 88163,
						["hp"] = 391,
					}, -- [2]
					{
						["ts"] = 1551454244.143,
						["amount"] = -4,
						["srcname"] = "血牙潜伏者",
						["spellid"] = 88163,
						["hp"] = 385,
					}, -- [3]
					{
						["ts"] = 1551454135.26,
						["amount"] = -7,
						["srcname"] = "血牙潜伏者",
						["spellid"] = 88163,
						["hp"] = 398,
					}, -- [4]
					{
						["ts"] = 1551454137.394,
						["amount"] = -5,
						["srcname"] = "血牙潜伏者",
						["spellid"] = 88163,
						["hp"] = 391,
					}, -- [5]
					{
						["ts"] = 1551454139.478,
						["amount"] = -6,
						["hp"] = 386,
						["srcname"] = "血牙潜伏者",
						["spellid"] = 88163,
					}, -- [6]
					{
						["ts"] = 1551454141.527,
						["amount"] = -5,
						["hp"] = 380,
						["srcname"] = "血牙潜伏者",
						["spellid"] = 88163,
					}, -- [7]
					{
						["ts"] = 1551454173.145,
						["amount"] = -7,
						["hp"] = 405,
						["srcname"] = "血牙潜伏者",
						["spellid"] = 88163,
					}, -- [8]
					{
						["ts"] = 1551454175.244,
						["amount"] = -5,
						["hp"] = 398,
						["srcname"] = "血牙潜伏者",
						["spellid"] = 88163,
					}, -- [9]
					{
						["ts"] = 1551454177.326,
						["amount"] = -5,
						["hp"] = 393,
						["srcname"] = "血牙潜伏者",
						["spellid"] = 88163,
					}, -- [10]
					{
						["ts"] = 1551454179.594,
						["amount"] = -5,
						["hp"] = 388,
						["srcname"] = "血牙潜伏者",
						["spellid"] = 88163,
					}, -- [11]
					{
						["ts"] = 1551454225.359,
						["amount"] = -5,
						["hp"] = 405,
						["srcname"] = "血牙潜伏者",
						["spellid"] = 88163,
					}, -- [12]
					{
						["ts"] = 1551454227.209,
						["amount"] = -7,
						["hp"] = 400,
						["srcname"] = "血牙潜伏者",
						["spellid"] = 88163,
					}, -- [13]
					{
						["ts"] = 1551454229.327,
						["amount"] = -5,
						["hp"] = 393,
						["srcname"] = "血牙潜伏者",
						["spellid"] = 88163,
					}, -- [14]
					{
						["ts"] = 1551454237.977,
						["amount"] = -7,
						["hp"] = 405,
						["srcname"] = "血牙潜伏者",
						["spellid"] = 88163,
					}, -- [15]
					["pos"] = 4,
				},
				["damagetaken"] = 748,
				["ffdamagedone"] = 0,
				["ffdamagedonespells"] = {
				},
			}, -- [1]
		},
		["deaths"] = 0,
		["mobs"] = {
			["暴怒的狼人"] = {
				["players"] = {
					["書生"] = {
						["taken"] = 98,
						["done"] = 52,
						["class"] = "WARLOCK",
						["role"] = "NONE",
					},
				},
				["hdone"] = 0,
				["hdonespell"] = {
				},
				["taken"] = 98,
				["htakenspell"] = {
				},
				["htaken"] = 0,
				["done"] = 52,
			},
			["血牙潜伏者"] = {
				["players"] = {
					["書生"] = {
						["taken"] = 218,
						["done"] = 86,
						["role"] = "NONE",
						["class"] = "WARLOCK",
					},
				},
				["hdone"] = 0,
				["htakenspell"] = {
				},
				["taken"] = 218,
				["done"] = 86,
				["htaken"] = 0,
				["hdonespell"] = {
				},
			},
			["达利乌斯·克罗雷领主"] = {
				["players"] = {
				},
				["hdone"] = 379,
				["htakenspell"] = {
					["叛军勇气"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 6,
						["healing"] = 24,
						["overhealing"] = 5652,
						["hits"] = 86,
					},
				},
				["taken"] = 0,
				["done"] = 0,
				["htaken"] = 24,
				["hdonespell"] = {
					["叛军勇气"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 6,
						["healing"] = 379,
						["overhealing"] = 651718,
						["hits"] = 253,
					},
				},
			},
			["吉尔尼斯皇家卫兵"] = {
				["players"] = {
				},
				["hdone"] = 0,
				["htakenspell"] = {
					["叛军勇气"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 5,
						["healing"] = 338,
						["overhealing"] = 645662,
						["hits"] = 85,
					},
				},
				["taken"] = 0,
				["done"] = 0,
				["htaken"] = 338,
				["hdonespell"] = {
				},
			},
			["血牙狼人"] = {
				["players"] = {
					["書生"] = {
						["taken"] = 242,
						["done"] = 340,
						["role"] = "NONE",
						["class"] = "WARLOCK",
					},
				},
				["hdone"] = 0,
				["htakenspell"] = {
				},
				["taken"] = 242,
				["done"] = 340,
				["htaken"] = 0,
				["hdonespell"] = {
				},
			},
			["扫描电镜-国王之谷"] = {
				["players"] = {
				},
				["hdone"] = 53,
				["htakenspell"] = {
					["迅捷的正义之手"] = {
						["min"] = 4,
						["crits"] = 0,
						["max"] = 9,
						["healing"] = 53,
						["overhealing"] = 4,
						["hits"] = 7,
					},
				},
				["taken"] = 0,
				["done"] = 0,
				["htaken"] = 53,
				["hdonespell"] = {
					["迅捷的正义之手"] = {
						["min"] = 4,
						["crits"] = 0,
						["max"] = 9,
						["healing"] = 53,
						["overhealing"] = 4,
						["hits"] = 7,
					},
				},
			},
			["托比亚斯·密斯特曼托"] = {
				["players"] = {
				},
				["hdone"] = 0,
				["htakenspell"] = {
					["叛军勇气"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 3,
						["healing"] = 17,
						["overhealing"] = 404,
						["hits"] = 82,
					},
				},
				["taken"] = 0,
				["done"] = 0,
				["htaken"] = 17,
				["hdonespell"] = {
				},
			},
			["狼人幼崽"] = {
				["players"] = {
					["書生"] = {
						["taken"] = 350,
						["done"] = 188,
						["role"] = "NONE",
						["class"] = "WARLOCK",
					},
				},
				["hdone"] = 0,
				["htakenspell"] = {
				},
				["taken"] = 350,
				["done"] = 188,
				["htaken"] = 0,
				["hdonespell"] = {
				},
			},
			["狼人前锋"] = {
				["players"] = {
					["書生"] = {
						["taken"] = 58,
						["done"] = 29,
						["role"] = "NONE",
						["class"] = "WARLOCK",
					},
				},
				["hdone"] = 0,
				["htakenspell"] = {
				},
				["taken"] = 58,
				["done"] = 29,
				["htaken"] = 0,
				["hdonespell"] = {
				},
			},
			["血牙放血者"] = {
				["players"] = {
					["書生"] = {
						["taken"] = 68,
						["done"] = 53,
						["role"] = "NONE",
						["class"] = "WARLOCK",
					},
				},
				["hdone"] = 0,
				["htakenspell"] = {
				},
				["taken"] = 68,
				["done"] = 53,
				["htaken"] = 0,
				["hdonespell"] = {
				},
			},
		},
		["mobtaken"] = 1034,
		["ffdamagedone"] = 0,
		["healing"] = 0,
		["damagetaken"] = 748,
		["overhealing"] = 0,
		["power"] = {
		},
		["dispells"] = 0,
		["name"] = "总计",
		["starttime"] = 1550934235,
		["shielding"] = 0,
		["mobhdone"] = 432,
		["last_action"] = 1550934235,
		["mobdone"] = 748,
	},
}
