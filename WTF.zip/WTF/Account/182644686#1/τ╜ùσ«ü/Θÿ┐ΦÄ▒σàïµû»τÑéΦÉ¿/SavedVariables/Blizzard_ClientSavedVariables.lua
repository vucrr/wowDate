
TARGET_FRAME_UNLOCKED = false
PLAYER_FRAME_UNLOCKED = false
TARGET_FRAME_BUFFS_ON_TOP = nil
FOCUS_FRAME_BUFFS_ON_TOP = nil
PLAYER_FRAME_CASTBARS_SHOWN = nil
CHANNELPULLOUT_FADEFRAMES = {
	"ChannelPulloutBackground", -- [1]
	"ChannelPulloutCloseButton", -- [2]
	"ChannelPulloutRosterScroll", -- [3]
}
DISPLAYED_COMMUNITIES_INVITATIONS = {
}
