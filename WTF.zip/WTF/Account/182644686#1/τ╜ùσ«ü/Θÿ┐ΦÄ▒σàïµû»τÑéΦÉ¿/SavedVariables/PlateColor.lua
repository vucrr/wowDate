
PlateColorDB = {
	["zb"] = true,
	["arrow"] = true,
	["scale"] = true,
	["mb"] = true,
	["ch"] = true,
	["name"] = true,
	["zsx"] = 0.35,
	["zs"] = false,
	["jian"] = true,
}
