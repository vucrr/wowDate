
PlateColorDB = {
	["zb"] = true,
	["arrow"] = true,
	["scale"] = true,
	["mb"] = true,
	["ch"] = true,
	["name"] = true,
	["zsx"] = 0.35,
	["jian"] = true,
	["zs"] = false,
}
