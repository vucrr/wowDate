
SkadaPerCharDB = {
	["total"] = {
		["healingabsorbed"] = 0,
		["auras"] = {
		},
		["ccbreaks"] = 0,
		["time"] = 7,
		["interrupts"] = 0,
		["damage"] = 1070,
		["players"] = {
			{
				["healingabsorbed"] = 0,
				["class"] = "WARRIOR",
				["damaged"] = {
				},
				["dispells"] = 0,
				["role"] = "NONE",
				["time"] = 5,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedonespells"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 1070,
				["damagespells"] = {
					["攻击"] = {
						["criticalamount"] = 967,
						["id"] = 6603,
						["min"] = 967,
						["criticalmax"] = 967,
						["critical"] = 1,
						["criticalmin"] = 967,
						["school"] = 1,
						["max"] = 967,
						["totalhits"] = 1,
						["damage"] = 967,
					},
					["冲锋"] = {
						["hitmin"] = 103,
						["id"] = 126664,
						["min"] = 103,
						["hitamount"] = 103,
						["hitmax"] = 103,
						["hit"] = 1,
						["school"] = 1,
						["max"] = 103,
						["totalhits"] = 1,
						["damage"] = 103,
					},
				},
				["maxhp"] = 19920,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Player-886-0537EB0F",
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "Testes",
				["healingspells"] = {
				},
				["shielding"] = 0,
				["healing"] = 0,
				["auras"] = {
				},
				["ccbreaks"] = 0,
			}, -- [1]
		},
		["deaths"] = 0,
		["mobs"] = {
			["目标假人"] = {
				["players"] = {
					["Testes"] = {
						["taken"] = 1070,
						["done"] = 0,
						["role"] = "NONE",
						["class"] = "WARRIOR",
					},
				},
				["hdone"] = 0,
				["htakenspell"] = {
				},
				["taken"] = 1070,
				["done"] = 0,
				["htaken"] = 0,
				["hdonespell"] = {
				},
			},
		},
		["mobtaken"] = 1070,
		["ffdamagedone"] = 0,
		["healing"] = 0,
		["damagetaken"] = 0,
		["overhealing"] = 0,
		["shielding"] = 0,
		["starttime"] = 1545460725,
		["name"] = "总计",
		["dispells"] = 0,
		["power"] = {
		},
		["mobhdone"] = 0,
		["last_action"] = 1545460725,
		["mobdone"] = 0,
	},
	["sets"] = {
		{
			["healingabsorbed"] = 0,
			["auras"] = {
			},
			["ccbreaks"] = 0,
			["time"] = 7,
			["interrupts"] = 0,
			["endtime"] = 1545460732,
			["dispells"] = 0,
			["damage"] = 1070,
			["players"] = {
				{
					["last"] = 1545460731,
					["healingabsorbed"] = 0,
					["class"] = "WARRIOR",
					["damaged"] = {
						["目标假人"] = 1070,
					},
					["dispells"] = 0,
					["role"] = "NONE",
					["time"] = 5,
					["interrupts"] = 0,
					["ffdamagedonetargets"] = {
					},
					["ffdamagedonespells"] = {
					},
					["damage"] = 1070,
					["damagespells"] = {
						["攻击"] = {
							["criticalamount"] = 967,
							["id"] = 6603,
							["min"] = 967,
							["criticalmax"] = 967,
							["critical"] = 1,
							["criticalmin"] = 967,
							["school"] = 1,
							["max"] = 967,
							["totalhits"] = 1,
							["damage"] = 967,
						},
						["冲锋"] = {
							["hitmin"] = 103,
							["id"] = 126664,
							["min"] = 103,
							["hitamount"] = 103,
							["hitmax"] = 103,
							["hit"] = 1,
							["school"] = 1,
							["max"] = 103,
							["totalhits"] = 1,
							["damage"] = 103,
						},
					},
					["ffdamagedone"] = 0,
					["healed"] = {
					},
					["power"] = {
					},
					["id"] = "Player-886-0537EB0F",
					["first"] = 1545460726,
					["damagetaken"] = 0,
					["damagetakenspells"] = {
					},
					["maxhp"] = 19920,
					["overhealing"] = 0,
					["name"] = "Testes",
					["healingspells"] = {
					},
					["shielding"] = 0,
					["healing"] = 0,
					["auras"] = {
					},
					["ccbreaks"] = 0,
				}, -- [1]
			},
			["deaths"] = 0,
			["mobs"] = {
				["目标假人"] = {
					["players"] = {
						["Testes"] = {
							["taken"] = 1070,
							["done"] = 0,
							["role"] = "NONE",
							["class"] = "WARRIOR",
						},
					},
					["hdone"] = 0,
					["htakenspell"] = {
					},
					["taken"] = 1070,
					["done"] = 0,
					["htaken"] = 0,
					["hdonespell"] = {
					},
				},
			},
			["mobtaken"] = 1070,
			["ffdamagedone"] = 0,
			["healing"] = 0,
			["damagetaken"] = 0,
			["overhealing"] = 0,
			["shielding"] = 0,
			["starttime"] = 1545460725,
			["name"] = "目标假人",
			["mobname"] = "目标假人",
			["power"] = {
			},
			["mobhdone"] = 0,
			["last_action"] = 1545460725,
			["mobdone"] = 0,
		}, -- [1]
	},
}
