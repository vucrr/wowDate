
SkadaPerCharDB = {
	["sets"] = {
	},
	["total"] = {
		["healingabsorbed"] = 0,
		["auras"] = {
		},
		["ccbreaks"] = 0,
		["time"] = 0,
		["interrupts"] = 0,
		["damage"] = 0,
		["players"] = {
			{
				["healingabsorbed"] = 0,
				["class"] = "MONK",
				["damaged"] = {
				},
				["dispells"] = 0,
				["role"] = "NONE",
				["time"] = 275,
				["interrupts"] = 0,
				["ccbreaks"] = 0,
				["auras"] = {
					["颂歌"] = {
						["uptime"] = 0,
						["name"] = "颂歌",
						["active"] = 0,
						["school"] = 1,
						["auratype"] = "BUFF",
						["id"] = 91141,
					},
					["Romane: 致死之伤"] = {
						["uptime"] = 0,
						["name"] = "Romane: 致死之伤",
						["active"] = 0,
						["school"] = 1,
						["auratype"] = "DEBUFF",
						["id"] = 115804,
					},
					["业报之触"] = {
						["name"] = "业报之触",
						["active"] = 0,
						["id"] = 122470,
						["school"] = 1,
						["auratype"] = "BUFF",
						["uptime"] = 78,
					},
					["猛虎之眼"] = {
						["name"] = "猛虎之眼",
						["active"] = 0,
						["id"] = 196608,
						["school"] = 8,
						["auratype"] = "BUFF",
						["uptime"] = 123,
					},
					["醉酿投"] = {
						["name"] = "醉酿投",
						["active"] = 0,
						["school"] = 1,
						["uptime"] = 20,
						["auratype"] = "DEBUFF",
						["id"] = 121253,
					},
					["火焰之息"] = {
						["name"] = "火焰之息",
						["active"] = 0,
						["school"] = 4,
						["uptime"] = 20,
						["auratype"] = "DEBUFF",
						["id"] = 123725,
					},
					["壮胆酒"] = {
						["uptime"] = 58,
						["active"] = 0,
						["auratype"] = "BUFF",
						["id"] = 120954,
						["name"] = "壮胆酒",
						["school"] = 1,
					},
					["轻度醉拳"] = {
						["started"] = 1550932209,
						["name"] = "轻度醉拳",
						["active"] = 1,
						["school"] = 1,
						["uptime"] = 19,
						["auratype"] = "DEBUFF",
						["id"] = 124275,
					},
					["抓钩武器"] = {
						["name"] = "抓钩武器",
						["active"] = 0,
						["school"] = 1,
						["uptime"] = 12,
						["auratype"] = "DEBUFF",
						["id"] = 233759,
					},
					["醉拳大师"] = {
						["uptime"] = 67,
						["name"] = "醉拳大师",
						["active"] = 1,
						["school"] = 1,
						["auratype"] = "BUFF",
						["started"] = 1550932272,
						["id"] = 195630,
					},
					["风火雷电"] = {
						["uptime"] = 45,
						["active"] = 0,
						["auratype"] = "BUFF",
						["id"] = 137639,
						["name"] = "风火雷电",
						["school"] = 8,
					},
					["玄秘掌"] = {
						["name"] = "玄秘掌",
						["active"] = 0,
						["id"] = 113746,
						["school"] = 1,
						["auratype"] = "DEBUFF",
						["uptime"] = 243,
					},
					["轮回之触"] = {
						["name"] = "轮回之触",
						["active"] = 0,
						["school"] = 1,
						["uptime"] = 4,
						["auratype"] = "DEBUFF",
						["id"] = 115080,
					},
					["碎玉闪电"] = {
						["school"] = 8,
						["name"] = "碎玉闪电",
						["active"] = 0,
						["id"] = 117952,
						["auratype"] = "DEBUFF",
						["uptime"] = 11,
					},
					["致死之伤"] = {
						["name"] = "致死之伤",
						["active"] = 0,
						["school"] = 1,
						["uptime"] = 20,
						["auratype"] = "DEBUFF",
						["id"] = 115804,
					},
					["中度醉拳"] = {
						["name"] = "中度醉拳",
						["active"] = 0,
						["school"] = 1,
						["uptime"] = 7,
						["auratype"] = "DEBUFF",
						["id"] = 124274,
					},
					["怒雷破"] = {
						["name"] = "怒雷破",
						["active"] = 0,
						["school"] = 1,
						["uptime"] = 1,
						["auratype"] = "BUFF",
						["id"] = 113656,
					},
					["嚎镇八方"] = {
						["name"] = "嚎镇八方",
						["active"] = 0,
						["school"] = 1,
						["uptime"] = 6,
						["auratype"] = "DEBUFF",
						["id"] = 116189,
					},
					["散魔功"] = {
						["uptime"] = 24,
						["active"] = 0,
						["auratype"] = "BUFF",
						["id"] = 122783,
						["name"] = "散魔功",
						["school"] = 8,
					},
					["扫堂腿"] = {
						["uptime"] = 15,
						["active"] = 0,
						["auratype"] = "DEBUFF",
						["id"] = 119381,
						["name"] = "扫堂腿",
						["school"] = 1,
					},
					["神鹤印记"] = {
						["name"] = "神鹤印记",
						["active"] = 0,
						["id"] = 228287,
						["school"] = 1,
						["auratype"] = "DEBUFF",
						["uptime"] = 136,
					},
					["幻灭踢！"] = {
						["name"] = "幻灭踢！",
						["active"] = 0,
						["school"] = 1,
						["uptime"] = 3,
						["auratype"] = "BUFF",
						["id"] = 116768,
					},
					["铁骨酒"] = {
						["name"] = "铁骨酒",
						["active"] = 0,
						["school"] = 1,
						["uptime"] = 7,
						["auratype"] = "BUFF",
						["id"] = 215479,
					},
					["金刚震"] = {
						["name"] = "金刚震",
						["active"] = 0,
						["school"] = 1,
						["uptime"] = 42,
						["auratype"] = "DEBUFF",
						["id"] = 116095,
					},
				},
				["damage"] = 0,
				["damagespells"] = {
				},
				["healing"] = 57104,
				["healed"] = {
					["Player-886-02A40235"] = {
						["role"] = "NONE",
						["name"] = "Romane",
						["amount"] = 57104,
						["class"] = "MONK",
						["shielding"] = 35607,
					},
				},
				["power"] = {
					[12] = {
						["spells"] = {
							[129597] = 0,
							[261978] = 11,
							[100780] = 29,
						},
						["amount"] = 40,
					},
				},
				["id"] = "Player-886-02A40235",
				["maxhp"] = 13175,
				["shielding"] = 35607,
				["damagetakenspells"] = {
					["投掷石块"] = {
						["crushing"] = 0,
						["id"] = 130060,
						["min"] = 155,
						["school"] = 1,
						["critical"] = 0,
						["glancing"] = 0,
						["absorbed"] = 790,
						["name"] = "投掷石块",
						["blocked"] = 0,
						["totalhits"] = 10,
						["resisted"] = 0,
						["max"] = 155,
						["damage"] = 1550,
					},
					["攻击"] = {
						["crushing"] = 0,
						["id"] = 6603,
						["damage"] = 17488,
						["max"] = 480,
						["name"] = "攻击",
						["min"] = 28,
						["totalhits"] = 216,
						["critical"] = 0,
						["blocked"] = 0,
						["school"] = 1,
						["resisted"] = 0,
						["glancing"] = 0,
						["absorbed"] = 7260,
					},
					["醉拳"] = {
						["crushing"] = 0,
						["id"] = 124255,
						["damage"] = 13945,
						["max"] = 288,
						["name"] = "醉拳",
						["min"] = 6,
						["totalhits"] = 184,
						["critical"] = 0,
						["blocked"] = 0,
						["school"] = 1,
						["resisted"] = 0,
						["glancing"] = 0,
						["absorbed"] = 37,
					},
					["猛虎掌"] = {
						["crushing"] = 0,
						["id"] = 130782,
						["damage"] = 3156,
						["max"] = 469,
						["name"] = "猛虎掌",
						["min"] = 296,
						["totalhits"] = 8,
						["critical"] = 0,
						["blocked"] = 0,
						["school"] = 1,
						["resisted"] = 0,
						["glancing"] = 0,
						["absorbed"] = 184,
					},
					["神鹤引项踢"] = {
						["crushing"] = 0,
						["id"] = 130151,
						["damage"] = 57889,
						["max"] = 1289,
						["name"] = "神鹤引项踢",
						["min"] = 281,
						["totalhits"] = 52,
						["critical"] = 0,
						["blocked"] = 0,
						["school"] = 1,
						["resisted"] = 0,
						["glancing"] = 0,
						["absorbed"] = 13255,
					},
					["旭日东升踢"] = {
						["crushing"] = 0,
						["id"] = 130784,
						["damage"] = 2465,
						["max"] = 1462,
						["name"] = "旭日东升踢",
						["min"] = 1003,
						["totalhits"] = 2,
						["critical"] = 0,
						["blocked"] = 0,
						["school"] = 1,
						["resisted"] = 0,
						["glancing"] = 0,
						["absorbed"] = 0,
					},
				},
				["healingspells"] = {
					["猛虎之眼"] = {
						["shielding"] = 0,
						["id"] = 196608,
						["healing"] = 2505,
						["min"] = 7,
						["name"] = "猛虎之眼",
						["hits"] = 64,
						["overhealing"] = 0,
						["max"] = 72,
						["critical"] = 10,
						["absorbed"] = 0,
					},
					["活血术"] = {
						["shielding"] = 0,
						["id"] = 116670,
						["healing"] = 16642,
						["min"] = 916,
						["name"] = "活血术",
						["hits"] = 12,
						["overhealing"] = 0,
						["max"] = 2100,
						["critical"] = 5,
						["absorbed"] = 0,
					},
					["业报之触"] = {
						["shielding"] = 28887,
						["id"] = 122470,
						["healing"] = 28887,
						["min"] = 248,
						["name"] = "业报之触",
						["hits"] = 27,
						["overhealing"] = 0,
						["max"] = 1289,
						["critical"] = 0,
						["absorbed"] = 0,
					},
					["玄牛之赐"] = {
						["shielding"] = 0,
						["id"] = 178173,
						["healing"] = 986,
						["min"] = 986,
						["name"] = "玄牛之赐",
						["max"] = 986,
						["critical"] = 0,
						["absorbed"] = 0,
						["overhealing"] = 0,
						["hits"] = 1,
					},
					["天神护佑"] = {
						["shielding"] = 0,
						["id"] = 216521,
						["healing"] = 1364,
						["min"] = 1364,
						["name"] = "天神护佑",
						["max"] = 1364,
						["critical"] = 0,
						["absorbed"] = 0,
						["overhealing"] = 0,
						["hits"] = 1,
					},
					["免死金牌"] = {
						["shielding"] = 6720,
						["id"] = 131288,
						["healing"] = 6720,
						["min"] = 35,
						["name"] = "免死金牌",
						["hits"] = 25,
						["overhealing"] = 0,
						["max"] = 1071,
						["critical"] = 0,
						["absorbed"] = 0,
					},
				},
				["name"] = "Romane",
				["ffdamagedonetargets"] = {
				},
				["overhealing"] = 0,
				["deathlog"] = {
					{
						["srcname"] = "Romane",
						["amount"] = -63,
						["spellid"] = 124255,
						["hp"] = 218,
						["ts"] = 1550932276.337,
					}, -- [1]
					{
						["ts"] = 1550932276.821,
						["amount"] = -63,
						["spellid"] = 124255,
						["hp"] = 155,
						["srcname"] = "Romane",
					}, -- [2]
					{
						["ts"] = 1550932277.337,
						["amount"] = -63,
						["spellid"] = 124255,
						["hp"] = 92,
						["srcname"] = "Romane",
					}, -- [3]
					{
						["ts"] = 1550932277.887,
						["amount"] = -63,
						["srcname"] = "Romane",
						["hp"] = 29,
						["spellid"] = 124255,
					}, -- [4]
					{
						["ts"] = 1550932278.188,
						["absorb"] = -87,
						["amount"] = -28,
						["srcname"] = "武僧弟子",
						["hp"] = 29,
						["spellid"] = 88163,
					}, -- [5]
					{
						["absorb"] = -70,
						["spellid"] = 88163,
						["amount"] = -28,
						["srcname"] = "武僧弟子",
						["hp"] = 29,
						["ts"] = 1550932278.188,
					}, -- [6]
					{
						["absorb"] = 0,
						["spellid"] = 178173,
						["amount"] = 986,
						["srcname"] = "Romane",
						["hp"] = 987,
						["ts"] = 1550932279.922,
					}, -- [7]
					{
						["ts"] = 1550932280.287,
						["amount"] = -35,
						["srcname"] = "Romane",
						["spellid"] = 124255,
						["hp"] = 952,
					}, -- [8]
					{
						["ts"] = 1550932280.903,
						["spellid"] = 124255,
						["amount"] = -35,
						["srcname"] = "Romane",
						["hp"] = 917,
					}, -- [9]
					{
						["ts"] = 1550932281.453,
						["amount"] = -35,
						["spellid"] = 124255,
						["srcname"] = "Romane",
						["hp"] = 882,
					}, -- [10]
					{
						["srcname"] = "Romane",
						["amount"] = -35,
						["spellid"] = 124255,
						["hp"] = 847,
						["ts"] = 1550932281.937,
					}, -- [11]
					{
						["srcname"] = "Romane",
						["amount"] = -35,
						["spellid"] = 124255,
						["hp"] = 812,
						["ts"] = 1550932282.387,
					}, -- [12]
					{
						["srcname"] = "Romane",
						["amount"] = -35,
						["spellid"] = 124255,
						["hp"] = 777,
						["ts"] = 1550932282.888,
					}, -- [13]
					{
						["srcname"] = "Romane",
						["amount"] = -35,
						["spellid"] = 124255,
						["hp"] = 742,
						["ts"] = 1550932283.404,
					}, -- [14]
					{
						["spellid"] = 124255,
						["amount"] = -63,
						["srcname"] = "Romane",
						["hp"] = 281,
						["ts"] = 1550932275.837,
					}, -- [15]
					["pos"] = 15,
				},
				["damagetaken"] = 96493,
				["ffdamagedone"] = 0,
				["ffdamagedonespells"] = {
				},
			}, -- [1]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 20,
				["interrupts"] = 0,
				["role"] = "NONE",
				["damage"] = 0,
				["damagespells"] = {
				},
				["auras"] = {
					["神鹤引项踢"] = {
						["name"] = "神鹤引项踢",
						["active"] = 0,
						["school"] = 1,
						["uptime"] = 20,
						["auratype"] = "BUFF",
						["id"] = 130150,
					},
				},
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-66180-00006051C0",
				["maxhp"] = 0,
				["shielding"] = 0,
				["damagetakenspells"] = {
				},
				["healingspells"] = {
				},
				["name"] = "程大师",
				["ffdamagedonetargets"] = {
				},
				["overhealing"] = 0,
				["deathlog"] = {
				},
				["damagetaken"] = 0,
				["healing"] = 0,
				["ffdamagedone"] = 0,
			}, -- [2]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 20,
				["interrupts"] = 0,
				["role"] = "NONE",
				["damage"] = 0,
				["damagespells"] = {
				},
				["auras"] = {
					["神鹤引项踢"] = {
						["name"] = "神鹤引项踢",
						["active"] = 0,
						["school"] = 1,
						["uptime"] = 20,
						["auratype"] = "BUFF",
						["id"] = 130150,
					},
				},
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-66180-0000605356",
				["maxhp"] = 0,
				["shielding"] = 0,
				["damagetakenspells"] = {
				},
				["healingspells"] = {
				},
				["name"] = "程大师",
				["ffdamagedonetargets"] = {
				},
				["overhealing"] = 0,
				["deathlog"] = {
				},
				["damagetaken"] = 0,
				["healing"] = 0,
				["ffdamagedone"] = 0,
			}, -- [3]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["role"] = "NONE",
				["damage"] = 0,
				["damagespells"] = {
				},
				["auras"] = {
					["风火雷电"] = {
						["uptime"] = 0,
						["name"] = "风火雷电",
						["active"] = 0,
						["school"] = 1,
						["auratype"] = "BUFF",
						["id"] = 138130,
					},
				},
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-69792-0000605389",
				["maxhp"] = 0,
				["shielding"] = 0,
				["damagetakenspells"] = {
				},
				["healingspells"] = {
				},
				["name"] = "未知目标",
				["ffdamagedonetargets"] = {
				},
				["overhealing"] = 0,
				["deathlog"] = {
				},
				["damagetaken"] = 0,
				["healing"] = 0,
				["ffdamagedone"] = 0,
			}, -- [4]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["role"] = "NONE",
				["damage"] = 0,
				["damagespells"] = {
				},
				["auras"] = {
					["风火雷电"] = {
						["uptime"] = 0,
						["name"] = "风火雷电",
						["active"] = 0,
						["school"] = 1,
						["auratype"] = "BUFF",
						["id"] = 138130,
					},
				},
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-69791-0000605389",
				["maxhp"] = 0,
				["shielding"] = 0,
				["damagetakenspells"] = {
				},
				["healingspells"] = {
				},
				["name"] = "未知目标",
				["ffdamagedonetargets"] = {
				},
				["overhealing"] = 0,
				["deathlog"] = {
				},
				["damagetaken"] = 0,
				["healing"] = 0,
				["ffdamagedone"] = 0,
			}, -- [5]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 17,
				["interrupts"] = 0,
				["role"] = "NONE",
				["damage"] = 0,
				["damagespells"] = {
				},
				["auras"] = {
					["神鹤引项踢"] = {
						["name"] = "神鹤引项踢",
						["active"] = 0,
						["school"] = 1,
						["uptime"] = 17,
						["auratype"] = "BUFF",
						["id"] = 130150,
					},
				},
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-66180-00006053C3",
				["maxhp"] = 0,
				["shielding"] = 0,
				["damagetakenspells"] = {
				},
				["healingspells"] = {
				},
				["name"] = "程大师",
				["ffdamagedonetargets"] = {
				},
				["overhealing"] = 0,
				["deathlog"] = {
				},
				["damagetaken"] = 0,
				["healing"] = 0,
				["ffdamagedone"] = 0,
			}, -- [6]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["role"] = "NONE",
				["damage"] = 0,
				["damagespells"] = {
				},
				["auras"] = {
					["风火雷电"] = {
						["uptime"] = 0,
						["name"] = "风火雷电",
						["active"] = 0,
						["school"] = 1,
						["auratype"] = "BUFF",
						["id"] = 138130,
					},
				},
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-69792-0000605456",
				["maxhp"] = 0,
				["shielding"] = 0,
				["damagetakenspells"] = {
				},
				["healingspells"] = {
				},
				["name"] = "大地之灵",
				["ffdamagedonetargets"] = {
				},
				["overhealing"] = 0,
				["deathlog"] = {
				},
				["damagetaken"] = 0,
				["healing"] = 0,
				["ffdamagedone"] = 0,
			}, -- [7]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["role"] = "NONE",
				["damage"] = 0,
				["damagespells"] = {
				},
				["auras"] = {
					["风火雷电"] = {
						["uptime"] = 0,
						["name"] = "风火雷电",
						["active"] = 0,
						["school"] = 1,
						["auratype"] = "BUFF",
						["id"] = 138130,
					},
				},
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-69791-0000605456",
				["maxhp"] = 0,
				["shielding"] = 0,
				["damagetakenspells"] = {
				},
				["healingspells"] = {
				},
				["name"] = "烈焰之灵",
				["ffdamagedonetargets"] = {
				},
				["overhealing"] = 0,
				["deathlog"] = {
				},
				["damagetaken"] = 0,
				["healing"] = 0,
				["ffdamagedone"] = 0,
			}, -- [8]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 31,
				["interrupts"] = 0,
				["role"] = "NONE",
				["damage"] = 0,
				["damagespells"] = {
				},
				["auras"] = {
					["神鹤引项踢"] = {
						["name"] = "神鹤引项踢",
						["active"] = 0,
						["school"] = 1,
						["uptime"] = 31,
						["auratype"] = "BUFF",
						["id"] = 130150,
					},
				},
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-66180-0000605424",
				["maxhp"] = 0,
				["shielding"] = 0,
				["damagetakenspells"] = {
				},
				["healingspells"] = {
				},
				["name"] = "程大师",
				["ffdamagedonetargets"] = {
				},
				["overhealing"] = 0,
				["deathlog"] = {
				},
				["damagetaken"] = 0,
				["healing"] = 0,
				["ffdamagedone"] = 0,
			}, -- [9]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["role"] = "NONE",
				["damage"] = 0,
				["damagespells"] = {
				},
				["auras"] = {
					["风火雷电"] = {
						["uptime"] = 0,
						["name"] = "风火雷电",
						["active"] = 0,
						["school"] = 1,
						["auratype"] = "BUFF",
						["id"] = 138130,
					},
				},
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-69792-00006054E0",
				["maxhp"] = 0,
				["shielding"] = 0,
				["damagetakenspells"] = {
				},
				["healingspells"] = {
				},
				["name"] = "大地之灵",
				["ffdamagedonetargets"] = {
				},
				["overhealing"] = 0,
				["deathlog"] = {
				},
				["damagetaken"] = 0,
				["healing"] = 0,
				["ffdamagedone"] = 0,
			}, -- [10]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["role"] = "NONE",
				["damage"] = 0,
				["damagespells"] = {
				},
				["auras"] = {
					["风火雷电"] = {
						["uptime"] = 0,
						["name"] = "风火雷电",
						["active"] = 0,
						["school"] = 1,
						["auratype"] = "BUFF",
						["id"] = 138130,
					},
				},
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-69791-00006054E0",
				["maxhp"] = 0,
				["shielding"] = 0,
				["damagetakenspells"] = {
				},
				["healingspells"] = {
				},
				["name"] = "烈焰之灵",
				["ffdamagedonetargets"] = {
				},
				["overhealing"] = 0,
				["deathlog"] = {
				},
				["damagetaken"] = 0,
				["healing"] = 0,
				["ffdamagedone"] = 0,
			}, -- [11]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 31,
				["interrupts"] = 0,
				["role"] = "NONE",
				["damage"] = 0,
				["damagespells"] = {
				},
				["auras"] = {
					["神鹤引项踢"] = {
						["name"] = "神鹤引项踢",
						["active"] = 0,
						["school"] = 1,
						["uptime"] = 13,
						["auratype"] = "BUFF",
						["id"] = 130150,
					},
				},
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-66180-00006054B1",
				["maxhp"] = 0,
				["shielding"] = 0,
				["damagetakenspells"] = {
				},
				["healingspells"] = {
				},
				["name"] = "程大师",
				["ffdamagedonetargets"] = {
				},
				["overhealing"] = 0,
				["deathlog"] = {
				},
				["damagetaken"] = 0,
				["healing"] = 0,
				["ffdamagedone"] = 0,
			}, -- [12]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 32,
				["interrupts"] = 0,
				["role"] = "NONE",
				["damage"] = 0,
				["damagespells"] = {
				},
				["auras"] = {
					["神鹤引项踢"] = {
						["name"] = "神鹤引项踢",
						["active"] = 0,
						["school"] = 1,
						["uptime"] = 13,
						["auratype"] = "BUFF",
						["id"] = 130150,
					},
				},
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-66180-000060553D",
				["maxhp"] = 0,
				["shielding"] = 0,
				["damagetakenspells"] = {
				},
				["healingspells"] = {
				},
				["name"] = "程大师",
				["ffdamagedonetargets"] = {
				},
				["overhealing"] = 0,
				["deathlog"] = {
				},
				["damagetaken"] = 0,
				["healing"] = 0,
				["ffdamagedone"] = 0,
			}, -- [13]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3911-870-8-66101-00027158C6",
				["healing"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "武僧弟子",
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["尝试乘坐载具"] = {
						["school"] = 8,
						["name"] = "尝试乘坐载具",
						["active"] = 1,
						["id"] = 131507,
						["started"] = 1550932279,
						["auratype"] = "BUFF",
						["uptime"] = 0,
					},
				},
				["role"] = "NONE",
			}, -- [14]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3911-870-8-66101-00017158C6",
				["healing"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "武僧弟子",
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["尝试乘坐载具"] = {
						["school"] = 8,
						["name"] = "尝试乘坐载具",
						["active"] = 1,
						["id"] = 131507,
						["started"] = 1550932279,
						["auratype"] = "BUFF",
						["uptime"] = 0,
					},
				},
				["role"] = "NONE",
			}, -- [15]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3911-870-8-66101-0002F158C6",
				["healing"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "武僧弟子",
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["尝试乘坐载具"] = {
						["school"] = 8,
						["name"] = "尝试乘坐载具",
						["active"] = 1,
						["id"] = 131507,
						["started"] = 1550932279,
						["auratype"] = "BUFF",
						["uptime"] = 0,
					},
				},
				["role"] = "NONE",
			}, -- [16]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3911-870-8-66101-0001F158C6",
				["healing"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "武僧弟子",
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["尝试乘坐载具"] = {
						["school"] = 8,
						["name"] = "尝试乘坐载具",
						["active"] = 1,
						["id"] = 131507,
						["started"] = 1550932279,
						["auratype"] = "BUFF",
						["uptime"] = 0,
					},
				},
				["role"] = "NONE",
			}, -- [17]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3911-870-8-66101-00007158C6",
				["healing"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "武僧弟子",
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["尝试乘坐载具"] = {
						["school"] = 8,
						["name"] = "尝试乘坐载具",
						["active"] = 1,
						["id"] = 131507,
						["started"] = 1550932279,
						["auratype"] = "BUFF",
						["uptime"] = 0,
					},
				},
				["role"] = "NONE",
			}, -- [18]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3911-870-8-66101-0000F158C6",
				["healing"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "武僧弟子",
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["尝试乘坐载具"] = {
						["school"] = 8,
						["name"] = "尝试乘坐载具",
						["active"] = 1,
						["id"] = 131507,
						["started"] = 1550932279,
						["auratype"] = "BUFF",
						["uptime"] = 0,
					},
				},
				["role"] = "NONE",
			}, -- [19]
		},
		["deaths"] = 0,
		["mobs"] = {
			["翔龙雕像"] = {
				["players"] = {
				},
				["hdone"] = 0,
				["hdonespell"] = {
					["抚慰之雾"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 0,
						["healing"] = 0,
						["overhealing"] = 58272,
						["hits"] = 314,
					},
				},
				["taken"] = 0,
				["htakenspell"] = {
				},
				["htaken"] = 0,
				["done"] = 0,
			},
			["吉斯坦大师"] = {
				["players"] = {
				},
				["hdone"] = 0,
				["hdonespell"] = {
				},
				["taken"] = 0,
				["htakenspell"] = {
					["抚慰之雾"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 0,
						["healing"] = 0,
						["overhealing"] = 58272,
						["hits"] = 314,
					},
				},
				["htaken"] = 0,
				["done"] = 0,
			},
			["一月阴影-泰兰德"] = {
				["players"] = {
				},
				["hdone"] = 847,
				["htakenspell"] = {
					["真气波"] = {
						["min"] = 295,
						["crits"] = 1,
						["max"] = 295,
						["healing"] = 295,
						["overhealing"] = 0,
						["hits"] = 1,
					},
					["反向伤害"] = {
						["min"] = 552,
						["crits"] = 0,
						["max"] = 552,
						["healing"] = 552,
						["overhealing"] = 0,
						["hits"] = 1,
					},
				},
				["taken"] = 0,
				["done"] = 0,
				["htaken"] = 847,
				["hdonespell"] = {
					["真气波"] = {
						["min"] = 295,
						["crits"] = 1,
						["max"] = 295,
						["healing"] = 295,
						["overhealing"] = 0,
						["hits"] = 1,
					},
					["反向伤害"] = {
						["min"] = 552,
						["crits"] = 0,
						["max"] = 552,
						["healing"] = 552,
						["overhealing"] = 0,
						["hits"] = 1,
					},
				},
			},
			["懮蕥乄箐叶丶-托尔巴拉德"] = {
				["players"] = {
				},
				["hdone"] = 0,
				["htakenspell"] = {
					["猛虎之眼"] = {
						["min"] = 0,
						["crits"] = 1,
						["max"] = 0,
						["healing"] = 0,
						["overhealing"] = 107,
						["hits"] = 1,
					},
				},
				["taken"] = 0,
				["done"] = 0,
				["htaken"] = 0,
				["hdonespell"] = {
					["猛虎之眼"] = {
						["min"] = 0,
						["crits"] = 1,
						["max"] = 0,
						["healing"] = 0,
						["overhealing"] = 107,
						["hits"] = 1,
					},
				},
			},
			["肆影-埃德萨拉"] = {
				["players"] = {
				},
				["hdone"] = 48,
				["htakenspell"] = {
					["猛虎之眼"] = {
						["min"] = 6,
						["crits"] = 0,
						["max"] = 21,
						["healing"] = 48,
						["overhealing"] = 0,
						["hits"] = 3,
					},
				},
				["taken"] = 0,
				["done"] = 0,
				["htaken"] = 48,
				["hdonespell"] = {
					["猛虎之眼"] = {
						["min"] = 6,
						["crits"] = 0,
						["max"] = 21,
						["healing"] = 48,
						["overhealing"] = 0,
						["hits"] = 3,
					},
				},
			},
			["武僧弟子"] = {
				["players"] = {
				},
				["hdone"] = 36285,
				["hdonespell"] = {
					["冥想"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 793,
						["healing"] = 36285,
						["overhealing"] = 6514,
						["hits"] = 54,
					},
				},
				["taken"] = 0,
				["htakenspell"] = {
					["冥想"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 793,
						["healing"] = 36285,
						["overhealing"] = 6514,
						["hits"] = 54,
					},
				},
				["htaken"] = 36285,
				["done"] = 0,
			},
		},
		["mobtaken"] = 0,
		["ffdamagedone"] = 0,
		["healing"] = 57104,
		["damagetaken"] = 96493,
		["overhealing"] = 0,
		["power"] = {
			[12] = 40,
		},
		["dispells"] = 0,
		["name"] = "总计",
		["starttime"] = 1541427696,
		["shielding"] = 35607,
		["mobhdone"] = 37180,
		["last_action"] = 1541427696,
		["mobdone"] = 0,
	},
}
