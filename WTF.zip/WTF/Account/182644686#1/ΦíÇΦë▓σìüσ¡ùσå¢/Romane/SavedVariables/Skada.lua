
SkadaPerCharDB = {
	["total"] = {
		["healingabsorbed"] = 0,
		["auras"] = {
		},
		["ccbreaks"] = 0,
		["time"] = 0,
		["interrupts"] = 0,
		["damage"] = 0,
		["players"] = {
			{
				["healingabsorbed"] = 0,
				["class"] = "MONK",
				["damaged"] = {
				},
				["dispells"] = 0,
				["role"] = "NONE",
				["time"] = 198,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedonespells"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 12960,
				["healed"] = {
					["Player-886-02A40235"] = {
						["role"] = "NONE",
						["name"] = "Romane",
						["amount"] = 46103,
						["class"] = "MONK",
						["shielding"] = 35354,
					},
				},
				["power"] = {
					[12] = {
						["amount"] = 40,
						["spells"] = {
							[129597] = 0,
							[261978] = 11,
							[100780] = 29,
						},
					},
				},
				["id"] = "Player-886-02A40235",
				["damagetaken"] = 73284,
				["damagetakenspells"] = {
					["攻击"] = {
						["crushing"] = 0,
						["id"] = 6603,
						["min"] = 376,
						["school"] = 1,
						["critical"] = 0,
						["glancing"] = 0,
						["absorbed"] = 0,
						["name"] = "攻击",
						["blocked"] = 0,
						["totalhits"] = 8,
						["resisted"] = 0,
						["max"] = 480,
						["damage"] = 3423,
					},
					["醉拳"] = {
						["crushing"] = 0,
						["id"] = 124255,
						["min"] = 9,
						["school"] = 1,
						["critical"] = 0,
						["glancing"] = 0,
						["absorbed"] = 37,
						["name"] = "醉拳",
						["blocked"] = 0,
						["totalhits"] = 39,
						["resisted"] = 0,
						["max"] = 288,
						["damage"] = 6351,
					},
					["猛虎掌"] = {
						["crushing"] = 0,
						["id"] = 130782,
						["min"] = 296,
						["school"] = 1,
						["critical"] = 0,
						["glancing"] = 0,
						["absorbed"] = 184,
						["name"] = "猛虎掌",
						["blocked"] = 0,
						["totalhits"] = 8,
						["resisted"] = 0,
						["max"] = 469,
						["damage"] = 3156,
					},
					["神鹤引项踢"] = {
						["crushing"] = 0,
						["id"] = 130151,
						["min"] = 281,
						["school"] = 1,
						["critical"] = 0,
						["glancing"] = 0,
						["absorbed"] = 13255,
						["name"] = "神鹤引项踢",
						["blocked"] = 0,
						["totalhits"] = 52,
						["resisted"] = 0,
						["max"] = 1289,
						["damage"] = 57889,
					},
					["旭日东升踢"] = {
						["crushing"] = 0,
						["id"] = 130784,
						["min"] = 1003,
						["school"] = 1,
						["critical"] = 0,
						["glancing"] = 0,
						["absorbed"] = 0,
						["name"] = "旭日东升踢",
						["blocked"] = 0,
						["totalhits"] = 2,
						["resisted"] = 0,
						["max"] = 1462,
						["damage"] = 2465,
					},
				},
				["deathlog"] = {
					{
						["absorb"] = 0,
						["hp"] = 4896,
						["amount"] = 8,
						["ts"] = 1541428614.736,
						["spellid"] = 196608,
						["srcname"] = "Romane",
					}, -- [1]
					{
						["ts"] = 1541428616.319,
						["amount"] = -1288,
						["hp"] = 3608,
						["srcname"] = "程大师",
						["spellid"] = 130151,
					}, -- [2]
					{
						["ts"] = 1541428617.236,
						["amount"] = -1288,
						["hp"] = 2320,
						["srcname"] = "程大师",
						["spellid"] = 130151,
					}, -- [3]
					{
						["ts"] = 1541428618.136,
						["amount"] = -1289,
						["hp"] = 1031,
						["spellid"] = 130151,
						["srcname"] = "程大师",
					}, -- [4]
					{
						["ts"] = 1541428604.088,
						["amount"] = -429,
						["hp"] = 2768,
						["spellid"] = 130782,
						["srcname"] = "程大师",
					}, -- [5]
					{
						["absorb"] = 0,
						["ts"] = 1541428604.305,
						["amount"] = 72,
						["hp"] = 2840,
						["srcname"] = "Romane",
						["spellid"] = 196608,
					}, -- [6]
					{
						["absorb"] = 0,
						["ts"] = 1541428606.372,
						["amount"] = 36,
						["hp"] = 2876,
						["srcname"] = "Romane",
						["spellid"] = 196608,
					}, -- [7]
					{
						["hp"] = 2876,
						["ts"] = 1541428606.421,
						["spellid"] = 88163,
						["srcname"] = "程大师",
					}, -- [8]
					{
						["ts"] = 1541428608.421,
						["absorb"] = 0,
						["amount"] = 72,
						["hp"] = 2948,
						["srcname"] = "Romane",
						["spellid"] = 196608,
					}, -- [9]
					{
						["ts"] = 1541428609.038,
						["hp"] = 2948,
						["srcname"] = "程大师",
						["spellid"] = 88163,
					}, -- [10]
					{
						["absorb"] = 0,
						["hp"] = 2984,
						["amount"] = 36,
						["ts"] = 1541428610.288,
						["spellid"] = 196608,
						["srcname"] = "Romane",
					}, -- [11]
					{
						["absorb"] = 0,
						["ts"] = 1541428611.222,
						["amount"] = 916,
						["hp"] = 3900,
						["spellid"] = 116670,
						["srcname"] = "Romane",
					}, -- [12]
					{
						["absorb"] = 0,
						["ts"] = 1541428612.323,
						["amount"] = 36,
						["hp"] = 3936,
						["spellid"] = 196608,
						["srcname"] = "Romane",
					}, -- [13]
					{
						["absorb"] = 0,
						["hp"] = 4852,
						["amount"] = 916,
						["ts"] = 1541428612.722,
						["spellid"] = 116670,
						["srcname"] = "Romane",
					}, -- [14]
					{
						["absorb"] = 0,
						["ts"] = 1541428614.337,
						["amount"] = 36,
						["hp"] = 4888,
						["srcname"] = "Romane",
						["spellid"] = 196608,
					}, -- [15]
					["pos"] = 5,
				},
				["overhealing"] = 0,
				["name"] = "Romane",
				["healingspells"] = {
					["猛虎之眼"] = {
						["shielding"] = 0,
						["id"] = 196608,
						["healing"] = 2505,
						["min"] = 7,
						["name"] = "猛虎之眼",
						["max"] = 72,
						["critical"] = 10,
						["absorbed"] = 0,
						["overhealing"] = 0,
						["hits"] = 64,
					},
					["活血术"] = {
						["shielding"] = 0,
						["id"] = 116670,
						["healing"] = 8244,
						["min"] = 916,
						["name"] = "活血术",
						["max"] = 1832,
						["critical"] = 2,
						["absorbed"] = 0,
						["overhealing"] = 0,
						["hits"] = 7,
					},
					["业报之触"] = {
						["shielding"] = 28887,
						["id"] = 122470,
						["healing"] = 28887,
						["min"] = 248,
						["name"] = "业报之触",
						["max"] = 1289,
						["critical"] = 0,
						["absorbed"] = 0,
						["overhealing"] = 0,
						["hits"] = 27,
					},
					["免死金牌"] = {
						["shielding"] = 6467,
						["id"] = 131288,
						["healing"] = 6467,
						["min"] = 37,
						["name"] = "免死金牌",
						["max"] = 1071,
						["critical"] = 0,
						["absorbed"] = 0,
						["overhealing"] = 0,
						["hits"] = 19,
					},
				},
				["shielding"] = 35354,
				["healing"] = 46103,
				["auras"] = {
					["颂歌"] = {
						["school"] = 1,
						["name"] = "颂歌",
						["active"] = 2,
						["id"] = 91141,
						["started"] = 1541428226,
						["auratype"] = "BUFF",
						["uptime"] = 0,
					},
					["Romane: 致死之伤"] = {
						["school"] = 1,
						["name"] = "Romane: 致死之伤",
						["active"] = 1,
						["id"] = 115804,
						["started"] = 1541428456,
						["auratype"] = "DEBUFF",
						["uptime"] = 0,
					},
					["业报之触"] = {
						["name"] = "业报之触",
						["active"] = 0,
						["id"] = 122470,
						["uptime"] = 78,
						["auratype"] = "BUFF",
						["school"] = 1,
					},
					["猛虎之眼"] = {
						["name"] = "猛虎之眼",
						["active"] = 0,
						["id"] = 196608,
						["uptime"] = 123,
						["auratype"] = "BUFF",
						["school"] = 8,
					},
					["醉酿投"] = {
						["school"] = 1,
						["name"] = "醉酿投",
						["active"] = 0,
						["id"] = 121253,
						["auratype"] = "DEBUFF",
						["uptime"] = 20,
					},
					["火焰之息"] = {
						["school"] = 4,
						["name"] = "火焰之息",
						["active"] = 0,
						["id"] = 123725,
						["auratype"] = "DEBUFF",
						["uptime"] = 20,
					},
					["壮胆酒"] = {
						["uptime"] = 58,
						["active"] = 0,
						["auratype"] = "BUFF",
						["school"] = 1,
						["name"] = "壮胆酒",
						["id"] = 120954,
					},
					["轻度醉拳"] = {
						["school"] = 1,
						["name"] = "轻度醉拳",
						["active"] = 0,
						["id"] = 124275,
						["auratype"] = "DEBUFF",
						["uptime"] = 19,
					},
					["抓钩武器"] = {
						["school"] = 1,
						["name"] = "抓钩武器",
						["active"] = 0,
						["id"] = 233759,
						["auratype"] = "DEBUFF",
						["uptime"] = 12,
					},
					["醉拳大师"] = {
						["school"] = 1,
						["name"] = "醉拳大师",
						["active"] = 1,
						["id"] = 195630,
						["started"] = 1541427722,
						["auratype"] = "BUFF",
						["uptime"] = 16,
					},
					["风火雷电"] = {
						["uptime"] = 45,
						["active"] = 0,
						["auratype"] = "BUFF",
						["school"] = 8,
						["name"] = "风火雷电",
						["id"] = 137639,
					},
					["玄秘掌"] = {
						["name"] = "玄秘掌",
						["active"] = 0,
						["id"] = 113746,
						["uptime"] = 170,
						["auratype"] = "DEBUFF",
						["school"] = 1,
					},
					["轮回之触"] = {
						["school"] = 1,
						["name"] = "轮回之触",
						["active"] = 0,
						["id"] = 115080,
						["auratype"] = "DEBUFF",
						["uptime"] = 4,
					},
					["致死之伤"] = {
						["school"] = 1,
						["name"] = "致死之伤",
						["active"] = 0,
						["id"] = 115804,
						["auratype"] = "DEBUFF",
						["uptime"] = 20,
					},
					["幻灭踢！"] = {
						["school"] = 1,
						["name"] = "幻灭踢！",
						["active"] = 0,
						["id"] = 116768,
						["auratype"] = "BUFF",
						["uptime"] = 3,
					},
					["怒雷破"] = {
						["school"] = 1,
						["name"] = "怒雷破",
						["active"] = 0,
						["id"] = 113656,
						["auratype"] = "BUFF",
						["uptime"] = 1,
					},
					["嚎镇八方"] = {
						["school"] = 1,
						["name"] = "嚎镇八方",
						["active"] = 0,
						["id"] = 116189,
						["auratype"] = "DEBUFF",
						["uptime"] = 3,
					},
					["散魔功"] = {
						["uptime"] = 24,
						["active"] = 0,
						["auratype"] = "BUFF",
						["school"] = 8,
						["name"] = "散魔功",
						["id"] = 122783,
					},
					["中度醉拳"] = {
						["school"] = 1,
						["name"] = "中度醉拳",
						["active"] = 0,
						["id"] = 124274,
						["auratype"] = "DEBUFF",
						["uptime"] = 7,
					},
					["扫堂腿"] = {
						["uptime"] = 15,
						["active"] = 0,
						["auratype"] = "DEBUFF",
						["school"] = 1,
						["name"] = "扫堂腿",
						["id"] = 119381,
					},
					["神鹤印记"] = {
						["name"] = "神鹤印记",
						["active"] = 0,
						["id"] = 228287,
						["uptime"] = 136,
						["auratype"] = "DEBUFF",
						["school"] = 1,
					},
					["铁骨酒"] = {
						["school"] = 1,
						["name"] = "铁骨酒",
						["active"] = 0,
						["id"] = 215479,
						["auratype"] = "BUFF",
						["uptime"] = 7,
					},
					["金刚震"] = {
						["school"] = 1,
						["name"] = "金刚震",
						["active"] = 0,
						["id"] = 116095,
						["auratype"] = "DEBUFF",
						["uptime"] = 42,
					},
				},
				["ccbreaks"] = 0,
			}, -- [1]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 20,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-66180-00006051C0",
				["healing"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "程大师",
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["神鹤引项踢"] = {
						["school"] = 1,
						["name"] = "神鹤引项踢",
						["active"] = 0,
						["id"] = 130150,
						["auratype"] = "BUFF",
						["uptime"] = 20,
					},
				},
				["role"] = "NONE",
			}, -- [2]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 20,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-66180-0000605356",
				["healing"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "程大师",
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["神鹤引项踢"] = {
						["school"] = 1,
						["name"] = "神鹤引项踢",
						["active"] = 0,
						["id"] = 130150,
						["auratype"] = "BUFF",
						["uptime"] = 20,
					},
				},
				["role"] = "NONE",
			}, -- [3]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-69792-0000605389",
				["healing"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "未知目标",
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["风火雷电"] = {
						["school"] = 1,
						["name"] = "风火雷电",
						["active"] = 1,
						["id"] = 138130,
						["started"] = 1541428105,
						["auratype"] = "BUFF",
						["uptime"] = 0,
					},
				},
				["role"] = "NONE",
			}, -- [4]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-69791-0000605389",
				["healing"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "未知目标",
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["风火雷电"] = {
						["school"] = 1,
						["name"] = "风火雷电",
						["active"] = 1,
						["id"] = 138130,
						["started"] = 1541428105,
						["auratype"] = "BUFF",
						["uptime"] = 0,
					},
				},
				["role"] = "NONE",
			}, -- [5]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 17,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-66180-00006053C3",
				["healing"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "程大师",
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["神鹤引项踢"] = {
						["school"] = 1,
						["name"] = "神鹤引项踢",
						["active"] = 0,
						["id"] = 130150,
						["auratype"] = "BUFF",
						["uptime"] = 17,
					},
				},
				["role"] = "NONE",
			}, -- [6]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-69792-0000605456",
				["healing"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "大地之灵",
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["风火雷电"] = {
						["school"] = 1,
						["name"] = "风火雷电",
						["active"] = 1,
						["id"] = 138130,
						["started"] = 1541428310,
						["auratype"] = "BUFF",
						["uptime"] = 0,
					},
				},
				["role"] = "NONE",
			}, -- [7]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-69791-0000605456",
				["healing"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "烈焰之灵",
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["风火雷电"] = {
						["school"] = 1,
						["name"] = "风火雷电",
						["active"] = 1,
						["id"] = 138130,
						["started"] = 1541428310,
						["auratype"] = "BUFF",
						["uptime"] = 0,
					},
				},
				["role"] = "NONE",
			}, -- [8]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 31,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-66180-0000605424",
				["healing"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "程大师",
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["神鹤引项踢"] = {
						["school"] = 1,
						["name"] = "神鹤引项踢",
						["active"] = 0,
						["id"] = 130150,
						["auratype"] = "BUFF",
						["uptime"] = 31,
					},
				},
				["role"] = "NONE",
			}, -- [9]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-69792-00006054E0",
				["healing"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "大地之灵",
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["风火雷电"] = {
						["school"] = 1,
						["name"] = "风火雷电",
						["active"] = 1,
						["id"] = 138130,
						["started"] = 1541428448,
						["auratype"] = "BUFF",
						["uptime"] = 0,
					},
				},
				["role"] = "NONE",
			}, -- [10]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-69791-00006054E0",
				["healing"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "烈焰之灵",
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["风火雷电"] = {
						["school"] = 1,
						["name"] = "风火雷电",
						["active"] = 1,
						["id"] = 138130,
						["started"] = 1541428448,
						["auratype"] = "BUFF",
						["uptime"] = 0,
					},
				},
				["role"] = "NONE",
			}, -- [11]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 31,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-66180-00006054B1",
				["healing"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "程大师",
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["神鹤引项踢"] = {
						["school"] = 1,
						["name"] = "神鹤引项踢",
						["active"] = 0,
						["id"] = 130150,
						["auratype"] = "BUFF",
						["uptime"] = 13,
					},
				},
				["role"] = "NONE",
			}, -- [12]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 32,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-66180-000060553D",
				["healing"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "程大师",
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["神鹤引项踢"] = {
						["school"] = 1,
						["name"] = "神鹤引项踢",
						["active"] = 0,
						["id"] = 130150,
						["auratype"] = "BUFF",
						["uptime"] = 13,
					},
				},
				["role"] = "NONE",
			}, -- [13]
		},
		["deaths"] = 0,
		["mobs"] = {
			["翔龙雕像"] = {
				["players"] = {
				},
				["hdone"] = 0,
				["htakenspell"] = {
				},
				["taken"] = 0,
				["done"] = 0,
				["htaken"] = 0,
				["hdonespell"] = {
					["抚慰之雾"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 0,
						["healing"] = 0,
						["overhealing"] = 43422,
						["hits"] = 234,
					},
				},
			},
			["吉斯坦大师"] = {
				["players"] = {
				},
				["hdone"] = 0,
				["htakenspell"] = {
					["抚慰之雾"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 0,
						["healing"] = 0,
						["overhealing"] = 43422,
						["hits"] = 234,
					},
				},
				["taken"] = 0,
				["done"] = 0,
				["htaken"] = 0,
				["hdonespell"] = {
				},
			},
			["武僧弟子"] = {
				["players"] = {
				},
				["hdone"] = 26473,
				["htakenspell"] = {
					["冥想"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 793,
						["healing"] = 26473,
						["overhealing"] = 4437,
						["hits"] = 39,
					},
				},
				["taken"] = 0,
				["done"] = 0,
				["htaken"] = 26473,
				["hdonespell"] = {
					["冥想"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 793,
						["healing"] = 26473,
						["overhealing"] = 4437,
						["hits"] = 39,
					},
				},
			},
		},
		["mobtaken"] = 0,
		["ffdamagedone"] = 0,
		["healing"] = 46103,
		["damagetaken"] = 73284,
		["overhealing"] = 0,
		["shielding"] = 35354,
		["starttime"] = 1541427696,
		["name"] = "总计",
		["dispells"] = 0,
		["power"] = {
			[12] = 40,
		},
		["mobhdone"] = 26473,
		["last_action"] = 1541427696,
		["mobdone"] = 0,
	},
	["sets"] = {
	},
}
