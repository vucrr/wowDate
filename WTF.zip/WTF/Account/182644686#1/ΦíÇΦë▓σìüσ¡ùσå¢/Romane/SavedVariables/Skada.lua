
SkadaPerCharDB = {
	["total"] = {
		["healingabsorbed"] = 0,
		["auras"] = {
		},
		["ccbreaks"] = 0,
		["time"] = 0,
		["interrupts"] = 0,
		["damage"] = 0,
		["players"] = {
			{
				["healingabsorbed"] = 0,
				["class"] = "MONK",
				["damaged"] = {
				},
				["dispells"] = 0,
				["role"] = "NONE",
				["time"] = 342,
				["interrupts"] = 0,
				["ffdamagedonespells"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["damagetaken"] = 114807,
				["healed"] = {
					["Player-886-02A40235"] = {
						["role"] = "NONE",
						["name"] = "Romane",
						["amount"] = 61859,
						["class"] = "MONK",
						["shielding"] = 36322,
					},
					["Vehicle-0-3043-870-16-66097-0000517B7C"] = {
						["role"] = "NONE",
						["name"] = "梅花桩",
						["amount"] = 0,
						["shielding"] = 0,
					},
					["Creature-0-3043-870-16-66101-0000D17B7C"] = {
						["role"] = "NONE",
						["name"] = "武僧弟子",
						["amount"] = 1056,
						["shielding"] = 0,
					},
				},
				["power"] = {
					[12] = {
						["amount"] = 40,
						["spells"] = {
							[129597] = 0,
							[261978] = 11,
							[100780] = 29,
						},
					},
				},
				["id"] = "Player-886-02A40235",
				["healing"] = 62915,
				["deathlog"] = {
					{
						["ts"] = 1557232613.646,
						["absorb"] = -34,
						["amount"] = -66,
						["hp"] = 793,
						["srcname"] = "武僧弟子",
						["spellid"] = 88163,
					}, -- [1]
					{
						["ts"] = 1557232613.728,
						["absorb"] = -38,
						["amount"] = -75,
						["srcname"] = "武僧弟子",
						["spellid"] = 88163,
						["hp"] = 727,
					}, -- [2]
					{
						["ts"] = 1557232613.728,
						["absorb"] = -31,
						["amount"] = -62,
						["srcname"] = "武僧弟子",
						["spellid"] = 88163,
						["hp"] = 727,
					}, -- [3]
					{
						["ts"] = 1557232613.852,
						["amount"] = -47,
						["spellid"] = 124255,
						["srcname"] = "Romane",
						["hp"] = 680,
					}, -- [4]
					{
						["ts"] = 1557232614.017,
						["spellid"] = 88163,
						["amount"] = -70,
						["hp"] = 543,
						["srcname"] = "武僧弟子",
						["absorb"] = -36,
					}, -- [5]
					{
						["ts"] = 1557232614.383,
						["amount"] = -47,
						["hp"] = 426,
						["spellid"] = 124255,
						["srcname"] = "Romane",
					}, -- [6]
					{
						["absorb"] = -37,
						["ts"] = 1557232614.817,
						["amount"] = -72,
						["hp"] = 426,
						["spellid"] = 88163,
						["srcname"] = "武僧弟子",
					}, -- [7]
					{
						["ts"] = 1557232614.817,
						["absorb"] = -32,
						["amount"] = -62,
						["hp"] = 426,
						["srcname"] = "武僧弟子",
						["spellid"] = 88163,
					}, -- [8]
					{
						["ts"] = 1557232614.817,
						["amount"] = -48,
						["hp"] = 378,
						["spellid"] = 124255,
						["srcname"] = "Romane",
					}, -- [9]
					{
						["ts"] = 1557232615.078,
						["absorb"] = -30,
						["amount"] = -59,
						["hp"] = 244,
						["spellid"] = 88163,
						["srcname"] = "武僧弟子",
					}, -- [10]
					{
						["ts"] = 1557232615.387,
						["amount"] = -47,
						["hp"] = 138,
						["srcname"] = "Romane",
						["spellid"] = 124255,
					}, -- [11]
					{
						["ts"] = 1557232615.603,
						["absorb"] = -31,
						["amount"] = -62,
						["hp"] = 138,
						["srcname"] = "武僧弟子",
						["spellid"] = 88163,
					}, -- [12]
					{
						["ts"] = 1557232615.806,
						["absorb"] = -31,
						["amount"] = -62,
						["hp"] = 76,
						["srcname"] = "武僧弟子",
						["spellid"] = 88163,
					}, -- [13]
					{
						["ts"] = 1557232615.806,
						["absorb"] = -43,
						["amount"] = -75,
						["hp"] = 76,
						["srcname"] = "武僧弟子",
						["spellid"] = 88163,
					}, -- [14]
					{
						["ts"] = 1557232613.44,
						["amount"] = -44,
						["hp"] = 793,
						["spellid"] = 124255,
						["srcname"] = "Romane",
					}, -- [15]
					["pos"] = 15,
				},
				["damagetakenspells"] = {
					["投掷石块"] = {
						["crushing"] = 0,
						["id"] = 130060,
						["damage"] = 4185,
						["max"] = 155,
						["name"] = "投掷石块",
						["min"] = 155,
						["totalhits"] = 27,
						["critical"] = 0,
						["blocked"] = 0,
						["school"] = 1,
						["resisted"] = 0,
						["glancing"] = 0,
						["absorbed"] = 2150,
					},
					["攻击"] = {
						["crushing"] = 0,
						["id"] = 6603,
						["absorbed"] = 13262,
						["glancing"] = 0,
						["critical"] = 0,
						["min"] = 13,
						["school"] = 1,
						["name"] = "攻击",
						["blocked"] = 0,
						["totalhits"] = 366,
						["resisted"] = 0,
						["max"] = 480,
						["damage"] = 26748,
					},
					["醉拳"] = {
						["crushing"] = 0,
						["id"] = 124255,
						["absorbed"] = 37,
						["glancing"] = 0,
						["critical"] = 0,
						["min"] = 6,
						["school"] = 1,
						["name"] = "醉拳",
						["blocked"] = 0,
						["totalhits"] = 306,
						["resisted"] = 0,
						["max"] = 288,
						["damage"] = 20364,
					},
					["猛虎掌"] = {
						["crushing"] = 0,
						["id"] = 130782,
						["absorbed"] = 184,
						["glancing"] = 0,
						["critical"] = 0,
						["min"] = 296,
						["school"] = 1,
						["name"] = "猛虎掌",
						["blocked"] = 0,
						["totalhits"] = 8,
						["resisted"] = 0,
						["max"] = 469,
						["damage"] = 3156,
					},
					["神鹤引项踢"] = {
						["crushing"] = 0,
						["id"] = 130151,
						["absorbed"] = 13255,
						["glancing"] = 0,
						["critical"] = 0,
						["min"] = 281,
						["school"] = 1,
						["name"] = "神鹤引项踢",
						["blocked"] = 0,
						["totalhits"] = 52,
						["resisted"] = 0,
						["max"] = 1289,
						["damage"] = 57889,
					},
					["旭日东升踢"] = {
						["crushing"] = 0,
						["id"] = 130784,
						["absorbed"] = 0,
						["glancing"] = 0,
						["critical"] = 0,
						["min"] = 1003,
						["school"] = 1,
						["name"] = "旭日东升踢",
						["blocked"] = 0,
						["totalhits"] = 2,
						["resisted"] = 0,
						["max"] = 1462,
						["damage"] = 2465,
					},
				},
				["overhealing"] = 403,
				["ffdamagedonetargets"] = {
				},
				["name"] = "Romane",
				["healingspells"] = {
					["猛虎之眼"] = {
						["shielding"] = 0,
						["id"] = 196608,
						["healing"] = 2505,
						["min"] = 7,
						["name"] = "猛虎之眼",
						["absorbed"] = 0,
						["critical"] = 10,
						["max"] = 72,
						["overhealing"] = 0,
						["hits"] = 64,
					},
					["活血术"] = {
						["shielding"] = 0,
						["id"] = 116670,
						["healing"] = 20866,
						["min"] = 916,
						["name"] = "活血术",
						["absorbed"] = 0,
						["critical"] = 6,
						["max"] = 2112,
						["overhealing"] = 0,
						["hits"] = 15,
					},
					["业报之触"] = {
						["shielding"] = 28887,
						["id"] = 122470,
						["healing"] = 28887,
						["min"] = 248,
						["name"] = "业报之触",
						["absorbed"] = 0,
						["critical"] = 0,
						["max"] = 1289,
						["overhealing"] = 0,
						["hits"] = 27,
					},
					["玄牛之赐"] = {
						["shielding"] = 0,
						["id"] = 178173,
						["healing"] = 986,
						["min"] = 986,
						["name"] = "玄牛之赐",
						["hits"] = 1,
						["overhealing"] = 0,
						["max"] = 986,
						["critical"] = 0,
						["absorbed"] = 0,
					},
					["免死金牌"] = {
						["shielding"] = 7435,
						["id"] = 131288,
						["healing"] = 7435,
						["min"] = 35,
						["name"] = "免死金牌",
						["absorbed"] = 0,
						["critical"] = 0,
						["max"] = 1071,
						["overhealing"] = 0,
						["hits"] = 39,
					},
					["天神护佑"] = {
						["shielding"] = 0,
						["id"] = 216521,
						["healing"] = 1431,
						["min"] = 67,
						["name"] = "天神护佑",
						["hits"] = 2,
						["overhealing"] = 0,
						["max"] = 1364,
						["critical"] = 0,
						["absorbed"] = 0,
					},
					["真气爆裂"] = {
						["shielding"] = 0,
						["id"] = 130654,
						["healing"] = 805,
						["min"] = 0,
						["name"] = "真气爆裂",
						["max"] = 805,
						["critical"] = 1,
						["absorbed"] = 0,
						["overhealing"] = 403,
						["hits"] = 2,
					},
				},
				["shielding"] = 36322,
				["maxhp"] = 13175,
				["auras"] = {
					["颂歌"] = {
						["uptime"] = 0,
						["active"] = 0,
						["school"] = 1,
						["id"] = 91141,
						["auratype"] = "BUFF",
						["name"] = "颂歌",
					},
					["Romane: 致死之伤"] = {
						["uptime"] = 0,
						["active"] = 0,
						["school"] = 1,
						["id"] = 115804,
						["auratype"] = "DEBUFF",
						["name"] = "Romane: 致死之伤",
					},
					["业报之触"] = {
						["name"] = "业报之触",
						["active"] = 0,
						["id"] = 122470,
						["uptime"] = 78,
						["auratype"] = "BUFF",
						["school"] = 1,
					},
					["猛虎之眼"] = {
						["name"] = "猛虎之眼",
						["active"] = 0,
						["id"] = 196608,
						["uptime"] = 123,
						["auratype"] = "BUFF",
						["school"] = 8,
					},
					["醉酿投"] = {
						["name"] = "醉酿投",
						["active"] = 0,
						["school"] = 1,
						["id"] = 121253,
						["auratype"] = "DEBUFF",
						["uptime"] = 28,
					},
					["火焰之息"] = {
						["name"] = "火焰之息",
						["active"] = 0,
						["school"] = 4,
						["id"] = 123725,
						["auratype"] = "DEBUFF",
						["uptime"] = 20,
					},
					["壮胆酒"] = {
						["uptime"] = 58,
						["active"] = 0,
						["auratype"] = "BUFF",
						["school"] = 1,
						["name"] = "壮胆酒",
						["id"] = 120954,
					},
					["禅悟冥想"] = {
						["school"] = 8,
						["name"] = "禅悟冥想",
						["active"] = 0,
						["id"] = 115176,
						["auratype"] = "BUFF",
						["uptime"] = 0,
					},
					["轻度醉拳"] = {
						["id"] = 124275,
						["name"] = "轻度醉拳",
						["started"] = 1557232555,
						["school"] = 1,
						["auratype"] = "DEBUFF",
						["uptime"] = 19,
						["active"] = 1,
					},
					["抓钩武器"] = {
						["name"] = "抓钩武器",
						["active"] = 0,
						["school"] = 1,
						["id"] = 233759,
						["auratype"] = "DEBUFF",
						["uptime"] = 12,
					},
					["醉拳大师"] = {
						["started"] = 1557232615,
						["id"] = 195630,
						["uptime"] = 111,
						["active"] = 1,
						["school"] = 1,
						["auratype"] = "BUFF",
						["name"] = "醉拳大师",
					},
					["风火雷电"] = {
						["uptime"] = 45,
						["active"] = 0,
						["auratype"] = "BUFF",
						["school"] = 8,
						["name"] = "风火雷电",
						["id"] = 137639,
					},
					["玄秘掌"] = {
						["name"] = "玄秘掌",
						["active"] = 0,
						["id"] = 113746,
						["uptime"] = 298,
						["auratype"] = "DEBUFF",
						["school"] = 1,
					},
					["轮回之触"] = {
						["name"] = "轮回之触",
						["active"] = 0,
						["school"] = 1,
						["id"] = 115080,
						["auratype"] = "DEBUFF",
						["uptime"] = 4,
					},
					["碎玉闪电"] = {
						["name"] = "碎玉闪电",
						["active"] = 0,
						["school"] = 8,
						["uptime"] = 17,
						["auratype"] = "DEBUFF",
						["id"] = 117952,
					},
					["致死之伤"] = {
						["name"] = "致死之伤",
						["active"] = 0,
						["school"] = 1,
						["id"] = 115804,
						["auratype"] = "DEBUFF",
						["uptime"] = 20,
					},
					["中度醉拳"] = {
						["name"] = "中度醉拳",
						["active"] = 0,
						["school"] = 1,
						["id"] = 124274,
						["auratype"] = "DEBUFF",
						["uptime"] = 7,
					},
					["怒雷破"] = {
						["name"] = "怒雷破",
						["active"] = 0,
						["school"] = 1,
						["id"] = 113656,
						["auratype"] = "BUFF",
						["uptime"] = 1,
					},
					["嚎镇八方"] = {
						["name"] = "嚎镇八方",
						["active"] = 0,
						["school"] = 1,
						["id"] = 116189,
						["auratype"] = "DEBUFF",
						["uptime"] = 6,
					},
					["散魔功"] = {
						["uptime"] = 24,
						["active"] = 0,
						["auratype"] = "BUFF",
						["school"] = 8,
						["name"] = "散魔功",
						["id"] = 122783,
					},
					["幻灭踢！"] = {
						["name"] = "幻灭踢！",
						["active"] = 0,
						["school"] = 1,
						["id"] = 116768,
						["auratype"] = "BUFF",
						["uptime"] = 3,
					},
					["神鹤印记"] = {
						["name"] = "神鹤印记",
						["active"] = 0,
						["id"] = 228287,
						["uptime"] = 136,
						["auratype"] = "DEBUFF",
						["school"] = 1,
					},
					["扫堂腿"] = {
						["uptime"] = 20,
						["active"] = 0,
						["auratype"] = "DEBUFF",
						["school"] = 1,
						["name"] = "扫堂腿",
						["id"] = 119381,
					},
					["铁骨酒"] = {
						["name"] = "铁骨酒",
						["active"] = 0,
						["school"] = 1,
						["id"] = 215479,
						["auratype"] = "BUFF",
						["uptime"] = 14,
					},
					["金刚震"] = {
						["name"] = "金刚震",
						["active"] = 0,
						["school"] = 1,
						["id"] = 116095,
						["auratype"] = "DEBUFF",
						["uptime"] = 42,
					},
				},
				["ccbreaks"] = 0,
			}, -- [1]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 20,
				["interrupts"] = 0,
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["healing"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-66180-00006051C0",
				["maxhp"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "程大师",
				["ffdamagedonetargets"] = {
				},
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["神鹤引项踢"] = {
						["name"] = "神鹤引项踢",
						["active"] = 0,
						["school"] = 1,
						["id"] = 130150,
						["auratype"] = "BUFF",
						["uptime"] = 20,
					},
				},
				["role"] = "NONE",
			}, -- [2]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 20,
				["interrupts"] = 0,
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["healing"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-66180-0000605356",
				["maxhp"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "程大师",
				["ffdamagedonetargets"] = {
				},
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["神鹤引项踢"] = {
						["name"] = "神鹤引项踢",
						["active"] = 0,
						["school"] = 1,
						["id"] = 130150,
						["auratype"] = "BUFF",
						["uptime"] = 20,
					},
				},
				["role"] = "NONE",
			}, -- [3]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["healing"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-69792-0000605389",
				["maxhp"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "未知目标",
				["ffdamagedonetargets"] = {
				},
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["风火雷电"] = {
						["uptime"] = 0,
						["active"] = 0,
						["school"] = 1,
						["id"] = 138130,
						["auratype"] = "BUFF",
						["name"] = "风火雷电",
					},
				},
				["role"] = "NONE",
			}, -- [4]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["healing"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-69791-0000605389",
				["maxhp"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "未知目标",
				["ffdamagedonetargets"] = {
				},
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["风火雷电"] = {
						["uptime"] = 0,
						["active"] = 0,
						["school"] = 1,
						["id"] = 138130,
						["auratype"] = "BUFF",
						["name"] = "风火雷电",
					},
				},
				["role"] = "NONE",
			}, -- [5]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 17,
				["interrupts"] = 0,
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["healing"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-66180-00006053C3",
				["maxhp"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "程大师",
				["ffdamagedonetargets"] = {
				},
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["神鹤引项踢"] = {
						["name"] = "神鹤引项踢",
						["active"] = 0,
						["school"] = 1,
						["id"] = 130150,
						["auratype"] = "BUFF",
						["uptime"] = 17,
					},
				},
				["role"] = "NONE",
			}, -- [6]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["healing"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-69792-0000605456",
				["maxhp"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "大地之灵",
				["ffdamagedonetargets"] = {
				},
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["风火雷电"] = {
						["uptime"] = 0,
						["active"] = 0,
						["school"] = 1,
						["id"] = 138130,
						["auratype"] = "BUFF",
						["name"] = "风火雷电",
					},
				},
				["role"] = "NONE",
			}, -- [7]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["healing"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-69791-0000605456",
				["maxhp"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "烈焰之灵",
				["ffdamagedonetargets"] = {
				},
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["风火雷电"] = {
						["uptime"] = 0,
						["active"] = 0,
						["school"] = 1,
						["id"] = 138130,
						["auratype"] = "BUFF",
						["name"] = "风火雷电",
					},
				},
				["role"] = "NONE",
			}, -- [8]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 31,
				["interrupts"] = 0,
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["healing"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-66180-0000605424",
				["maxhp"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "程大师",
				["ffdamagedonetargets"] = {
				},
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["神鹤引项踢"] = {
						["name"] = "神鹤引项踢",
						["active"] = 0,
						["school"] = 1,
						["id"] = 130150,
						["auratype"] = "BUFF",
						["uptime"] = 31,
					},
				},
				["role"] = "NONE",
			}, -- [9]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["healing"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-69792-00006054E0",
				["maxhp"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "大地之灵",
				["ffdamagedonetargets"] = {
				},
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["风火雷电"] = {
						["uptime"] = 0,
						["active"] = 0,
						["school"] = 1,
						["id"] = 138130,
						["auratype"] = "BUFF",
						["name"] = "风火雷电",
					},
				},
				["role"] = "NONE",
			}, -- [10]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["healing"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-69791-00006054E0",
				["maxhp"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "烈焰之灵",
				["ffdamagedonetargets"] = {
				},
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["风火雷电"] = {
						["uptime"] = 0,
						["active"] = 0,
						["school"] = 1,
						["id"] = 138130,
						["auratype"] = "BUFF",
						["name"] = "风火雷电",
					},
				},
				["role"] = "NONE",
			}, -- [11]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 31,
				["interrupts"] = 0,
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["healing"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-66180-00006054B1",
				["maxhp"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "程大师",
				["ffdamagedonetargets"] = {
				},
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["神鹤引项踢"] = {
						["name"] = "神鹤引项踢",
						["active"] = 0,
						["school"] = 1,
						["id"] = 130150,
						["auratype"] = "BUFF",
						["uptime"] = 13,
					},
				},
				["role"] = "NONE",
			}, -- [12]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 32,
				["interrupts"] = 0,
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["healing"] = 0,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-862-66180-000060553D",
				["maxhp"] = 0,
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "程大师",
				["ffdamagedonetargets"] = {
				},
				["healingspells"] = {
				},
				["shielding"] = 0,
				["auras"] = {
					["神鹤引项踢"] = {
						["name"] = "神鹤引项踢",
						["active"] = 0,
						["school"] = 1,
						["id"] = 130150,
						["auratype"] = "BUFF",
						["uptime"] = 13,
					},
				},
				["role"] = "NONE",
			}, -- [13]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["role"] = "NONE",
				["damage"] = 0,
				["damagespells"] = {
				},
				["auras"] = {
					["尝试乘坐载具"] = {
						["uptime"] = 0,
						["name"] = "尝试乘坐载具",
						["active"] = 0,
						["school"] = 8,
						["auratype"] = "BUFF",
						["id"] = 131507,
					},
				},
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3911-870-8-66101-00027158C6",
				["maxhp"] = 0,
				["shielding"] = 0,
				["damagetakenspells"] = {
				},
				["healingspells"] = {
				},
				["name"] = "武僧弟子",
				["ffdamagedonetargets"] = {
				},
				["overhealing"] = 0,
				["deathlog"] = {
				},
				["damagetaken"] = 0,
				["healing"] = 0,
				["ffdamagedone"] = 0,
			}, -- [14]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["role"] = "NONE",
				["damage"] = 0,
				["damagespells"] = {
				},
				["auras"] = {
					["尝试乘坐载具"] = {
						["uptime"] = 0,
						["name"] = "尝试乘坐载具",
						["active"] = 0,
						["school"] = 8,
						["auratype"] = "BUFF",
						["id"] = 131507,
					},
				},
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3911-870-8-66101-00017158C6",
				["maxhp"] = 0,
				["shielding"] = 0,
				["damagetakenspells"] = {
				},
				["healingspells"] = {
				},
				["name"] = "武僧弟子",
				["ffdamagedonetargets"] = {
				},
				["overhealing"] = 0,
				["deathlog"] = {
				},
				["damagetaken"] = 0,
				["healing"] = 0,
				["ffdamagedone"] = 0,
			}, -- [15]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["role"] = "NONE",
				["damage"] = 0,
				["damagespells"] = {
				},
				["auras"] = {
					["尝试乘坐载具"] = {
						["uptime"] = 0,
						["name"] = "尝试乘坐载具",
						["active"] = 0,
						["school"] = 8,
						["auratype"] = "BUFF",
						["id"] = 131507,
					},
				},
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3911-870-8-66101-0002F158C6",
				["maxhp"] = 0,
				["shielding"] = 0,
				["damagetakenspells"] = {
				},
				["healingspells"] = {
				},
				["name"] = "武僧弟子",
				["ffdamagedonetargets"] = {
				},
				["overhealing"] = 0,
				["deathlog"] = {
				},
				["damagetaken"] = 0,
				["healing"] = 0,
				["ffdamagedone"] = 0,
			}, -- [16]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["role"] = "NONE",
				["damage"] = 0,
				["damagespells"] = {
				},
				["auras"] = {
					["尝试乘坐载具"] = {
						["uptime"] = 0,
						["name"] = "尝试乘坐载具",
						["active"] = 0,
						["school"] = 8,
						["auratype"] = "BUFF",
						["id"] = 131507,
					},
				},
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3911-870-8-66101-0001F158C6",
				["maxhp"] = 0,
				["shielding"] = 0,
				["damagetakenspells"] = {
				},
				["healingspells"] = {
				},
				["name"] = "武僧弟子",
				["ffdamagedonetargets"] = {
				},
				["overhealing"] = 0,
				["deathlog"] = {
				},
				["damagetaken"] = 0,
				["healing"] = 0,
				["ffdamagedone"] = 0,
			}, -- [17]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["role"] = "NONE",
				["damage"] = 0,
				["damagespells"] = {
				},
				["auras"] = {
					["尝试乘坐载具"] = {
						["uptime"] = 0,
						["name"] = "尝试乘坐载具",
						["active"] = 0,
						["school"] = 8,
						["auratype"] = "BUFF",
						["id"] = 131507,
					},
				},
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3911-870-8-66101-00007158C6",
				["maxhp"] = 0,
				["shielding"] = 0,
				["damagetakenspells"] = {
				},
				["healingspells"] = {
				},
				["name"] = "武僧弟子",
				["ffdamagedonetargets"] = {
				},
				["overhealing"] = 0,
				["deathlog"] = {
				},
				["damagetaken"] = 0,
				["healing"] = 0,
				["ffdamagedone"] = 0,
			}, -- [18]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
				["interrupts"] = 0,
				["role"] = "NONE",
				["damage"] = 0,
				["damagespells"] = {
				},
				["auras"] = {
					["尝试乘坐载具"] = {
						["uptime"] = 0,
						["name"] = "尝试乘坐载具",
						["active"] = 0,
						["school"] = 8,
						["auratype"] = "BUFF",
						["id"] = 131507,
					},
				},
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Creature-0-3911-870-8-66101-0000F158C6",
				["maxhp"] = 0,
				["shielding"] = 0,
				["damagetakenspells"] = {
				},
				["healingspells"] = {
				},
				["name"] = "武僧弟子",
				["ffdamagedonetargets"] = {
				},
				["overhealing"] = 0,
				["deathlog"] = {
				},
				["damagetaken"] = 0,
				["healing"] = 0,
				["ffdamagedone"] = 0,
			}, -- [19]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["auras"] = {
					["尝试乘坐载具"] = {
						["school"] = 8,
						["name"] = "尝试乘坐载具",
						["active"] = 0,
						["id"] = 131507,
						["auratype"] = "BUFF",
						["uptime"] = 0,
					},
				},
				["role"] = "NONE",
				["overhealing"] = 0,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 0,
				["damagetaken"] = 0,
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-16-66101-0002517B7C",
				["deathlog"] = {
				},
				["damagetakenspells"] = {
				},
				["healingspells"] = {
				},
				["shielding"] = 0,
				["name"] = "武僧弟子",
				["healing"] = 0,
				["healed"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
			}, -- [20]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["auras"] = {
					["尝试乘坐载具"] = {
						["school"] = 8,
						["name"] = "尝试乘坐载具",
						["active"] = 0,
						["id"] = 131507,
						["auratype"] = "BUFF",
						["uptime"] = 0,
					},
				},
				["role"] = "NONE",
				["overhealing"] = 0,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 0,
				["damagetaken"] = 0,
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-16-66101-0001517B7C",
				["deathlog"] = {
				},
				["damagetakenspells"] = {
				},
				["healingspells"] = {
				},
				["shielding"] = 0,
				["name"] = "武僧弟子",
				["healing"] = 0,
				["healed"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
			}, -- [21]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["auras"] = {
					["尝试乘坐载具"] = {
						["school"] = 8,
						["name"] = "尝试乘坐载具",
						["active"] = 0,
						["id"] = 131507,
						["auratype"] = "BUFF",
						["uptime"] = 0,
					},
				},
				["role"] = "NONE",
				["overhealing"] = 0,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 0,
				["damagetaken"] = 0,
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-16-66101-0002D17B7C",
				["deathlog"] = {
				},
				["damagetakenspells"] = {
				},
				["healingspells"] = {
				},
				["shielding"] = 0,
				["name"] = "武僧弟子",
				["healing"] = 0,
				["healed"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 0,
			}, -- [22]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["auras"] = {
					["尝试乘坐载具"] = {
						["school"] = 8,
						["name"] = "尝试乘坐载具",
						["active"] = 0,
						["id"] = 131507,
						["auratype"] = "BUFF",
						["uptime"] = 1,
					},
				},
				["role"] = "NONE",
				["overhealing"] = 0,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 0,
				["damagetaken"] = 0,
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-16-66101-0000517B7C",
				["deathlog"] = {
				},
				["damagetakenspells"] = {
				},
				["healingspells"] = {
				},
				["shielding"] = 0,
				["name"] = "武僧弟子",
				["healing"] = 0,
				["healed"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 1,
			}, -- [23]
			{
				["healingabsorbed"] = 0,
				["ffdamagedonespells"] = {
				},
				["damaged"] = {
				},
				["auras"] = {
					["尝试乘坐载具"] = {
						["school"] = 8,
						["name"] = "尝试乘坐载具",
						["active"] = 0,
						["id"] = 131507,
						["auratype"] = "BUFF",
						["uptime"] = 1,
					},
				},
				["role"] = "NONE",
				["overhealing"] = 0,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 0,
				["damagetaken"] = 0,
				["power"] = {
				},
				["id"] = "Creature-0-3043-870-16-66101-0001D17B7C",
				["deathlog"] = {
				},
				["damagetakenspells"] = {
				},
				["healingspells"] = {
				},
				["shielding"] = 0,
				["name"] = "武僧弟子",
				["healing"] = 0,
				["healed"] = {
				},
				["dispells"] = 0,
				["ccbreaks"] = 0,
				["time"] = 1,
			}, -- [24]
		},
		["deaths"] = 0,
		["mobs"] = {
			["吉斯坦大师"] = {
				["players"] = {
				},
				["hdone"] = 0,
				["done"] = 0,
				["taken"] = 0,
				["htakenspell"] = {
					["抚慰之雾"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 0,
						["healing"] = 0,
						["overhealing"] = 72382,
						["hits"] = 390,
					},
				},
				["htaken"] = 0,
				["hdonespell"] = {
				},
			},
			["肆影-埃德萨拉"] = {
				["players"] = {
				},
				["hdone"] = 48,
				["hdonespell"] = {
					["猛虎之眼"] = {
						["min"] = 6,
						["crits"] = 0,
						["max"] = 21,
						["healing"] = 48,
						["overhealing"] = 0,
						["hits"] = 3,
					},
				},
				["taken"] = 0,
				["htakenspell"] = {
					["猛虎之眼"] = {
						["min"] = 6,
						["crits"] = 0,
						["max"] = 21,
						["healing"] = 48,
						["overhealing"] = 0,
						["hits"] = 3,
					},
				},
				["htaken"] = 48,
				["done"] = 0,
			},
			["武僧弟子"] = {
				["players"] = {
				},
				["hdone"] = 46268,
				["done"] = 0,
				["taken"] = 0,
				["htakenspell"] = {
					["冥想"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 793,
						["healing"] = 46268,
						["overhealing"] = 8421,
						["hits"] = 69,
					},
				},
				["htaken"] = 46268,
				["hdonespell"] = {
					["冥想"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 793,
						["healing"] = 46268,
						["overhealing"] = 8421,
						["hits"] = 69,
					},
				},
			},
			["灬伽椰子灬-影之哀伤"] = {
				["players"] = {
				},
				["hdone"] = 69,
				["htakenspell"] = {
					["猛虎之眼"] = {
						["min"] = 27,
						["crits"] = 0,
						["max"] = 42,
						["healing"] = 69,
						["overhealing"] = 0,
						["hits"] = 2,
					},
				},
				["taken"] = 0,
				["done"] = 0,
				["htaken"] = 69,
				["hdonespell"] = {
					["猛虎之眼"] = {
						["min"] = 27,
						["crits"] = 0,
						["max"] = 42,
						["healing"] = 69,
						["overhealing"] = 0,
						["hits"] = 2,
					},
				},
			},
			["翔龙雕像"] = {
				["players"] = {
				},
				["hdone"] = 0,
				["done"] = 0,
				["taken"] = 0,
				["htakenspell"] = {
				},
				["htaken"] = 0,
				["hdonespell"] = {
					["抚慰之雾"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 0,
						["healing"] = 0,
						["overhealing"] = 72382,
						["hits"] = 390,
					},
				},
			},
			["花脸老猫-格瑞姆巴托"] = {
				["players"] = {
				},
				["hdone"] = 0,
				["htakenspell"] = {
					["精华之泉"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 0,
						["healing"] = 0,
						["overhealing"] = 879,
						["hits"] = 10,
					},
					["活血术"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 0,
						["healing"] = 0,
						["overhealing"] = 621,
						["hits"] = 1,
					},
				},
				["taken"] = 0,
				["done"] = 0,
				["htaken"] = 0,
				["hdonespell"] = {
					["活血术"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 0,
						["healing"] = 0,
						["overhealing"] = 621,
						["hits"] = 1,
					},
				},
			},
			["一月阴影-泰兰德"] = {
				["players"] = {
				},
				["hdone"] = 847,
				["hdonespell"] = {
					["真气波"] = {
						["min"] = 295,
						["crits"] = 1,
						["max"] = 295,
						["healing"] = 295,
						["overhealing"] = 0,
						["hits"] = 1,
					},
					["反向伤害"] = {
						["min"] = 552,
						["crits"] = 0,
						["max"] = 552,
						["healing"] = 552,
						["overhealing"] = 0,
						["hits"] = 1,
					},
				},
				["taken"] = 0,
				["htakenspell"] = {
					["真气波"] = {
						["min"] = 295,
						["crits"] = 1,
						["max"] = 295,
						["healing"] = 295,
						["overhealing"] = 0,
						["hits"] = 1,
					},
					["反向伤害"] = {
						["min"] = 552,
						["crits"] = 0,
						["max"] = 552,
						["healing"] = 552,
						["overhealing"] = 0,
						["hits"] = 1,
					},
				},
				["htaken"] = 847,
				["done"] = 0,
			},
			["懮蕥乄箐叶丶-托尔巴拉德"] = {
				["players"] = {
				},
				["hdone"] = 0,
				["hdonespell"] = {
					["猛虎之眼"] = {
						["min"] = 0,
						["crits"] = 1,
						["max"] = 0,
						["healing"] = 0,
						["overhealing"] = 107,
						["hits"] = 1,
					},
				},
				["taken"] = 0,
				["htakenspell"] = {
					["猛虎之眼"] = {
						["min"] = 0,
						["crits"] = 1,
						["max"] = 0,
						["healing"] = 0,
						["overhealing"] = 107,
						["hits"] = 1,
					},
				},
				["htaken"] = 0,
				["done"] = 0,
			},
			["她疯舞神-甜水绿洲"] = {
				["players"] = {
				},
				["hdone"] = 0,
				["htakenspell"] = {
				},
				["taken"] = 0,
				["done"] = 0,
				["htaken"] = 0,
				["hdonespell"] = {
					["精华之泉"] = {
						["min"] = 0,
						["crits"] = 0,
						["max"] = 0,
						["healing"] = 0,
						["overhealing"] = 879,
						["hits"] = 10,
					},
				},
			},
			["Herrington-安东尼达斯"] = {
				["players"] = {
				},
				["hdone"] = 117,
				["htakenspell"] = {
					["猛虎之眼"] = {
						["min"] = 6,
						["crits"] = 1,
						["max"] = 74,
						["healing"] = 117,
						["overhealing"] = 0,
						["hits"] = 3,
					},
				},
				["taken"] = 0,
				["done"] = 0,
				["htaken"] = 117,
				["hdonespell"] = {
					["猛虎之眼"] = {
						["min"] = 6,
						["crits"] = 1,
						["max"] = 74,
						["healing"] = 117,
						["overhealing"] = 0,
						["hits"] = 3,
					},
				},
			},
		},
		["mobtaken"] = 0,
		["ffdamagedone"] = 0,
		["healing"] = 62915,
		["damagetaken"] = 114807,
		["overhealing"] = 403,
		["shielding"] = 36322,
		["starttime"] = 1541427696,
		["name"] = "总计",
		["dispells"] = 0,
		["power"] = {
			[12] = 40,
		},
		["mobhdone"] = 47349,
		["last_action"] = 1541427696,
		["mobdone"] = 0,
	},
	["sets"] = {
	},
}
