
classSpecs = {
	{
		["targetDebuffSpells"] = {
		},
		["selfBuffSpells"] = {
		},
	}, -- [1]
	{
		["targetDebuffSpells"] = {
		},
		["selfBuffSpells"] = {
		},
	}, -- [2]
	{
		["targetDebuffSpells"] = {
		},
		["selfBuffSpells"] = {
		},
	}, -- [3]
}
frameScale = 1
framePositions = {
	["SelfBuffFrame"] = {
		"CENTER", -- [1]
		nil, -- [2]
		"CENTER", -- [3]
		0, -- [4]
		0, -- [5]
	},
	["TargetDeBuffFrame"] = {
		"CENTER", -- [1]
		nil, -- [2]
		"CENTER", -- [3]
		0, -- [4]
		40, -- [5]
	},
}
version = 105
