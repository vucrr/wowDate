
PlateColorDB = {
	["zb"] = true,
	["arrow"] = false,
	["scale"] = false,
	["mb"] = true,
	["ch"] = true,
	["name"] = true,
	["zsx"] = 0.35,
	["jian"] = true,
	["zs"] = false,
}
