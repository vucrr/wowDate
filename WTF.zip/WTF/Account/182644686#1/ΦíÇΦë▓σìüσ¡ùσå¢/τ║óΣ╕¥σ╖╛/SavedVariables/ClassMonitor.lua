
ClassMonitorDataPerChar = {
	["Plugins"] = {
	},
	["Global"] = {
		["autogridanchor"] = false,
		["configVersion"] = "1.4.1",
		["debug"] = false,
		["height"] = 16,
		["version"] = "3.7.1",
		["autogridanchorspacing"] = 3,
		["width"] = 262,
	},
}
