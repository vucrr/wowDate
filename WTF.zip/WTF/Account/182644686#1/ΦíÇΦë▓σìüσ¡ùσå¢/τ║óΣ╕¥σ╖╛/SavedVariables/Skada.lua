
SkadaPerCharDB = {
	["sets"] = {
	},
	["total"] = {
		["healingabsorbed"] = 0,
		["auras"] = {
		},
		["ccbreaks"] = 0,
		["time"] = 0,
		["interrupts"] = 0,
		["damage"] = 0,
		["players"] = {
		},
		["deaths"] = 0,
		["mobs"] = {
		},
		["mobtaken"] = 0,
		["ffdamagedone"] = 0,
		["healing"] = 0,
		["damagetaken"] = 0,
		["overhealing"] = 0,
		["power"] = {
		},
		["dispells"] = 0,
		["name"] = "总计",
		["starttime"] = 1552573511,
		["shielding"] = 0,
		["mobhdone"] = 0,
		["last_action"] = 1552573511,
		["mobdone"] = 0,
	},
}
