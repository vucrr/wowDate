
SkadaPerCharDB = {
	["total"] = {
		["healingabsorbed"] = 0,
		["auras"] = {
		},
		["ccbreaks"] = 0,
		["time"] = 0,
		["interrupts"] = 0,
		["damage"] = 0,
		["players"] = {
		},
		["deaths"] = 0,
		["mobs"] = {
		},
		["mobtaken"] = 0,
		["ffdamagedone"] = 0,
		["healing"] = 0,
		["damagetaken"] = 0,
		["overhealing"] = 0,
		["shielding"] = 0,
		["starttime"] = 1530158792,
		["name"] = "总计",
		["dispells"] = 0,
		["power"] = {
		},
		["mobhdone"] = 0,
		["last_action"] = 1530158792,
		["mobdone"] = 0,
	},
	["sets"] = {
	},
}
