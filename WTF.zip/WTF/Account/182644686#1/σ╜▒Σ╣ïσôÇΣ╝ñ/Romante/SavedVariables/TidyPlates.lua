
TidyPlatesOptions = {
	["PrimaryProfile"] = "Tank",
	["SecondSpecProfile"] = "Tank",
	["FriendlyAutomation"] = "不自动",
	["EnemyAutomation"] = "不自动",
	["FourthSpecProfile"] = "Damage",
	["ThirdSpecProfile"] = "Tank",
	["DisableCastBars"] = false,
	["ActiveTheme"] = "Blizzard",
	["ForceBlizzardFont"] = false,
	["WelcomeShown"] = false,
	["FirstSpecProfile"] = "Tank",
}
