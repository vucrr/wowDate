
SkadaPerCharDB = {
	["total"] = {
		["healingabsorbed"] = 0,
		["auras"] = {
		},
		["ccbreaks"] = 0,
		["time"] = 0,
		["interrupts"] = 0,
		["damage"] = 0,
		["players"] = {
			{
				["healingabsorbed"] = 0,
				["class"] = "DEMONHUNTER",
				["damaged"] = {
				},
				["dispells"] = 0,
				["role"] = "DAMAGER",
				["time"] = 0,
				["interrupts"] = 0,
				["ffdamagedonetargets"] = {
				},
				["ffdamagedonespells"] = {
				},
				["ffdamagedone"] = 0,
				["damage"] = 0,
				["damagespells"] = {
				},
				["maxhp"] = 139420,
				["healed"] = {
				},
				["power"] = {
				},
				["id"] = "Player-2133-084528F6",
				["damagetaken"] = 0,
				["damagetakenspells"] = {
				},
				["deathlog"] = {
				},
				["overhealing"] = 0,
				["name"] = "Romante",
				["healingspells"] = {
				},
				["shielding"] = 0,
				["healing"] = 0,
				["auras"] = {
					["迅捷远航"] = {
						["school"] = 1,
						["name"] = "迅捷远航",
						["active"] = 1,
						["id"] = 268887,
						["started"] = 1547385548,
						["auratype"] = "BUFF",
						["uptime"] = 0,
					},
					["全能远航"] = {
						["school"] = 1,
						["name"] = "全能远航",
						["active"] = 1,
						["id"] = 268854,
						["started"] = 1547385656,
						["auratype"] = "BUFF",
						["uptime"] = 0,
					},
				},
				["ccbreaks"] = 0,
			}, -- [1]
		},
		["deaths"] = 0,
		["mobs"] = {
		},
		["mobtaken"] = 0,
		["ffdamagedone"] = 0,
		["healing"] = 0,
		["damagetaken"] = 0,
		["overhealing"] = 0,
		["shielding"] = 0,
		["starttime"] = 1547385355,
		["name"] = "总计",
		["dispells"] = 0,
		["power"] = {
		},
		["mobhdone"] = 0,
		["last_action"] = 1547385355,
		["mobdone"] = 0,
	},
	["sets"] = {
	},
}
