
SkadaDB = {
	["profileKeys"] = {
		["逍遥戰弑 - 血色十字军"] = "Default",
		["Fallenrain - 菲拉斯"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["windows"] = {
				{
					["hidden"] = true,
					["y"] = -157.999992370605,
					["point"] = "LEFT",
					["x"] = 410.000091552734,
				}, -- [1]
			},
			["versions"] = {
				["1.6.3"] = true,
				["1.6.4"] = true,
				["1.6.7"] = true,
			},
		},
	},
}
