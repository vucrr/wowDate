
MapsterDB = {
	["namespaces"] = {
		["FogClear"] = {
		},
		["Coords"] = {
		},
	},
	["profileKeys"] = {
		["逍遥戰弑 - 血色十字军"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
