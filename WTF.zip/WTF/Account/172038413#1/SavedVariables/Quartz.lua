
Quartz3DB = {
	["namespaces"] = {
		["Swing"] = {
		},
		["Buff"] = {
		},
		["Interrupt"] = {
		},
		["Flight"] = {
		},
		["Pet"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 860,
				},
			},
		},
		["EnemyCasts"] = {
		},
		["Player"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 835,
				},
			},
		},
		["GCD"] = {
		},
		["Focus"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 860,
				},
			},
		},
		["Target"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 860,
				},
			},
		},
		["Range"] = {
		},
		["Mirror"] = {
		},
		["Latency"] = {
		},
	},
	["profileKeys"] = {
		["逍遥戰弑 - 血色十字军"] = "Default",
		["Fallenrain - 菲拉斯"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
