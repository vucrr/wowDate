
Quartz3DB = {
	["namespaces"] = {
		["Swing"] = {
		},
		["Buff"] = {
		},
		["Interrupt"] = {
		},
		["Flight"] = {
		},
		["Pet"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 860.000061035156,
				},
			},
		},
		["EnemyCasts"] = {
		},
		["Player"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 835.000061035156,
				},
			},
		},
		["GCD"] = {
		},
		["Focus"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 860.000061035156,
				},
			},
		},
		["Target"] = {
			["profiles"] = {
				["Default"] = {
					["x"] = 860.000061035156,
				},
			},
		},
		["Range"] = {
		},
		["Mirror"] = {
		},
		["Latency"] = {
		},
	},
	["profileKeys"] = {
		["Viiv - 影之哀伤"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
