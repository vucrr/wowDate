
MapsterDB = {
	["namespaces"] = {
		["FogClear"] = {
		},
		["Coords"] = {
		},
	},
	["profileKeys"] = {
		["Viiv - 影之哀伤"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
