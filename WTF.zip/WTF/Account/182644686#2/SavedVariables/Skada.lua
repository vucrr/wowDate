
SkadaDB = {
	["profileKeys"] = {
		["Viiv - 影之哀伤"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["windows"] = {
				{
					["hidden"] = true,
					["y"] = 1.525878906250e-005,
					["point"] = "CENTER",
					["x"] = -3.05175781250e-005,
				}, -- [1]
			},
			["versions"] = {
				["1.6.3"] = true,
				["1.6.4"] = true,
				["1.6.7"] = true,
			},
		},
	},
}
