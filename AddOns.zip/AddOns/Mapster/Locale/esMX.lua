-- Mapster Locale
-- Please use the Localization App on WoWAce to Update this
-- http://www.wowace.com/projects/mapster/localization/ ;¶

local L = LibStub("AceLocale-3.0"):NewLocale("Mapster", "esMX")
if not L then return end


