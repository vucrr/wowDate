-- credits to:
-- HopeASD (NGA qfeizaijun)/ 简繁(NGA zhangzhanxian3)
local addonName, addon = ...

addon[1] = {} -- Gloable
addon[2] = {} -- Function
addon[3] = {} -- Config
addon[4] = {} -- Locale

local G, F, C, L = unpack(addon)

local events = {}

local host = CreateFrame("Frame")
host:SetScript("OnEvent", function(_, event, ...)
	for func in pairs(events[event]) do
		if event == "COMBAT_LOG_EVENT_UNFILTERED" then
			func(event, CombatLogGetCurrentEventInfo())
		else
			func(event, ...)
		end
	end
end)

function G:RegisterEvent(event, func, unit1, unit2)
	if not events[event] then
		events[event] = {}
		if unit1 then
			host:RegisterUnitEvent(event, unit1, unit2)
		else
			host:RegisterEvent(event)
		end
	end

	events[event][func] = true
end

function G:UnregisterEvent(event, func)
	local funcs = events[event]
	if funcs and funcs[func] then
		funcs[func] = nil

		if not next(funcs) then
			events[event] = nil
			host:UnregisterEvent(event)
		end
	end
end

local DefaultDB = {
name = true,
arrow = true,
scale =true,
jian = true,
ch = true,
mb = true,
zb = true,
zs = false,
zsx = 0.35
}

local eventframe = CreateFrame("Frame")
eventframe:RegisterEvent("ADDON_LOADED")
eventframe:SetScript("OnEvent",function(self,_,addon)
	if addon ~= "PlateColor" then return end
	if not PlateColorDB then PlateColorDB = {} end
	
		for i, j in pairs(DefaultDB) do
		if type(j) == "table" then
			if PlateColorDB[i] == nil then PlateColorDB[i] = {} end
			for k, v in pairs(j) do
				if PlateColorDB[i][k] == nil then
					PlateColorDB[i][k] = v
				end
			end
		else
			if PlateColorDB[i] == nil then PlateColorDB[i] = j end
		end
	end
	self:UnregisterAllEvents()

end)
local function TestFunc()

if PlateColorDB.name ==  true  then 
--名字放大並描邊 NGA@EKE:https://bbs.nga.cn/read.php?tid=11956803
local function SetFont(obj, optSize) 
local fontName, _,fontFlags  = obj:GetFont() 
obj:SetFont(fontName,optSize,"OUTLINE") 
obj:SetShadowOffset(0, 0) 
end 
SetFont(SystemFont_LargeNamePlate,17) 
SetFont(SystemFont_NamePlate,17) 
SetFont(SystemFont_LargeNamePlateFixed,17) 
SetFont(SystemFont_NamePlateFixed,17) 
SetFont(SystemFont_NamePlateCastBar,17)


SetCVar("namePlateMinScale", 1)  --default is 0.8 
SetCVar("namePlateMaxScale", 1)
SetCVar("nameplateSelectedScale", 1)	--当前目标血条缩放
SetCVar("nameplateLargerScale", 1) 		--BOSS血条缩放
else
SetCVar("namePlateMinScale", 0.8)  --default is 0.8 
end

if PlateColorDB.arrow ==  true  then 
--血条右侧显示箭头
hooksecurefunc("CompactUnitFrame_UpdateSelectionHighlight", function(frame)
	if not frame.optionTable.displaySelectionHighlight then return end
	if frame:IsForbidden() then return end
	if frame and frame:GetName():find("NamePlate%d") then
		if not frame.arrow then
			frame.arrow = frame:CreateTexture(nil, "PARENT")
			frame.arrow:SetTexture("Interface\\Addons\\PlateColor\\blue.tga")		-- 图标路径
			frame.arrow:SetPoint("right", frame.healthBar, "right", 55, 0)				-- 右方箭头位置
			frame.arrow:SetSize(60, 60)										-- 箭头大小
			frame.arrow:SetAlpha(0)
		end
		if UnitIsUnit(frame.displayedUnit, "target") and PlateColorDB.arrow ==  true then
			frame.arrow:SetAlpha(1)
		else
			frame.arrow:SetAlpha(0)
		end
	end
end)
end

--缩放血条
if PlateColorDB.scale == true and PlateColorDB.name == true then SetCVar("nameplateGlobalScale", 0.7)
else SetCVar("nameplateGlobalScale", 1) end

--堆叠间距
if PlateColorDB.jian == true then
SetCVar("nameplateOverlapH",  0.6)
SetCVar("nameplateOverlapV",  0.8)
else
SetCVar("nameplateOverlapH",  0.8)
SetCVar("nameplateOverlapV",  1.1)
end

--血条变色
hooksecurefunc("CompactUnitFrame_OnUpdate", function(frame) 
   if C_NamePlate.GetNamePlateForUnit(frame.unit) ~= C_NamePlate.GetNamePlateForUnit("player") and not UnitIsPlayer(frame.unit) and not CompactUnitFrame_IsTapDenied(frame) then 
		  local threat = UnitThreatSituation("player", frame.unit) or 0 
		  local reaction = UnitReaction(frame.unit, "player") 
		  local name = UnitName(frame.unit) 
		  local A = UnitBuff(frame.unit,1) 
		  local B = UnitBuff(frame.unit,2) 
		  local C = UnitBuff(frame.unit,3) 
		  local D = UnitBuff(frame.unit,4) 
   
		if name == "爆炸物" then --邪能炸药 
		r, g, b = 0, 1, 0 
		elseif A == "戈霍恩共生体" or B == "戈霍恩共生体" or C == "戈霍恩共生体" or D == "戈霍恩共生体" then--共生 
		r, g, b = 0, 0, 1 
		elseif name == "戈霍恩之嗣" then--共生小怪 
		r, g, b = 1, 0, 1 
		elseif threat == 3 then 
		r, g, b = 1, 0, 0   -- 仇恨是你 颜色 
		elseif threat == 2 then       
		r, g, b = 0, 1, 1--仇恨降低  颜色 
		elseif threat == 1 or threat == 2 then       
		r, g, b = 1, 0, 0-- 高仇恨  颜色 
		elseif UnitIsUnit(frame.displayedUnit, "target") then 
		r, g, b = 0, 1, 1-- 你的目标 颜色 
		elseif reaction == 4 then 
		r, g, b = 1, 1, 0-- 中立怪 黄色 
		else 
		r, g, b = 0, 1, 1 
        end 
      frame.healthBar:SetStatusBarColor(r, g, b, 1) 
   end 
end)
 

end
G:RegisterEvent("PLAYER_LOGIN",TestFunc)



local frame = CreateFrame("Frame", nil, InterfaceOptionsFrame)
frame.name = addonName
frame:SetScript("OnShow", function(frame)
	
	local PlateColor = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	PlateColor:SetPoint("TOPLEFT", 16, -16)
	PlateColor:SetText("PlateColor")
	PlateColor:SetFont("fonts\\ARHei.ttf", 30, "OUTLINE")
	
	local sm = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	sm:SetPoint("TOPLEFT", 380, -60)
	sm:SetText("|cffFF0000红色:|r正常\r\r|cff4C0099紫色:|r目标是你\r\r|cffFF7F00橙色:|r仇恨高\r\r|cff00FFFF青色:|r你的目标\r\r|cff00FF00绿色:|r易爆球/斩杀\r\r|cff0000FF蓝色:|r共生怪\r\r|cffFF00FF粉色:|r共生小怪")
	sm:SetJustifyH("LEFT")
	
	local qqun = frame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
	qqun:SetPoint("BOTTOMRIGHT", -10, 10)
	qqun:SetText("斗鱼:323075\r\rQQ群:718148969")
	qqun:SetJustifyH("RIGHT")


	local function newCheckbox(label, description, onClick)
		local check = CreateFrame("CheckButton", "PlateColorCheck" .. label, frame, "InterfaceOptionsCheckButtonTemplate")
		check:SetScript("OnClick", function(self)
			local tick = self:GetChecked()
			onClick(self, tick and true or false)
		end)
		check.label = _G[check:GetName() .. "Text"]
		check.label:SetText(label)
		check.tooltipText = label
		check.tooltipRequirement = description
		return check
	end
	
	local namec = newCheckbox("血条名字美化|cffFFC0CB(重载生效)|r","ekk的血条名字美化",function(self, value) PlateColorDB.name = value end)
	namec:SetChecked(PlateColorDB.name)
	namec:SetPoint("TOPLEFT", 16, -60)
	
	local arrowc = newCheckbox("血条右侧箭头|cffFFC0CB(重载生效)|r","当前目标右侧蓝色箭头",function(self, value) PlateColorDB.arrow = value end)
	arrowc:SetChecked(PlateColorDB.arrow)
	arrowc:SetPoint("TOPLEFT", 16, -90)
	
	local scalec = newCheckbox("大姓名版缩放|cffFFC0CB(重载生效)|r","缩放至70%",function(self, value) PlateColorDB.scale = value end)
	scalec:SetChecked(PlateColorDB.scale)
	scalec:SetPoint("TOPLEFT", 16, -120)
	
	local jianc = newCheckbox("缩小堆叠间距|cffFFC0CB(重载生效)|r","自动设置堆叠姓名版并微调间距",function(self, value) PlateColorDB.jian = value end)
	jianc:SetChecked(PlateColorDB.jian)
	jianc:SetPoint("TOPLEFT", 16, -150)
	
	local chc = newCheckbox("仇恨变色","根据仇恨不同显示不同颜色",function(self, value) PlateColorDB.ch = value end)
	chc:SetChecked(PlateColorDB.ch)
	chc:SetPoint("TOPLEFT", 16, -180)

	local zbc = newCheckbox("易爆球共生怪变色","易爆球共生怪变色",function(self, value) PlateColorDB.zb = value end)
	zbc:SetChecked(PlateColorDB.zb)
	zbc:SetPoint("TOPLEFT", 16, -210)
	
	local mbc = newCheckbox("当前目标变色","更容易区分当前目标和非当前目标",function(self, value) PlateColorDB.mb = value end)
	mbc:SetChecked(PlateColorDB.mb)
	mbc:SetPoint("TOPLEFT", 16, -240)
	
	local zsc = newCheckbox("斩杀变色","进入斩杀线变色",function(self, value) PlateColorDB.zs = value end)
	zsc:SetChecked(PlateColorDB.zs)
	zsc:SetPoint("TOPLEFT", 16, -270)
		
	local info = {}
	local zsDropdown = CreateFrame("Frame", "zscursor", frame, "UIDropDownMenuTemplate")
	zsDropdown:SetPoint("TOPLEFT", 0, -300)
	zsDropdown.initialize = function()
		wipe(info)
		local fonts = {0.35, 0.3, 0.2}
		local names = {"35%", "30%", "20%"}
		for i, font in next, fonts do
			info.text = names[i]
			info.value = font
			info.func = function(self)
				PlateColorDB.zsx = self.value
				zscursorText:SetText(self:GetText())
			end
			info.checked = font == PlateColorDB.zsx
			UIDropDownMenu_AddButton(info)
		end
	end
	zscursorText:SetText("设置斩杀线")
	
	frame:SetScript("OnShow", nil)
end)

InterfaceOptions_AddCategory(frame)
SLASH_PlateColor1 = "/pc"
SlashCmdList["PlateColor"] = function() 
    InterfaceOptionsFrame_OpenToCategory(frame)
	InterfaceOptionsFrame_OpenToCategory(frame)
end